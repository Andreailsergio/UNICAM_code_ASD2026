package it.unicam.cs.asdl2526.esamereversebst;

import java.util.ArrayList;
import java.util.List;

/**
 * Un oggetto di questa classe rappresenta un binary search tree, cioè un albero
 * binario di ricerca, realizzato tramite nodi ricorsivi (rappresentati da
 * oggetti della classe interna RecBST). Le API pubbliche chiamano i
 * corrispondenti metodi ricorsivi sul nodo RecBST che attualmente è la radice.
 * Questa classe non accetta elementi null e non accetta elementi duplicati.
 *
 * La particolarità di questo BST è che l'ordine è contrario rispetto a
 * quello solitamente usato, cioè la proprietà è che per ogni nodo
 * l'etichetta E è maggiore o uguale di tutti i nodi del sottoalbero
 * sinistro e minore di tutti i nodi del sottoalbero destro.
 *
 * Il binary search tree rappresentato da un oggetto di questa classe può essere
 * anche vuoto, mentre un oggetto della classe RecBST non può rappresentare un
 * albero vuoto: in quel caso l'albero vuoto è rappresentato dal fatto che il
 * puntatore all'oggetto RecBST è null, cioè dal fatto che l'oggetto non esiste.
 * 
 * La complessità delle operazioni di ricerca, inserimento e cancellazione nel
 * caso pessimo sono O(h) dove h è l'altezza dell'albero. Questa classe non
 * esegue un autobilanciamento dell'altezza, quindi nei casi degeneri la
 * complessità delle operazioni può diventare O(n) dove n è il numero degli
 * elementi presenti.
 * 
 * E è il tipo delle etichette dei nodi in questo Binary Search Tree.
 * La classe {@code E} deve avere un ordinamento naturale definito
 * tra gli elementi.
 * 
 * @author Template: Luca Tesei
 *
 */
public class ReverseBinarySearchTree<E extends Comparable<E>> {

    /*
     * Puntatore all'attuale nodo radice dell'albero, se null allora l'albero è
     * vuoto
     */
    private RecReverseBST root;

    /*
     * Numero di nodi attualmente presenti in questo albero
     */
    private int size;

    /**
     * Crea un albero binario di ricerca vuoto.
     */
    public ReverseBinarySearchTree() {
        this.root = null;
        this.size = 0;
    }

    /**
     * Costruisce un albero contenente solo un nodo radice/foglia.
     * 
     * @param label
     *                  etichetta del nodo radice/foglia
     * @throws NullPointerException
     *                                  se l'etichetta passata è null
     */
    public ReverseBinarySearchTree(E label) {
        if (label == null)
            throw new NullPointerException("Etichetta della radice null");
        this.root = new RecReverseBST(label);
        this.size = 1;
    }

    /**
     * Determina se questo albero è vuoto.
     * 
     * @return true se questo albero è vuoto, false altrimenti
     */
    public boolean isEmpty() {
        return this.root == null;
    }

    /**
     * Determina il numero di nodi in questo albero.
     * 
     * @return il numero di nodi in questo albero
     */
    public int size() {
        return this.size;
    }

    /**
     * Cancella tutti i nodi di questo albero, che quindi diventa vuoto.
     */
    public void clear() {
        this.root = null;
        this.size = 0;
    }

    /**
     * Restituisce l'altezza di questo albero. L'altezza è definita come la
     * massima lunghezza di un percorso dal nodo radice a un nodo foglia in
     * questo albero. L'altezza dell'albero vuoto è -1, l'altezza dell'albero
     * con una radice/foglia è 0, e così via.
     * 
     * @return l'altezza di questo albero oppure -1 se questo albero è vuoto.
     */
    public int getHeight() {
        if (this.isEmpty())
            return -1;
        return this.root.computeHeight();
    }

    /**
     * Restituisce la lista ordinata delle etichette dei nodi di questo albero
     * secondo l'ordinamento naturale crescente della classe {@code E}.
     * 
     * @return la lista ordinata delle etichette dei nodi di questo albero
     *         secondo l'ordinamento naturale crescente della classe {@code E}
     */
    public List<E> getOrderedLabels() {
        if (this.isEmpty())
            return new ArrayList<E>();
        return this.root.inOrderVisit();
    }

    /**
     * Cerca un certo nodo in questo albero che ha una etichetta data.
     * 
     * @param label
     *                  l'etichetta da cercare
     * @return true se l'etichetta è presente, false altrimenti
     * 
     * @throws NullPointerException
     *                                  se l'etichetta passata è null
     */
    public boolean contains(E label) {
        if (label == null)
            throw new NullPointerException("Etichetta da cercare null");
        if (this.isEmpty())
            return false;
        RecReverseBST n = this.root.search(label);
        if (n == null)
            return false;
        else
            return true;
    }

    /**
     * Restituisce l'etichetta più piccola, in base all'ordinamento naturale
     * della classe {@code E}, presente nell'albero.
     * 
     * @return l'etichetta minima presente nell'albero oppure null se l'albero è
     *         vuoto
     */
    public E getMin() {
        if (this.isEmpty())
            return null;
        return this.root.getMinNode().getLabel();
    }

    /**
     * Restituisce l'etichetta più grande, in base all'ordinamento naturale
     * della classe {@code E}, presente nell'albero.
     * 
     * @return l'etichetta massima presente nell'albero oppure null se l'albero
     *         è vuoto
     */
    public E getMax() {
        if (this.isEmpty())
            return null;
        return this.root.getMaxNode().getLabel();
    }

    /**
     * Restituisce l'etichetta successiva a una etichetta data secondo l'ordine
     * canonico della classe E.
     * 
     * @param label
     *                  l'etichetta di cui trovare il successore
     * 
     * @return l'etichetta successore di {@code label} in questo albero, oppure
     *         null se {@code label} non ha un successore
     * @throws IllegalArgumentException
     *                                      se l'etichetta {@code label} non è
     *                                      presente in questo albero
     * @throws NullPointerException
     *                                      se l'etichetta passata è null
     */
    public E getSuccessor(E label) {
        if (label == null)
            throw new NullPointerException(
                    "Etichetta di cui cercare il successore null");
        if (this.isEmpty())
            throw new IllegalArgumentException(
                    "Tentativo di cercare il successore di una etichetta non esistente");
        RecReverseBST n = this.root.search(label);
        if (n == null)
            throw new IllegalArgumentException(
                    "Tentativo di cercare il successore di una etichetta non esistente");
        RecReverseBST succ = n.getSuccessorNode();
        if (succ == null)
            return null;
        else
            return succ.getLabel();
    }

    /**
     * Restituisce l'etichetta precedente a una etichetta data secondo l'ordine
     * canonico della classe E.
     * 
     * @param label
     *                  l'etichetta di cui trovare il predecessore
     * 
     * @return l'etichetta predecessore di {@code label} in questo albero,
     *         oppure null se {@code label} non ha un predecessore
     * @throws IllegalArgumentException
     *                                      se l'etichetta {@code label} non è
     *                                      presente in questo albero
     * @throws NullPointerException
     *                                      se l'etichetta passata è null
     */
    public E getPredecessor(E label) {
        if (label == null)
            throw new NullPointerException(
                    "Etichetta di cui cercare il predecessore null");
        if (this.isEmpty())
            throw new IllegalArgumentException(
                    "Tentativo di cercare il predecessore di una etichetta non esistente");
        RecReverseBST n = this.root.search(label);
        if (n == null)
            throw new IllegalArgumentException(
                    "Tentativo di cercare il predecessore di una etichetta non esistente");
        RecReverseBST pred = n.getPredecessorNode();
        if (pred == null)
            return null;
        else
            return pred.getLabel();
    }

    /**
     * Aggiunge un nodo a questo albero con una etichetta specificata.
     * 
     * @param label
     *                  etichetta da inserire
     * 
     * @return true se il nodo è stato effettivamente inserito, false se
     *         l'etichetta era già presente
     * @throws NullPointerException
     *                                  se l'etichetta passata è null
     */
    public boolean add(E label) {
        if (label == null)
            throw new NullPointerException("Etichetta da aggiungere null");
        if (this.isEmpty()) {
            // aggiunge la radice
            this.root = new RecReverseBST(label);
            this.size = 1;
            return true;
        } // chiama il corrispondente metodo sulla radice
        else {
            boolean result = this.root.insert(label);
            if (result)
                this.size++;
            return result;
        }
    }

    /**
     * Just for JUnit testing purposes.
     * 
     * @return the RecBST node corresponding to the root of this binary search
     *         tree.
     */
    protected RecReverseBST getRoot() {
        return this.root;
    }

    /*
     * Classe interna che implementa tutti i metodi ricorsivamente e in cui ogni
     * nodo è un (sotto-)albero. Lo specificatore è protected solamente per
     * permettere i test JUnit.
     */
    protected class RecReverseBST {
        /*
         * Etichetta associata al nodo
         */
        private E label;

        /*
         * Sottoalbero sinistro, se non presente vale null
         */
        private RecReverseBST left;

        /*
         * Sottoalbero destro, se non presente vale null
         */
        private RecReverseBST right;

        /*
         * Genitore di questo (sotto-)albero, può essere null quando questo nodo
         * è la radice dell'albero rappresentato dall'oggetto della classe
         * principale.
         */
        private RecReverseBST parent;

        /*
         * Costruisce un (sotto-)albero che contiene solo la radice/foglia.
         * 
         * @param label etichetta da associare al nodo
         */
        protected RecReverseBST(E label) {
            this.label = label;
            this.left = null;
            this.right = null;
            this.parent = null;
        }

        /*
         * Costruisce un (sotto-albero) a partire da un nodo, due sotto-alberi e
         * un nodo genitore.
         * 
         * @param label etichetta da associare al nodo
         * 
         * @param aLeft sotto-albero sinistro, può essere null
         * 
         * @param aRight sotto-albero destro, può essere null
         * 
         * @param aParent nodo genitore, può essere null
         */
        protected RecReverseBST(E label, RecReverseBST aLeft, RecReverseBST aRight, RecReverseBST aParent) {
            this.label = label;
            this.left = aLeft;
            this.right = aRight;
            this.parent = aParent;
        }

        /**
         * @return the label
         */
        protected E getLabel() {
            return this.label;
        }

        /**
         * @param label
         *                  the label to set
         */
        protected void setLabel(E label) {
            this.label = label;
        }

        /**
         * @return the left
         */
        protected RecReverseBST getLeft() {
            return left;
        }

        /**
         * @param left
         *                 the left to set
         */
        protected void setLeft(RecReverseBST left) {
            this.left = left;
        }

        /**
         * @return the right
         */
        protected RecReverseBST getRight() {
            return right;
        }

        /**
         * @param right
         *                  the right to set
         */
        protected void setRight(RecReverseBST right) {
            this.right = right;
        }

        /**
         * @return the parent
         */
        protected RecReverseBST getParent() {
            return parent;
        }

        /**
         * @param parent
         *                   the parent to set
         */
        protected void setParent(RecReverseBST parent) {
            this.parent = parent;
        }

        /*
         * Restituisce l'altezza di questo nodo.
         * 
         * @return la lunghezza del massimo cammino da questo nodo a una foglia.
         */
        protected int computeHeight() {
            // TODO implementato ricorsivamente

            return heightRec(root);
        }
        private int heightRec(RecReverseBST x) {
            if (x == null) return -1;   // convenzione: albero vuoto ha altezza -1
            // invertiti i rami per fare le ricorsioni: max sul right + left
            return 1 + Math.max(heightRec(x.right), heightRec(x.left));
        }


        /*
         * Aggiunge un nodo a questo (sotto-)albero con una etichetta
         * specificata.
         * 
         * @param label etichetta da inserire
         * 
         * @return true se il nodo è stato effettivamente inserito, false se
         * l'etichetta era già presente.
         */
        protected boolean insert(E label) {
            // TODO implementato ricorsivamente

            // =========================================================
            //  Inserisce una chiave label mantenendo la proprietà BST INVERTITO.
            //  Scende a destra se key < nodo corrente, a sinistra altrimenti.
            // =========================================================

            RecReverseBST z = new RecReverseBST(label);
            RecReverseBST y = null;   // padre del punto di inserimento
            RecReverseBST x = root;

            // Scendi fino a trovare il posto giusto
            // compareTo restituisce un intero:
            // negativo se z.label è minore, zero se uguale, positivo se maggiore.
            // Quindi compareTo(...) < 0 è l'equivalente di < per i tipi generici Comparable
            while (x != null) {
                y = x;
                if (z.label.equals(x.label))
                    return false;
                else if (z.label.compareTo(x.label) < 0)
                    x = x.right;
                else
                    x = x.left;
            }

            z.parent = y;

            if (y == null)
                root = z;              // albero era vuoto
            else if (z.label.compareTo(y.label) < 0)
                y.right = z;
            else
                y.left = z;

            return true;
        }


        /*
         * Cerca un nodo con una certa etichetta in questo albero.
         * 
         * @param label l'etichetta da cercare
         * 
         * @return il puntatore al nodo che contiene l'etichetta cercata, oppure
         * null se l'etichetta non è presente
         */
        protected RecReverseBST search(E label) {
            // TODO implementato ricorsivamente
            // SEARCH — O(h) RESTITUISCE IL NODO SE TROVATO - SE NON TROVATO null
            RecReverseBST x = root;
            while (x != null) {
                if (x.label == label)
                    return x;
                else if (x.label.compareTo(label) < 0)
                    x = x.left;
                else
                    x = x.right;
            }
            return null;
        }


        /*
         * Restituisce la lista ordinata delle etichette dei nodi di questo
         * (sotto-)albero secondo l'ordinamento naturale della classe {@code E}.
         * Per ottenere il risultato fa una visita in-order.
         * 
         * @return la lista ordinata delle etichette dei nodi di questo
         * (sotto-)albero secondo l'ordinamento naturale della classe {@code E}
         */
        protected List<E> inOrderVisit() {
            // TODO implementato ricorsivamente
            // Visita: destra → nodo → sinistra
            // (invertita rispetto al BST normale, perché l'albero è "reverse")
            List<E> result = new ArrayList<>();
            if (this.right != null) {
                result.addAll(this.right.inOrderVisit());
            }
            result.add(this.label);
            if (this.left != null) {
                result.addAll(this.left.inOrderVisit());
            }
            return result;
        }

        /* private void inorderRec(RecReverseBST x) {
            if (x != null) {
                inorderRec(x.right);    // 1. visita sottoalbero destro (con valori più grandi)
                System.out.print(x.label + " ");  // 2. stampa la radice
                inorderRec(x.left);   // 3. visita sottoalbero sistro
            }
        }
        */

        /*
         * Restituisce il puntatore al nodo che contiene l'etichetta più piccola
         * presente in questo (sotto-)albero.
         * 
         * @return il nodo più a sinistra che non ha un sotto-albero sinistro in
         * questo (sotto-)albero
         */
        protected RecReverseBST getMinNode() {
            // TODO implementato ricorsivamente
            // scende sempre a destra
            if (root == null) throw new java.util.NoSuchElementException();
            RecReverseBST x = root;
            while (x.right != null) x = x.right;
            return x;
        }


        /*
         * Restituisce il puntatore al nodo che contiene l'etichetta più grande
         * presente in questo (sotto-)albero.
         * 
         * @return il nodo più a destra che non ha un sottoalbero destro in
         * questo (sotto-)albero
         */
        protected RecReverseBST getMaxNode() {
            // TODO implementato ricorsivamente
            // scende sempre a sinistra
            if (root == null) throw new java.util.NoSuchElementException();
            RecReverseBST x = root;
            while (x.left != null) x = x.left;
            return x;
        }


        // =========================================================
        //  MINIMUM / MAXIMUM — O(h)
        //  Usati internamente da successor e predecessor.
        // =========================================================

        private RecReverseBST minimum_PreSuc(RecReverseBST x) {
            while (x.left != null) x = x.left;
            return x;
        }

        private RecReverseBST maximum_PreSuc(RecReverseBST x) {
            while (x.right != null) x = x.right;
            return x;
        }

        /*
         * Restituisce il puntatore al nodo che contiene l'etichetta successiva
         * all'etichetta di questo nodo secondo l'ordine canonico della classe
         * E.
         * 
         * @return il puntatore al nodo successore oppure null se questo nodo
         * non ha successore
         */
        protected RecReverseBST getSuccessorNode() {
            // TODO implementato
            return tree_successor(root);
        }

        // =========================================================
        //  TREE_SUCCESSOR — O(h)
        //  Simmetrico a PREDECESSOR.
        //
        //  Caso 1: x ha figlio sinistro
        //          → il predecessore è il MASSIMO del sottoalbero sinistro
        //
        //  Caso 2: x NON ha figlio sinistro
        //          → risali finché si incontra un antenato y tale che
        //            x sia nel suo sottoalbero DESTRO.
        //          → se non esiste (x è già il massimo) → restituisce null
        // =========================================================

        private RecReverseBST tree_successor(RecReverseBST x) {
            // Caso 1: esiste il figlio sinistro
            if (x.left != null)
                return maximum_PreSuc(x.left);

            // Caso 2: risali finché x non è figlio destro
            RecReverseBST y = x.parent;
            // poco intuitivo - ma si risale finché si è ancora figli sinistri
            while (y != null && x == y.left) {
                x = y;
                y = y.parent;
            }
            return y;   // null se x era il massimo
        }

        /*
         * Restituisce il puntatore al nodo che contiene l'etichetta precedente
         * all'etichetta di questo nodo secondo l'ordine canonico della classe
         * E.
         *
         * @return il puntatore al nodo predecessore oppure null se questo nodo
         * non ha predecessore
         */
        protected RecReverseBST getPredecessorNode() {
            // TODO implementato
            return tree_predecessor(root);
        }
        // =========================================================
        //  TREE-PREDECESSOR(x)
        //
        //  Caso 1: x ha figlio destro
        //          → il predecessore è il MINIMO del sottoalbero destro
        //            (il più piccolo tra i valori minori di x)
        //
        //  Caso 2: x NON ha figlio destro
        //          → risali verso la radice finché si incontra
        //            un antenato y tale che x sia nel suo sottoalbero SINISTRO.
        //            Quel y è il predecessore (il primo antenato più piccolo).
        //          → se non esiste (x è già il minimo) → restituisce null
        // =========================================================

        private RecReverseBST tree_predecessor(RecReverseBST x) {
            // Caso 1: esiste il figlio destro
            if (x.right != null)
                return minimum_PreSuc(x.right);

            // Caso 2: risali finché x non è figlio sinistro
            RecReverseBST y = x.parent;
            // poco intuitivo - ma si risale finché si è ancora figli destri
            while (y != null && x == y.right) {
                x = y;
                y = y.parent;
            }
            return y;   // null se x era il minimo
        }



    }
}
