package it.unicam.cs.asdl2526.provaesame3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

class PriorityQueueTest {

    private PriorityQueue<String> pq;

    @BeforeEach
    void setup() {
        pq = new PriorityQueue<>();
    }

    @Test
    void testAddValidElement() {
        pq.add("A", 5);
        assertEquals(1, pq.size());
        assertFalse(pq.isEmpty());
    }

    @Test
    void testAddNullValueThrowsException() {
        assertThrows(NullPointerException.class,
                () -> pq.add(null, 5));
    }

    @Test
    void testAddNegativePriorityThrowsException() {
        assertThrows(IllegalArgumentException.class,
                () -> pq.add("A", -1));
    }

    @Test
    void testGetMaxReturnsHighestPriorityElement() {
        pq.add("Low", 1);
        pq.add("High", 10);

        assertEquals("High", pq.getMax());
        assertEquals(2, pq.size()); // non deve rimuovere
    }

    @Test
    void testPeakRemovesAndReturnsHighestPriorityElement() {
        pq.add("Low", 1);
        pq.add("High", 10);

        String result = pq.peak();
        assertEquals("High", result);
        assertEquals(1, pq.size());
    }

    @Test
    void testGetMaxOnEmptyQueueThrowsException() {
        assertThrows(IllegalStateException.class,
                () -> pq.getMax());
    }

    @Test
    void testPeakOnEmptyQueueThrowsException() {
        assertThrows(IllegalStateException.class,
                () -> pq.peak());
    }

    @Test
    void testGetMaxPriority() {
        pq.add("A", 3);
        pq.add("B", 7);
        pq.add("C", 5);

        assertEquals(7, pq.getMaxPriority());
    }

    @Test
    void testGetMaxPriorityOnEmptyQueueThrowsException() {
        assertThrows(IllegalStateException.class,
                () -> pq.getMaxPriority());
    }

    @Test
    void testIsEmptyInitiallyTrue() {
        assertTrue(pq.isEmpty());
        assertEquals(0, pq.size());
    }

    @Test
    void testIsEmptyAfterAdd() {
        pq.add("A", 1);
        assertFalse(pq.isEmpty());
    }

    @Test
    void testSizeAfterMultipleAdds() {
        pq.add("A", 1);
        pq.add("B", 2);
        pq.add("C", 3);

        assertEquals(3, pq.size());
    }

    @Test
    void testSizeAfterPeak() {
        pq.add("A", 1);
        pq.add("B", 2);

        pq.peak();
        assertEquals(1, pq.size());
    }

    @Test
    void testClearEmptiesQueue() {
        pq.add("A", 1);
        pq.add("B", 2);

        pq.clear();

        assertTrue(pq.isEmpty());
        assertEquals(0, pq.size());
    }

    @Test
    void testClearThenOperationsFail() {
        pq.add("A", 1);
        pq.clear();

        assertThrows(IllegalStateException.class,
                () -> pq.getMax());
    }

    @Test
    void testSort() {
        pq.add("A", 3);
        pq.add("B", 1);
        pq.add("C", 2);

        List<String> sorted = pq.sort();
        assertArrayEquals(new String[] {"A", "C", "B"}, sorted.toArray());
    }

    @Test
    void testSortOnEmptyQueueReturnsEmptyList() {
        List<String> sorted = pq.sort();
        assertTrue(sorted.isEmpty());
    }

    @Test
    void stressTestSorted() {
        int n = 1000;
        for (int i = 0; i < n; i++) {
            pq.add("Elem: " + i, n - i);
        }
        List<String> sorted = pq.sort();
        for (int i = 0; i < n; i++) {
            assertEquals("Elem: " + i, sorted.get(i));
        }
    }
}
