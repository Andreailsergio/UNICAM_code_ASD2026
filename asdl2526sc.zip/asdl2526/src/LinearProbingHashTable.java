package it.unicam.cs.asdl2526.provaesame2;

public class LinearProbingHashTable<V> {
    private static final double LOAD_FACTOR_THRESHOLD = 0.7;
    private static final int INITIAL_CAPACITY = 11;

    private Entry<V>[] table;
    private static class Entry<V> {
        V value;

        Entry(V value) {
            this.value = value;
        }
    }
    private int size;

    public LinearProbingHashTable() {
        this.table = new Entry[INITIAL_CAPACITY];
        this.size = 0;
    }

    /**
     * Aggiunge il valore specificato alla tabella hash se non è già presente.
     * @param value il valore da inserire
     * @return true se il valore è stato inserito, false se era già presente
     * @throws NullPointerException se il valore è null
     */
    public boolean insert(V value) {
        // TODO implementato il metodo
        if (value == null) throw new NullPointerException("Il valore non può essere null");

        int index = hash(value);
        int visited = 0;
        while (table[index] != null && visited < table.length) {
            if (table[index].value.equals(value)) {
                return false; // Elemento già presente come duplicato
            }
            index = probe(index);
            visited ++;
        }
        table[index] = new Entry<>(value);
        size++;

        resize(); // Controlla e applica resize dopo l'inserimento
        // (es. dopo 8 inserimenti su capacità 11 → load factor 8/11 ≈ 0.727 > 0.7 parametro di soglia
        // → resize scatta immediatamente e la tabella viene espansa,
        // portando il load factor sotto 0.7 prima che il test testResizeTriggered lo verifichi.)

        return true;
    }

    /**
     * Verifica se il valore specificato è presente nella tabella hash.
     * @param value il valore da cercare
     * @return true se il valore è presente, false altrimenti
     * @throws NullPointerException se il valore è null
     */
    public boolean contains(V value) {
        // TODO implementato il metodo
        if (value == null) throw new NullPointerException("Il valore non può essere null");

        int index = hash(value);
        // il contatore visited serve ad evitare loop infiniti qualora l'array fosse completamente pieno.
        int visited = 0;
        while (table[index] != null && visited < table.length) {
            if (table[index].value.equals(value)) {
                return true;
            }
            index = probe(index);
            visited++;
        }
        return false;
    }

    /**
     * Restituisce il numero di elementi presenti nella tabella hash.
     * @return il numero di elementi nella tabella hash
     */
    public int size() {
        return this.size;
    }

    /**
     * Verifica se la tabella hash è vuota.
     * @return true se la tabella hash è vuota, false altrimenti
     */
    public boolean isEmpty() {
        return this.size == 0;
    }

    /**
     * Rimuove tutti gli elementi dalla tabella hash.
     */
    public void clear() {
        // TODO implementato il metodo clear
        // Il clear ricrea l'array con la stessa lunghezza corrente table.length (non quella iniziale)
        // resettarla a INITIAL_CAPACITY per avere la lunghezza iniziale
        table = new Entry[table.length];
        size = 0;
    }

    /**
     * Calcola e restituisce il fattore di carico della tabella hash.
     * @return il fattore di carico, che è il rapporto tra il numero di elementi e la capacità della tabella
     */
    public double loadFactor() {
        // TODO: implementato il calcolo del fattore di carico
        return (double) size / table.length;
    }

    /**
     * Effettua il resize della tabella hash quando il fattore di carico supera la soglia.
     */
    private void resize() {
        // TODO: implementato il resize
        // resize usa nextPrime perché con l'hashing lineare avere una capacità primo riduce i cluster
        // e garantisce che la sequenza di probing copra tutti gli slot.
        if (loadFactor() <= LOAD_FACTOR_THRESHOLD) return;
        Entry<V>[] oldTable = table;
        // Trova il prossimo numero primo circa doppio della capacità attuale
        int newCapacity = nextPrime(oldTable.length * 2);
        table = new Entry[newCapacity];
        size = 0;

        for (Entry<V> entry : oldTable) {
            if (entry != null) {
                insert(entry.value); // Re-inserisce nel nuovo array
            }
        }

    }

    // TODO metodi aggiunti
    private int nextPrime(int n) {
        while (!isPrime(n)) n++;
        return n;
    }

    private boolean isPrime(int n) {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    /**
     * Calcola l'indice hash per il valore specificato.
     * @param value il valore di cui calcolare l'indice hash
     * @return l'indice hash nella tabella
     */
    private int hash(V value) {
        return Math.abs(value.hashCode()) % table.length;
    }

    /**
     * Calcola il prossimo indice da sondare in caso di collisione.
     * @param index l'indice corrente
     * @return il prossimo indice da sondare
     */
    private int probe(int index) {
        return (index + 1) % table.length;
    }
    
}