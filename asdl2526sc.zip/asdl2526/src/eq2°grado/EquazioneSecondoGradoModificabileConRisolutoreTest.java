/**
 *
 */
package it.unicam.cs.asdl2526.es1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Template: Luca Tesei, Implementation: Collettiva da Esercitazione a
 *         Casa
 *
 */
class EquazioneSecondoGradoModificabileConRisolutoreTest {
    /*
     * Costante piccola per il confronto di due numeri double
     */
    static final double EPSILON = 1.0E-15;

    @Test
    final void testEquazioneSecondoGradoModificabileConRisolutore() {
        // controllo che il valore 0 su a lanci l'eccezione
        assertThrows(IllegalArgumentException.class,
                () -> new EquazioneSecondoGradoModificabileConRisolutore(0, 1,
                        1));
        // devo controllare che comunque nel caso normale il costruttore
        // funziona
        EquazioneSecondoGradoModificabileConRisolutore eq = new EquazioneSecondoGradoModificabileConRisolutore(
                1, 1, 1);
        // Controllo che all'inizio l'equazione non risulti già risolta
        assertFalse(eq.isSolved());
    }

    @Test
    final void testGetA() {
        double x = 10;
        EquazioneSecondoGradoModificabileConRisolutore e1 = new EquazioneSecondoGradoModificabileConRisolutore(
                x, 1, 1);
        // controllo che il valore restituito sia quello che ho messo
        // all'interno
        // dell'oggetto
        assertTrue(Math.abs(x - e1.getA()) < EPSILON);
        // in generale si dovrebbe usare assertTrue(Math.abs(x -
        // e1.getA())<EPSILON) ma in
        // questo caso il valore che testiamo non ha subito manipolazioni quindi
        // la sua rappresentazione sarà la stessa di quella inserita nel
        // costruttore senza errori di approssimazione

    }

    @Test
    final void testSetA() {
        // TODO implementato
        double x = 3.0;
        double y = 0.0;
        EquazioneSecondoGradoModificabileConRisolutore e1 = new EquazioneSecondoGradoModificabileConRisolutore(2, 1, 1);
        // setA con valore valido: il getter deve restituire il nuovo valore
        double nuovoA = 3.0;
        e1.setA(nuovoA);
        assertTrue(Math.abs(nuovoA - e1.getA()) < EPSILON);

        // setA(0) deve lanciare IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> e1.setA(0.0));

        // Dopo solve(), isSolved() è true
        e1.solve();
        assertTrue(e1.isSolved());

        // Impostare un valore DIVERSO deve invalidare la soluzione
        e1.setA(2.0);
        assertFalse(e1.isSolved());

        // getSolution() su equazione non risolta deve lanciare IllegalStateException
        assertThrows(IllegalStateException.class, () -> e1.getSolution());

        // Impostare lo stesso valore NON deve invalidare la soluzione
        e1.solve();
        assertTrue(e1.isSolved());
        e1.setA(2.0); // stesso valore già presente
        assertTrue(e1.isSolved());
    }

    @Test
    final void testGetB() {
        double x = 10;
        EquazioneSecondoGradoModificabileConRisolutore e1 =
                new EquazioneSecondoGradoModificabileConRisolutore(10, x, 1);
        assertTrue(Math.abs(x - e1.getB()) < EPSILON);
    }

    @Test
    final void testSetB() {
        EquazioneSecondoGradoModificabileConRisolutore e1 =
                new EquazioneSecondoGradoModificabileConRisolutore(2, 1, 1);

        // setB con valore valido: il getter deve restituire il nuovo valore
        double nuovoB = 3.0;
        e1.setB(nuovoB);
        assertTrue(Math.abs(nuovoB - e1.getB()) < EPSILON);

        // Dopo solve(), isSolved() è true
        e1.solve();
        assertTrue(e1.isSolved());

        // Impostare un valore DIVERSO deve invalidare la soluzione
        e1.setB(99.0);
        assertFalse(e1.isSolved());

        // getSolution() su equazione non risolta deve lanciare IllegalStateException
        assertThrows(IllegalStateException.class, () -> e1.getSolution());

        // Impostare lo stesso valore NON deve invalidare la soluzione
        e1.solve();
        assertTrue(e1.isSolved());
        e1.setB(99.0); // stesso valore già presente
        assertTrue(e1.isSolved());
    }


    @Test
    final void testSetC() {
        EquazioneSecondoGradoModificabileConRisolutore e1 =
                new EquazioneSecondoGradoModificabileConRisolutore(2, 1, 1);

        // setC con valore valido: il getter deve restituire il nuovo valore
        double nuovoC = 3.0;
        e1.setC(nuovoC);
        assertTrue(Math.abs(nuovoC - e1.getC()) < EPSILON);

        // Dopo solve(), isSolved() è true
        e1.solve();
        assertTrue(e1.isSolved());

        // Impostare un valore DIVERSO deve invalidare la soluzione
        e1.setC(99.0);
        assertFalse(e1.isSolved());

        // getSolution() su equazione non risolta deve lanciare IllegalStateException
        assertThrows(IllegalStateException.class, () -> e1.getSolution());

        // Impostare lo stesso valore NON deve invalidare la soluzione
        e1.solve();
        assertTrue(e1.isSolved());
        e1.setC(99.0); // stesso valore già presente
        assertTrue(e1.isSolved());
    }

    @Test
    final void testGetC() {

        double x = 10;
        EquazioneSecondoGradoModificabileConRisolutore e1 = new EquazioneSecondoGradoModificabileConRisolutore(
                10, 1, x);
        assertTrue(x == e1.getC());
    }


    @Test
    final void testIsSolved() {
        EquazioneSecondoGradoModificabileConRisolutore e1 =
                new EquazioneSecondoGradoModificabileConRisolutore(1, 1, 0);

        // All'inizio non risolta
        assertFalse(e1.isSolved());

        // Dopo solve() deve risultare risolta
        e1.solve();
        assertTrue(e1.isSolved());

        // Dopo cambio parametro deve tornare non risolta
        e1.setB(5.0);
        assertFalse(e1.isSolved());
    }

    @Test
    final void testSolve() {
        // Caso delta > 0: due soluzioni reali distinte (x^2 - 1 = 0 → x=1, x=-1)
        EquazioneSecondoGradoModificabileConRisolutore e1 =
                new EquazioneSecondoGradoModificabileConRisolutore(1, 0, -1);
        e1.solve();
        assertTrue(e1.isSolved());
        SoluzioneEquazioneSecondoGrado s1 = e1.getSolution();
        assertFalse(s1.isEmptySolution());
        assertFalse(s1.isOneSolution());
        assertTrue(Math.abs(s1.getS1() - 1) < EPSILON);
        assertTrue(Math.abs(s1.getS2() + 1) < EPSILON);

        // Caso delta == 0: soluzione unica (x^2 - 2x + 1 = 0 → x=1)
        EquazioneSecondoGradoModificabileConRisolutore e2 =
                new EquazioneSecondoGradoModificabileConRisolutore(1, -2, 1);
        e2.solve();
        SoluzioneEquazioneSecondoGrado s2 = e2.getSolution();
        assertFalse(s2.isEmptySolution());
        assertTrue(s2.isOneSolution());
        assertTrue(Math.abs(s2.getS1() - 1) < EPSILON);

        // Caso delta < 0: nessuna soluzione reale (x^2 + 1 = 0)
        EquazioneSecondoGradoModificabileConRisolutore e3 =
                new EquazioneSecondoGradoModificabileConRisolutore(1, 0, 1);
        e3.solve();
        SoluzioneEquazioneSecondoGrado s3 = e3.getSolution();
        assertTrue(s3.isEmptySolution());

        // Chiamare solve() due volte non deve cambiare la soluzione (idempotenza)
        e1.solve();
        assertTrue(e1.isSolved());
        SoluzioneEquazioneSecondoGrado s1bis = e1.getSolution();
        assertEquals(s1, s1bis);
    }

    @Test
    final void testGetSolution() {
        // Prima di solve() deve lanciare IllegalStateException
        EquazioneSecondoGradoModificabileConRisolutore e1 =
                new EquazioneSecondoGradoModificabileConRisolutore(1, 1, 3);
        assertThrows(IllegalStateException.class, () -> e1.getSolution());

        // Dopo solve() restituisce la soluzione senza eccezioni
        e1.solve();
        assertNotNull(e1.getSolution());

        // Dopo modifica di un parametro deve tornare a lanciare l'eccezione
        e1.setB(10);
        assertThrows(IllegalStateException.class, () -> e1.getSolution());

    }

}
