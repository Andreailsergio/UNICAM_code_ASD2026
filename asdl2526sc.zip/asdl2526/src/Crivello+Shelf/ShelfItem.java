package it.unicam.cs.asdl2526.tutorato.mp1;

/**
 * Interfaccia che accomuna tutti gli oggetti che possono essere posati su una
 * mensola.
 * 
 * @author Luca Tesei
 *
 */
public interface ShelfItem {
    /**
     * @return la lunghezza dell'oggetto
     */
    double getLength();

    /**
     * @return la larghezza dell'oggetto
     */
    double getWidth();

    /**
     * @return il peso dell'oggetto
     */
    double getWeight();

    /**
     * Restituisce l'area occupata dall'oggetto sulla superficie della mensola.
     * L'implementazione di default calcola l'area moltiplicando la lunghezza
     * per la larghezza, assumendo che l'oggetto appoggi una superficie
     * rettangolare. Nel caso di forma diversa l'implementazione di default deve
     * essere ridefinita.
     * 
     * @return la superficie occupata dall'oggetto
     */
    default double getOccupiedSurface() {
        return getLength() * getWidth();
    }
}
