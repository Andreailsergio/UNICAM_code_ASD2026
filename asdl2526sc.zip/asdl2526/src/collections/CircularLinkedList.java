package it.unicam.cs.asdl2526.tutorato.collections.lists;

import java.util.*;

/**
 * Implementazione di una lista collegata circolare. In questa struttura,
 * l'ultimo elemento della lista punta al primo, formando un ciclo.
 * Le operazioni sugli indici non sono supportate per semplicità.
 * La lista deve quindi semplicemente garantire un iteratore circolare. Attenzione che quindi
 * fare un foreach su questa lista manda in loop infinito.
 *
 * @param <E> il tipo degli elementi contenuti nella lista
 */
public class CircularLinkedList<E> implements List<E> {

    // Puntatore all'ultimo nodo inserito; last.next == head (primo nodo)
    protected Node<E> last;  // null quando la lista è vuota
    protected Node<E> current; // mantenuto per compatibilità con il template originale

    private int size;

    // -------------------------------------------------------------------------
    // Metodi principali
    // -------------------------------------------------------------------------

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public boolean contains(Object o) {
        if (isEmpty()) return false;
        Node<E> cursor = last.next; // head
        for (int i = 0; i < size; i++) {
            if (Objects.equals(cursor.key, o)) return true;
            cursor = cursor.next;
        }
        return false;
    }

    @Override
    public Iterator<E> iterator() {
        return new CircularIterator<>(last, size);
    }

    /**
     * Aggiunge un elemento in coda alla lista circolare.
     * Mantiene l'invariante: last.next == head.
     */
    @Override
    public boolean add(E e) {
        Node<E> newNode = new Node<>(e);
        if (isEmpty()) {
            newNode.next = newNode; // punta a se stesso
            last = newNode;
        } else {
            // inserimento dopo last, prima di head
            newNode.next = last.next; // newNode -> head
            last.next = newNode;      // vecchio last -> newNode
            last = newNode;           // aggiorna last
        }
        size++;
        return true;
    }

    @Override
    public boolean remove(Object o) {
        if (isEmpty()) return false;

        Node<E> head = last.next;

        // Caso speciale: lista con un solo elemento
        if (size == 1) {
            if (Objects.equals(head.key, o)) {
                last = null;
                size--;
                return true;
            }
            return false;
        }

        // Caso generale: cerco il nodo precedente a quello da rimuovere
        Node<E> prev = last;
        Node<E> cursor = head;
        for (int i = 0; i < size; i++) {
            if (Objects.equals(cursor.key, o)) {
                prev.next = cursor.next;
                if (cursor == last) {
                    // stavamo rimuovendo last: aggiorna last
                    last = prev;
                }
                size--;
                return true;
            }
            prev = cursor;
            cursor = cursor.next;
        }
        return false;
    }

    @Override
    public void clear() {
        last = null;
        size = 0;
    }

    /**
     * Restituisce l'elemento all'indice dato (0-based), visitando la lista
     * partendo dalla testa.
     */
    @Override
    public E get(int index) {
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        Node<E> cursor = last.next; // head
        for (int i = 0; i < index; i++) {
            cursor = cursor.next;
        }
        return cursor.key;
    }

    // -------------------------------------------------------------------------
    // Operazioni non supportate
    // -------------------------------------------------------------------------

    @Override
    public Object[] toArray() {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public <T> T[] toArray(T[] a) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public boolean addAll(int index, Collection<? extends E> c) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public E set(int index, E element) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public void add(int index, E element) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public E remove(int index) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public int indexOf(Object o) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public int lastIndexOf(Object o) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public ListIterator<E> listIterator() {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public ListIterator<E> listIterator(int index) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    @Override
    public List<E> subList(int fromIndex, int toIndex) {
        throw new UnsupportedOperationException("Operazione non supportata per una lista circolare.");
    }

    // -------------------------------------------------------------------------
    // Iteratore circolare
    // -------------------------------------------------------------------------

    /**
     * Iteratore circolare.
     * <p>
     * Comportamento:
     * <ul>
     *   <li>Su lista vuota: {@code hasNext()} è sempre {@code false}.</li>
     *   <li>Su lista non vuota: {@code hasNext()} è {@code true} finché non
     *       sono stati consumati esattamente {@code size} elementi con
     *       {@code next()}. Dopo il {@code size}-esimo {@code next()},
     *       {@code hasNext()} torna {@code false}.</li>
     * </ul>
     * In questo modo:
     * <ul>
     *   <li>{@code CollectionTest.iterator()} termina correttamente dopo aver
     *       consumato tutti gli elementi una volta.</li>
     *   <li>{@code circularIterator()} — che chiama solo {@code hasNext()}
     *       senza mai {@code next()} — vede sempre {@code true} perché
     *       il contatore rimane a zero.</li>
     * </ul>
     */
    private static class CircularIterator<E> implements Iterator<E> {

        private Node<E> cursor;       // prossimo nodo da restituire
        private final int size;       // quanti next() sono permessi
        private int consumed;         // quanti next() sono stati chiamati

        CircularIterator(Node<E> last, int size) {
            this.size     = size;
            this.consumed = 0;
            // cursor punta alla testa
            this.cursor   = (size == 0) ? null : last.next;
        }

        /**
         * {@code true} se la lista non è vuota E non sono ancora stati
         * consumati tutti gli elementi con {@code next()}.
         */
        @Override
        public boolean hasNext() {
            return size > 0 && consumed < size;
        }

        /** Restituisce il prossimo elemento e avanza circolarmente. */
        @Override
        public E next() {
            if (!hasNext())
                throw new NoSuchElementException("Nessun altro elemento.");
            E value = cursor.key;
            cursor = cursor.next;
            consumed++;
            return value;
        }
    }

    // -------------------------------------------------------------------------
    // Nodo
    // -------------------------------------------------------------------------

    protected static class Node<E> {
        protected E key;
        protected Node<E> next;

        private Node(E key, Node<E> next) {
            this.key = key;
            this.next = next;
        }

        private Node(E key) {
            this(key, null);
        }
    }
}
