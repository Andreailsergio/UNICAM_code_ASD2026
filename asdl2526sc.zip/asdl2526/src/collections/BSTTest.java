package it.unicam.cs.asdl2526.tutorato.collections.sets.tree;

import it.unicam.cs.asdl2526.tutorato.collections.sets.SetTest;

import java.util.Set;

public class BSTTest extends SetTest {

    // CORREZIONE: era new HashSet<>() — il test deve usare BST, non HashSet.
    // Con HashSet, add(null) non lancia NullPointerException e il test
    // addNullElement() (ereditato da CollectionTest via SetTest) falliva.
    @Override
    public <E extends Comparable<E>> Set<E> createSet() {
        return new BST<>();
    }

}
