package it.unicam.cs.asdl2526.tutorato.collections.sets.hash;

import java.util.*;

/**
 * Una classe che implementa un insieme (set) utilizzando una tabella di hash
 * con probing lineare per la risoluzione delle collisioni.
 *
 * @param <E> il tipo degli elementi contenuti nell'insieme
 */
public class HashSetLinearProbing<E> implements Set<E> {

    private Node<E>[] table;
    private int size;

    // Versione della struttura: ogni modifica la incrementa.
    // Serve all'iteratore per rilevare modifiche concorrenti.
    private int modCount;

    private static final double LOAD_FACTOR_THRESHOLD = 0.5;
    private static final int INITIAL_CAPACITY = 16;

    public HashSetLinearProbing() {
        this(INITIAL_CAPACITY);
    }

    public HashSetLinearProbing(int capacity) {
        table = newArray(capacity);
        size = 0;
        modCount = 0;
    }

    // -------------------------------------------------------------------------
    // Hash
    // -------------------------------------------------------------------------

    /**
     * Calcola l'indice della tabella per l'elemento dato.
     * Usa Math.abs e il modulo per garantire un valore in [0, table.length-1].
     */
    @SuppressWarnings("unchecked")
    private int hash(E elem) {
        // hashCode() può essere negativo: usiamo & con Integer.MAX_VALUE
        // per azzerare il bit di segno prima del modulo.
        return (elem.hashCode() & Integer.MAX_VALUE) % table.length;
    }

    // -------------------------------------------------------------------------
    // Resize
    // -------------------------------------------------------------------------

    /**
     * Raddoppia la capacità della tabella e reinserisce tutti gli elementi
     * non cancellati.
     */
    private void resize() {
        Node<E>[] oldTable = table;
        table = newArray(oldTable.length * 2);
        size = 0; // verrà ricalcolato durante il reinserimento

        for (Node<E> node : oldTable) {
            if (node != null && !node.isDeleted) {
                add(node.value); // reinserisce nell'array più grande
            }
        }
        // modCount non viene incrementato qui: resize è un'operazione interna
        // invocata da add(), che lo incrementa già.
    }

    // -------------------------------------------------------------------------
    // Set operations
    // -------------------------------------------------------------------------

    /**
     * Aggiunge un elemento all'insieme se non è già presente.
     * Usa linear probing per risolvere le collisioni.
     */
    @Override
    public boolean add(E e) {
        if (e == null) throw new NullPointerException("Null non supportato.");

        // Ridimensiona se necessario PRIMA di cercare la posizione
        if ((double) (size + 1) / table.length > LOAD_FACTOR_THRESHOLD) {
            resize();
        }

        int index = hash(e);
        int firstDeleted = -1; // prima slot DELETED trovata durante il probing

        for (int i = 0; i < table.length; i++) {
            int probe = (index + i) % table.length;
            Node<E> node = table[probe];

            if (node == null) {
                // Slot libero: inserisci (riusa uno slot DELETED se trovato)
                int insertAt = (firstDeleted != -1) ? firstDeleted : probe;
                table[insertAt] = new Node<>(e);
                size++;
                modCount++;
                return true;
            }

            if (node.isDeleted) {
                // Teniamo nota del primo slot DELETED per riutilizzarlo
                if (firstDeleted == -1) firstDeleted = probe;
                // Continuiamo a cercare: potrebbe esserci il duplicato più avanti
            } else {
                // Slot occupato: controlla duplicato
                if (node.value.equals(e)) return false;
            }
        }

        // Tutta la tabella è piena di DELETED: inserisci nel primo DELETED
        if (firstDeleted != -1) {
            table[firstDeleted] = new Node<>(e);
            size++;
            modCount++;
            return true;
        }

        // Non dovrebbe mai arrivare qui grazie al resize anticipato
        throw new IllegalStateException("Tabella piena.");
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean contains(Object o) {
        if (o == null) return false;
        E elem;
        try {
            elem = (E) o;
        } catch (ClassCastException e) {
            return false;
        }

        int index = hash(elem);
        for (int i = 0; i < table.length; i++) {
            int probe = (index + i) % table.length;
            Node<E> node = table[probe];

            if (node == null) return false;          // catena interrotta: non c'è
            if (!node.isDeleted && node.value.equals(elem)) return true;
        }
        return false;
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean remove(Object o) {
        if (o == null) return false;
        E elem;
        try {
            elem = (E) o;
        } catch (ClassCastException e) {
            return false;
        }

        int index = hash(elem);
        for (int i = 0; i < table.length; i++) {
            int probe = (index + i) % table.length;
            Node<E> node = table[probe];

            if (node == null) return false;          // catena interrotta
            if (!node.isDeleted && node.value.equals(elem)) {
                node.markDeleted();
                size--;
                modCount++;
                return true;
            }
        }
        return false;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public void clear() {
        table = newArray(INITIAL_CAPACITY);
        size = 0;
        modCount++;
    }

    @Override
    public Iterator<E> iterator() {
        return new HashSetIterator();
    }

    // -------------------------------------------------------------------------
    // Utility
    // -------------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    private Node<E>[] newArray(int capacity) {
        return (Node<E>[]) new Node[capacity];
    }

    // -------------------------------------------------------------------------
    // equals / hashCode  (contratto java.util.Set)
    // -------------------------------------------------------------------------

    /**
     * Due Set sono uguali se e solo se hanno la stessa dimensione e ogni
     * elemento del primo è contenuto nel secondo (contratto java.util.AbstractSet).
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Set)) return false;
        Set<?> other = (Set<?>) obj;
        if (size != other.size()) return false;
        for (Node<E> node : table) {
            if (node != null && !node.isDeleted) {
                if (!other.contains(node.value)) return false;
            }
        }
        return true;
    }

    /**
     * L'hashCode di un Set è la somma degli hashCode dei suoi elementi
     * (contratto java.util.AbstractSet).
     */
    @Override
    public int hashCode() {
        int h = 0;
        for (Node<E> node : table) {
            if (node != null && !node.isDeleted) {
                h += node.value.hashCode();
            }
        }
        return h;
    }

    // -------------------------------------------------------------------------
    // Operazioni bulk
    // -------------------------------------------------------------------------

    @Override public boolean addAll(Collection<? extends E> c) {
        boolean changed = false;
        for (E e : c) changed |= add(e);
        return changed;
    }
    @Override public boolean containsAll(Collection<?> c) {
        for (Object o : c) if (!contains(o)) return false;
        return true;
    }
    @Override public boolean removeAll(Collection<?> c) {
        boolean changed = false;
        for (Object o : c) changed |= remove(o);
        return changed;
    }
    @Override public boolean retainAll(Collection<?> c) { throw new UnsupportedOperationException(); }
    @Override public Object[] toArray() { throw new UnsupportedOperationException(); }
    @Override public <T> T[] toArray(T[] a) { throw new UnsupportedOperationException(); }

    // -------------------------------------------------------------------------
    // Iteratore
    // -------------------------------------------------------------------------

    /**
     * Iteratore per l'insieme. Lancia IllegalStateException se la collezione
     * viene modificata dopo la creazione dell'iteratore.
     */
    protected class HashSetIterator implements Iterator<E> {

        private int cursor;           // indice corrente nella table
        private final int expectedModCount;

        HashSetIterator() {
            this.expectedModCount = modCount;
            this.cursor = advanceFrom(0);
        }

        /** Avanza cursor fino al prossimo slot occupato (non null, non deleted). */
        private int advanceFrom(int start) {
            int i = start;
            while (i < table.length) {
                if (table[i] != null && !table[i].isDeleted) return i;
                i++;
            }
            return table.length; // sentinella "fine"
        }

        @Override
        public boolean hasNext() {
            // Se ci sono state modifiche, l'iteratore è invalidato
            if (modCount != expectedModCount) return false;
            return cursor < table.length;
        }

        @Override
        public E next() {
            if (modCount != expectedModCount)
                throw new IllegalStateException("La collezione è stata modificata.");
            if (cursor >= table.length)
                throw new NoSuchElementException();
            E value = table[cursor].value;
            cursor = advanceFrom(cursor + 1);
            return value;
        }
    }

    // -------------------------------------------------------------------------
    // Nodo
    // -------------------------------------------------------------------------

    private static class Node<E> {
        E value;
        boolean isDeleted;

        Node(E value) {
            this.value = value;
            this.isDeleted = false;
        }

        public E getValue() {
            return value;
        }

        public void markDeleted() {
            this.isDeleted = true;
        }
    }
}
