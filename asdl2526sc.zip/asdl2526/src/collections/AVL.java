package it.unicam.cs.asdl2526.tutorato.collections.sets.tree;

import java.util.ArrayList;
import java.util.List;

/**
 * Questa classe rappresenta un albero AVL.
 * Supporta inserimento con auto-bilanciamento tramite rotazioni,
 * ricerca e visite in-order e post-order.
 */
public class AVL {

    // -------------------------------------------------------------------------
    // Nodo AVL
    // -------------------------------------------------------------------------

    protected class AVLNode {
        public AVLNode left, right;
        public int value;
        public int height;

        AVLNode(int value) {
            this.value  = value;
            this.height = 1;
        }
    }

    // -------------------------------------------------------------------------
    // Utility statiche sull'altezza e bilanciamento
    // -------------------------------------------------------------------------

    protected static int getHeight(AVLNode node) {
        if (node == null) return 0;
        return node.height;
    }

    protected static int getBalance(AVLNode node) {
        if (node == null) return 0;
        return getHeight(node.left) - getHeight(node.right);
    }

    /** Aggiorna l'altezza del nodo in base ai figli. */
    private void updateHeight(AVLNode node) {
        node.height = 1 + Math.max(getHeight(node.left), getHeight(node.right));
    }

    // -------------------------------------------------------------------------
    // Rotazioni
    // -------------------------------------------------------------------------

    /**
     * Rotazione destra sul nodo y.
     * <pre>
     *      y                x
     *     / \              / \
     *    x   T3    →      T1   y
     *   / \                   / \
     *  T1  T2               T2  T3
     * </pre>
     */
    private AVLNode rotateRight(AVLNode y) {
        AVLNode x  = y.left;
        AVLNode T2 = x.right;

        x.right = y;
        y.left  = T2;

        updateHeight(y);
        updateHeight(x);

        return x; // nuova radice del sottoalbero
    }

    /**
     * Rotazione sinistra sul nodo x.
     * <pre>
     *    x                  y
     *   / \                / \
     *  T1   y    →        x   T3
     *      / \           / \
     *     T2  T3        T1  T2
     * </pre>
     */
    private AVLNode rotateLeft(AVLNode x) {
        AVLNode y  = x.right;
        AVLNode T2 = y.left;

        y.left  = x;
        x.right = T2;

        updateHeight(x);
        updateHeight(y);

        return y; // nuova radice del sottoalbero
    }

    // -------------------------------------------------------------------------
    // Radice
    // -------------------------------------------------------------------------

    /** La radice dell'albero AVL (protected per i test). */
    protected AVLNode root;

    // -------------------------------------------------------------------------
    // Add
    // -------------------------------------------------------------------------

    /**
     * Aggiunge un valore all'albero AVL mantenendo il bilanciamento.
     *
     * @param value il valore da aggiungere
     * @return true se il valore è stato aggiunto, false se era già presente
     */
    public boolean add(int value) {
        boolean[] inserted = {false};
        root = insert(root, value, inserted);
        return inserted[0];
    }

    /**
     * Inserimento ricorsivo con ribilanciamento.
     * Segue la specifica del javadoc:
     * <ul>
     *   <li>balance > 1 && value < left.value  → rotazione destra (LL)</li>
     *   <li>balance < -1 && value > right.value → rotazione sinistra (RR)</li>
     *   <li>balance > 1 && value > left.value  → rotazione sinistra su left, poi destra (LR)</li>
     *   <li>balance < -1 && value < right.value → rotazione destra su right, poi sinistra (RL)</li>
     * </ul>
     */
    private AVLNode insert(AVLNode node, int value, boolean[] inserted) {
        // 1. Normale inserimento BST
        if (node == null) {
            inserted[0] = true;
            return new AVLNode(value);
        }

        if (value < node.value) {
            node.left  = insert(node.left,  value, inserted);
        } else if (value > node.value) {
            node.right = insert(node.right, value, inserted);
        } else {
            // Duplicato: non inserire
            return node;
        }

        // 2. Aggiorna altezza
        updateHeight(node);

        // 3. Calcola bilanciamento e applica rotazioni
        int balance = getBalance(node);

        // LL: sbilanciamento sinistro, il valore è nel sottoalbero sinistro-sinistro
        if (balance > 1 && value < node.left.value) {
            return rotateRight(node);
        }

        // RR: sbilanciamento destro, il valore è nel sottoalbero destro-destro
        if (balance < -1 && value > node.right.value) {
            return rotateLeft(node);
        }

        // LR: sbilanciamento sinistro, il valore è nel sottoalbero sinistro-destro
        if (balance > 1 && value > node.left.value) {
            node.left = rotateLeft(node.left);
            return rotateRight(node);
        }

        // RL: sbilanciamento destro, il valore è nel sottoalbero destro-sinistro
        if (balance < -1 && value < node.right.value) {
            node.right = rotateRight(node.right);
            return rotateLeft(node);
        }

        // Nessun bilanciamento necessario
        return node;
    }

    // -------------------------------------------------------------------------
    // Contains
    // -------------------------------------------------------------------------

    /**
     * Verifica se un valore è presente nell'albero AVL.
     */
    public boolean contains(int value) {
        AVLNode cursor = root;
        while (cursor != null) {
            if (value < cursor.value)      cursor = cursor.left;
            else if (value > cursor.value) cursor = cursor.right;
            else                           return true;
        }
        return false;
    }

    // -------------------------------------------------------------------------
    // Visite
    // -------------------------------------------------------------------------

    /**
     * Visita in-order (sinistro → radice → destro).
     * Restituisce i valori in ordine crescente.
     */
    public List<Integer> InOrderVisit() {
        List<Integer> result = new ArrayList<>();
        inOrder(root, result);
        return result;
    }

    private void inOrder(AVLNode node, List<Integer> result) {
        if (node == null) return;
        inOrder(node.left,  result);
        result.add(node.value);
        inOrder(node.right, result);
    }

    /**
     * Visita post-order (sinistro → destro → radice).
     * Nonostante il nome del metodo nel template sia {@code postOrder()},
     * il javadoc descrive correttamente una visita post-order.
     */
    public List<Integer> postOrder() {
        List<Integer> result = new ArrayList<>();
        postOrderVisit(root, result);
        return result;
    }

    private void postOrderVisit(AVLNode node, List<Integer> result) {
        if (node == null) return;
        postOrderVisit(node.left,  result);
        postOrderVisit(node.right, result);
        result.add(node.value);
    }
}
