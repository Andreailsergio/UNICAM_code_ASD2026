package it.unicam.cs.asdl2526.slides.javaeoop;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
/* ---------+--------+---------+---------+------
Modifier    | Class  | Package | Subclass| World
------------+--------+---------+---------+------
public      |   x    |    x    |    x    |   x
------------+--------+---------+---------+------
protected   |   x    |    x    |    x    |   .
------------+--------+---------+---------+------
no modifier |   x    |    x    |    .    |   .
------------+--------+---------+---------+------
private     |   x    |    .    |    .    |   .    
------------------------------------------------ */
/**
 * ESEMPI IN JAVA Prof. Marco Sechi
 * https://www.brescianet.com/appunti/programmazione/java/java.htm
 * @author Andrea_Sergiacomi
 */
// la classe firma il contratto con l'interfaccia
    // deve quindi obbligatoriamente definirne tutti i metodi (Circonferenza e Area)
    // può aggiungerne altri (StampaRaggio)
    // Una classe puo' implementare piu' interfacce contemporaneamente
public class CERCHIO_classe implements CERCHIO_interfaccia, Comparable<CERCHIO_classe> {

    protected double Raggio;
    /* Costruttore */
    public CERCHIO_classe(double r)
    {
        Raggio = r;
    }

    //@Override
    public double Circonferenza()
    {
        return 2*Raggio*Math.PI;
    }
    public double Area()
    {
        return (Raggio*Raggio*Math.PI);
    }
    // this serve per eliminare la confusione tra attributi della classe
    // e i parametri con lo stesso nome
    // (tipicamente perché un attributo della classe è oscurato
    // da un parametro di metodo o costruttore).
    public double StampaRaggio() {this.Raggio = Raggio;
    return Raggio;}

    @Override
    public int compareTo(CERCHIO_classe o) {
        return 0;
    }
}