package it.unicam.cs.asdl2526.slides.javaeoop;
//package comparable;

// FACCIO TEST MANUALE - NON USO FRAMEWORK JUNI5
//import static org.junit.jupiter.api.Assertions.*;
//import org.junit.jupiter.api.Test;

import org.junit.platform.commons.util.ToStringBuilder;

public class CERCHIO_classeTest {
    //@Test
    public static void main(String[] args) {
        CERCHIO_classe cerchio1 = new CERCHIO_classe(2);
        CERCHIO_classe cerchio2 = new CERCHIO_classe(3);
        CERCHIO_classe cerchio3 = new CERCHIO_classe(2);

        System.out.println("cerchio1.compareTo(cerchio2)<0 " + (cerchio1.compareTo(cerchio2)<0));
        System.out.println("/ncerchio1.compareTo(cerchio3)==0 " + (cerchio1.compareTo(cerchio3)==0));
        System.out.println("/ncerchio2.compareTo(cerchio3)>0 " + (cerchio2.compareTo(cerchio3)>0));

        if  (cerchio1.compareTo(cerchio2)<0){
            System.out.println("/nl'area di cerchio1 " + cerchio1.Area() + " è più piccola dell'area di cerchio2 " + cerchio2.Area());}

        if  (cerchio1.compareTo(cerchio3)==0){
            System.out.println("/nl'area di cerchio1 " + cerchio1.Area() + " è uguale all'area di cerchio3 " + cerchio3.Area());}

        if  (cerchio2.compareTo(cerchio3)>0){
            System.out.println("/nl'area di cerchio2 " + cerchio2.Area() + " è più grande dell'area di cerchio3 " + cerchio3.Area());}
    }
}
