package it.unicam.cs.asdl2526.slides.javaeoop;/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

import java.io.*; // Import necessario per lo stream di input

/**
 *
 * @author Andrea_Sergiacomi
 */
public class ContaMaiuscole {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
                // Impostazione per lo standard input
        InputStreamReader input = new InputStreamReader(System.in);
        BufferedReader Tastiera = new BufferedReader(input);
        String TestoLetto;
        
        // INPUT
        try {
               System.out.print("Digita la stringa: ");
               TestoLetto=Tastiera.readLine();
        }
        catch (Exception e) {
            return;
        }
        // ALGORITMO
        int  NrMaiuscole=0;
        for (int i=0; i <TestoLetto.length() ; i++)
        {
            if (TestoLetto.charAt(i)>='A' && TestoLetto.charAt(i)<='Z' )
                NrMaiuscole++;
        }
        
        // OUTPUT
        if (NrMaiuscole>0)
           System.out.println("Il numero di lettere maiuscole e': "+NrMaiuscole);
        else
           System.out.println("Non ho nessuna lettera maiuscola");
    }
}
