package it.unicam.cs.asdl2526.slides.javaeoop;

// Una coppia chiave-valore generica: può contenere qualsiasi combinazione di tipi.
public class Generics_Pair<K, V> {
    private K key;
    private V value;

    public Generics_Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey()   { return key; }
    public V getValue() { return value; }

    @Override
    public String toString() {
        return "(" + key + ", " + value + ")";
    }

}