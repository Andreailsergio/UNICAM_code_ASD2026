package it.unicam.cs.asdl2526.slides.javaeoop;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author Andrea_Sergiacomi
 */
public class CERCHIO_calcolo
{
    public static void main(String args[]) {
        // TODO code application logic here
        // variabile di tipo interfaccia (Measurable)
        // -> può accedere solo ai metodi dell'interfaccia
        CERCHIO_interfaccia c = new CERCHIO_classe(5);
        System.out.println("Circonferenza: " + c.Circonferenza());
        System.out.println("Area         : " + c.Area());
        CERCHIO_classe c2 = new CERCHIO_classe(5);
        if (c2 instanceof CERCHIO_classe) {
            // CAST esplicito altrimenti StampaRaggio() da errore
            // perchè il metodo non c'è in CERCHIO_interfaccia
            c2 = (CERCHIO_classe) c;
        }
        System.out.println("Raggio       : " + c2.StampaRaggio());

        // POLIMORFISMO
        // una variabile di tipo interfaccia (Measurable)
        // può contenere qualsiasi oggetto (CERCHIO_class CERCHIO2_class etc.)
        // di una classe che implementa quell'interfaccia
        CERCHIO_interfaccia c3 = new CERCHIO2_class(10);
        System.out.println("Circonferenza: " + c3.Circonferenza());
        System.out.println("Area         : " + c3.Area());
        CERCHIO2_class c4 = new CERCHIO2_class(10);;
        if (c4 instanceof CERCHIO2_class) {
            c4 = (CERCHIO2_class) c3;
        }
        System.out.println("PI greco     : " + c4.StampaPigreco());
        System.out.println("Raggio       : " + 10);
    }
}
