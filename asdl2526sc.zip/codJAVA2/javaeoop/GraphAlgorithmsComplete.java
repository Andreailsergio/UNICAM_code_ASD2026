package it.unicam.cs.asdl2526.slides.javaeoop;

import java.util.*;

/**
 * Implementazione dei principali algoritmi su grafi:
 *   - Prim      (MST)           O(E log V)
 *   - Kruskal   (MST)           O(E log V)
 *   - Dijkstra  (cammini minimi, pesi ≥ 0)   O(E log V)
 *   - Bellman-Ford (cammini minimi, pesi qualsiasi) O(VE)
 *
 * Grafo di esempio (A–F, non orientato pesato):
 *   A–B(4), A–C(2), B–C(6), B–D(5), B–E(3)
 *   C–E(7), D–E(1), D–F(8), E–F(4)
 *
 * Risultati attesi (dalle animazioni del corso):
 *   Kruskal/Prim MST = {D–E(1), A–C(2), B–E(3), A–B(4), E–F(4)} peso=14
 *   Dijkstra da A: A=0, B=4, C=2, D=8, E=7, F=11
 */

// ══════════════════════════════════════════════════════════
//  Strutture dati di supporto
// ══════════════════════════════════════════════════════════

/** Arco pesato (può essere orientato o non orientato a seconda del grafo). */
class WeightedEdge implements Comparable<WeightedEdge> {
    final String u, v;
    final int weight;

    WeightedEdge(String u, String v, int weight) {
        this.u = u; this.v = v; this.weight = weight;
    }

    @Override public int compareTo(WeightedEdge o) {
        return Integer.compare(this.weight, o.weight);
    }

    @Override public String toString() {
        return u + "–" + v + "(" + weight + ")";
    }
}

/** Voce della min-heap per Prim e Dijkstra. */
class HeapEntry implements Comparable<HeapEntry> {
    final String vertex;
    final int key;

    HeapEntry(String vertex, int key) {
        this.vertex = vertex; this.key = key;
    }

    @Override public int compareTo(HeapEntry o) {
        return Integer.compare(this.key, o.key);
    }
}

// ══════════════════════════════════════════════════════════
//  Risultati degli algoritmi (oggetti restituiti dai metodi)
// ══════════════════════════════════════════════════════════

/** Risultato di Kruskal o Prim: lista di archi MST + peso totale. */
class MSTResult {
    final List<WeightedEdge> edges;
    final int totalWeight;

    MSTResult(List<WeightedEdge> edges, int totalWeight) {
        this.edges = Collections.unmodifiableList(edges);
        this.totalWeight = totalWeight;
    }

    @Override public String toString() {
        return "MST archi=" + edges + "  peso totale=" + totalWeight;
    }
}

/** Risultato di Dijkstra o Bellman-Ford: distanze + predecessori. */
class ShortestPathResult {
    /** Distanza minima dalla sorgente. Integer.MAX_VALUE = ∞ (non raggiungibile). */
    final Map<String, Integer> dist;
    /** Predecessore nel cammino minimo. */
    final Map<String, String>  pred;
    /** true se è stato rilevato un ciclo di peso negativo (solo Bellman-Ford). */
    final boolean negativeCycle;

    ShortestPathResult(Map<String, Integer> dist,
                       Map<String, String>  pred,
                       boolean negativeCycle) {
        this.dist          = Collections.unmodifiableMap(dist);
        this.pred          = Collections.unmodifiableMap(pred);
        this.negativeCycle = negativeCycle;
    }

    /** Ricostruisce il cammino dalla sorgente a dst come lista di vertici. */
    public List<String> path(String src, String dst) {
        if (!dist.containsKey(dst) || dist.get(dst) == Integer.MAX_VALUE)
            return Collections.emptyList();
        LinkedList<String> p = new LinkedList<>();
        for (String cur = dst; cur != null; cur = pred.get(cur))
            p.addFirst(cur);
        return p;
    }

    @Override public String toString() {
        return "dist=" + dist + (negativeCycle ? "  [CICLO NEGATIVO]" : "");
    }
}

// ══════════════════════════════════════════════════════════
//  Grafo con liste di adiacenza
// ══════════════════════════════════════════════════════════

/**
 * Grafo rappresentato con mappe di adiacenza.
 * Supporta sia grafi orientati che non orientati;
 * i metodi MST (Prim, Kruskal) assumono grafo NON orientato,
 * i metodi di cammino minimo (Dijkstra, Bellman-Ford) assumono grafo ORIENTATO
 * (o non orientato con archi simmetrici).
 */
class GraphComplete {

    // adj: vertice → lista di (indice vicino, peso)
    private final Map<String, List<int[]>> adj      = new LinkedHashMap<>();
    private final List<String>             vertices = new ArrayList<>();
    // Tutti gli archi (non orientati, per Kruskal)
    private final List<WeightedEdge>       edges    = new ArrayList<>();

    // ── Costruzione ──────────────────────────────────────

    public void addVertex(String v) {
        if (!adj.containsKey(v)) {
            adj.put(v, new ArrayList<>());
            vertices.add(v);
        }
    }

    /**
     * Aggiunge un arco NON orientato (entrambe le direzioni).
     * Usato per MST (Prim/Kruskal) e per Dijkstra su grafi non orientati.
     */
    public void addUndirectedEdge(String u, String v, int w) {
        addVertex(u); addVertex(v);
        adj.get(u).add(new int[]{indexOf(v), w});
        adj.get(v).add(new int[]{indexOf(u), w});
        edges.add(new WeightedEdge(u, v, w));
    }

    /**
     * Aggiunge un arco ORIENTATO (solo la direzione u→v).
     * Usato per Dijkstra/Bellman-Ford su grafi orientati.
     */
    public void addDirectedEdge(String u, String v, int w) {
        addVertex(u); addVertex(v);
        adj.get(u).add(new int[]{indexOf(v), w});
        edges.add(new WeightedEdge(u, v, w));
    }

    // ── Accesso ──────────────────────────────────────────

    public List<String>       getVertices() { return Collections.unmodifiableList(vertices); }
    public List<WeightedEdge> getEdges()    { return Collections.unmodifiableList(edges); }

    public List<int[]> adjOf(String v) {
        return adj.getOrDefault(v, Collections.emptyList());
    }

    public String nameOf(int idx) { return vertices.get(idx); }

    private int indexOf(String v) {
        int i = vertices.indexOf(v);
        if (i < 0) throw new IllegalArgumentException("Vertice non trovato: " + v);
        return i;
    }

    // ══════════════════════════════════════════════════════
    //  KRUSKAL  —  MST  —  O(E log V)
    // ══════════════════════════════════════════════════════

    /**
     * Algoritmo di Kruskal.
     * Ordina tutti gli archi per peso crescente e accetta un arco se collega
     * due componenti distinte (Union-Find con union-by-rank + path compression).
     *
     * @return MSTResult con gli archi dell'MST e il peso totale
     */
    public MSTResult kruskal() {
        // 1. Ordina archi per peso
        List<WeightedEdge> sorted = new ArrayList<>(edges);
        Collections.sort(sorted);

        // 2. Inizializza Union-Find
        Map<String, String>  parent = new HashMap<>();
        Map<String, Integer> rank   = new HashMap<>();
        for (String v : vertices) { parent.put(v, v); rank.put(v, 0); }

        List<WeightedEdge> mst   = new ArrayList<>();
        int                total = 0;

        // 3. Scansione archi
        for (WeightedEdge e : sorted) {
            String ru = ufFind(parent, e.u);
            String rv = ufFind(parent, e.v);
            if (!ru.equals(rv)) {          // componenti diverse: accetto
                mst.add(e);
                total += e.weight;
                ufUnion(parent, rank, ru, rv);
            }
            if (mst.size() == vertices.size() - 1) break; // MST completo
        }
        return new MSTResult(mst, total);
    }

    // Union-Find — find con path compression
    private String ufFind(Map<String, String> parent, String v) {
        if (!parent.get(v).equals(v))
            parent.put(v, ufFind(parent, parent.get(v)));
        return parent.get(v);
    }

    // Union-Find — union by rank
    private void ufUnion(Map<String, String> parent,
                         Map<String, Integer> rank,
                         String u, String v) {
        int ru = rank.get(u), rv = rank.get(v);
        if      (ru < rv) parent.put(u, v);
        else if (ru > rv) parent.put(v, u);
        else { parent.put(v, u); rank.put(u, ru + 1); }
    }

    // ══════════════════════════════════════════════════════
    //  PRIM  —  MST  —  O((V+E) log V) con heap binario
    // ══════════════════════════════════════════════════════

    /**
     * Algoritmo di Prim.
     * Cresce l'MST un vertice alla volta partendo da root:
     * ad ogni passo aggiunge il vertice connesso con l'arco di peso minimo
     * verso l'albero già costruito.
     *
     * @param root vertice di partenza
     * @return MSTResult con gli archi dell'MST e il peso totale
     */
    public MSTResult prim(String root) {
        Map<String, Integer> key    = new HashMap<>();   // arco minimo verso l'albero
        Map<String, String>  parent = new HashMap<>();   // predecessore nell'MST
        Set<String>          inMST  = new HashSet<>();

        for (String v : vertices) { key.put(v, Integer.MAX_VALUE); parent.put(v, null); }
        key.put(root, 0);

        PriorityQueue<HeapEntry> pq = new PriorityQueue<>();
        pq.add(new HeapEntry(root, 0));

        List<WeightedEdge> mstEdges = new ArrayList<>();
        int total = 0;

        while (!pq.isEmpty()) {
            HeapEntry e = pq.poll();
            String    u = e.vertex;

            if (inMST.contains(u)) continue;   // già nell'albero
            inMST.add(u);

            if (parent.get(u) != null) {
                int w = key.get(u);
                mstEdges.add(new WeightedEdge(parent.get(u), u, w));
                total += w;
            }

            // Aggiorna le chiavi dei vicini non ancora nell'MST
            for (int[] edge : adjOf(u)) {
                String v = nameOf(edge[0]);
                int    w = edge[1];
                if (!inMST.contains(v) && w < key.get(v)) {
                    key.put(v, w);
                    parent.put(v, u);
                    pq.add(new HeapEntry(v, w));
                }
            }
        }
        return new MSTResult(mstEdges, total);
    }

    // ══════════════════════════════════════════════════════
    //  DIJKSTRA  —  cammini minimi  —  O((V+E) log V)
    //  Requisito: pesi non negativi
    // ══════════════════════════════════════════════════════

    /**
     * Algoritmo di Dijkstra.
     * Estrae iterativamente il vertice con distanza minima dalla coda
     * e rilassa tutti gli archi uscenti.
     *
     * @param src sorgente
     * @return ShortestPathResult con distanze e predecessori
     * @throws IllegalArgumentException se src non è nel grafo
     */
    public ShortestPathResult dijkstra(String src) {
        if (!adj.containsKey(src))
            throw new IllegalArgumentException("Sorgente non trovata: " + src);

        Map<String, Integer> dist    = new HashMap<>();
        Map<String, String>  pred    = new HashMap<>();
        Set<String>          settled = new HashSet<>();

        for (String v : vertices) { dist.put(v, Integer.MAX_VALUE); pred.put(v, null); }
        dist.put(src, 0);

        PriorityQueue<HeapEntry> pq = new PriorityQueue<>();
        pq.add(new HeapEntry(src, 0));

        while (!pq.isEmpty()) {
            HeapEntry e = pq.poll();
            String    u = e.vertex;

            if (settled.contains(u)) continue;
            settled.add(u);

            for (int[] edge : adjOf(u)) {
                String v    = nameOf(edge[0]);
                int    w    = edge[1];
                int    newD = dist.get(u) + w;

                if (newD < dist.get(v)) {
                    dist.put(v, newD);
                    pred.put(v, u);
                    pq.add(new HeapEntry(v, newD));
                }
            }
        }
        return new ShortestPathResult(dist, pred, false);
    }

    // ══════════════════════════════════════════════════════
    //  BELLMAN-FORD  —  cammini minimi  —  O(VE)
    //  Funziona con pesi negativi; rileva cicli negativi
    // ══════════════════════════════════════════════════════

    /**
     * Algoritmo di Bellman-Ford.
     * Rilassa tutti gli archi |V|−1 volte.
     * Dopo |V|−1 iterazioni, se un ulteriore rilassamento è ancora possibile,
     * esiste un ciclo di peso negativo raggiungibile da src.
     *
     * @param src sorgente
     * @return ShortestPathResult; negativeCycle=true se ciclo negativo rilevato
     * @throws IllegalArgumentException se src non è nel grafo
     */
    public ShortestPathResult bellmanFord(String src) {
        if (!adj.containsKey(src))
            throw new IllegalArgumentException("Sorgente non trovata: " + src);

        Map<String, Integer> dist = new HashMap<>();
        Map<String, String>  pred = new HashMap<>();

        for (String v : vertices) { dist.put(v, Integer.MAX_VALUE); pred.put(v, null); }
        dist.put(src, 0);

        int n = vertices.size();

        // |V| − 1 passate di rilassamento su tutti gli archi
        for (int i = 1; i < n; i++) {
            boolean updated = false;
            for (WeightedEdge e : edges) {
                if (dist.get(e.u) != Integer.MAX_VALUE) {
                    int newD = dist.get(e.u) + e.weight;
                    if (newD < dist.get(e.v)) {
                        dist.put(e.v, newD);
                        pred.put(e.v, e.u);
                        updated = true;
                    }
                }
            }
            if (!updated) break;  // convergenza anticipata
        }

        // Verifica ciclo negativo: se dopo |V|−1 passate si riesce ancora a rilassare
        boolean negativeCycle = false;
        for (WeightedEdge e : edges) {
            if (dist.get(e.u) != Integer.MAX_VALUE &&
                dist.get(e.u) + e.weight < dist.get(e.v)) {
                negativeCycle = true;
                break;
            }
        }

        return new ShortestPathResult(dist, pred, negativeCycle);
    }
}

// ══════════════════════════════════════════════════════════
//  Main — demo di tutti e quattro gli algoritmi
// ══════════════════════════════════════════════════════════

public class GraphAlgorithmsComplete {

    public static void main(String[] args) {

        // ── Grafo non orientato pesato (per Prim e Kruskal) ────────────────────
        // Esempio del corso: A–F con pesi noti
        GraphComplete gUnd = new GraphComplete();
        gUnd.addUndirectedEdge("A", "B", 4);
        gUnd.addUndirectedEdge("A", "C", 2);
        gUnd.addUndirectedEdge("B", "C", 6);
        gUnd.addUndirectedEdge("B", "D", 5);
        gUnd.addUndirectedEdge("B", "E", 3);
        gUnd.addUndirectedEdge("C", "E", 7);
        gUnd.addUndirectedEdge("D", "E", 1);
        gUnd.addUndirectedEdge("D", "F", 8);
        gUnd.addUndirectedEdge("E", "F", 4);

        // ── KRUSKAL ─────────────────────────────────────────────────────────────
        System.out.println("════════════════════════════════════");
        System.out.println(" KRUSKAL — Minimo Albero di Copertura");
        System.out.println("════════════════════════════════════");
        MSTResult kResult = gUnd.kruskal();
        System.out.println(kResult);
        // Atteso: archi {D–E(1), A–C(2), B–E(3), A–B(4), E–F(4)}  peso=14

        // ── PRIM ────────────────────────────────────────────────────────────────
        System.out.println("\n════════════════════════════════════");
        System.out.println(" PRIM — Minimo Albero di Copertura (radice A)");
        System.out.println("════════════════════════════════════");
        MSTResult pResult = gUnd.prim("A");
        System.out.println(pResult);
        // Atteso: stesso MST di Kruskal, peso=14

        // ── Grafo non orientato pesato (stessa struttura, usata per Dijkstra) ──
        GraphComplete gDij = new GraphComplete();
        gDij.addUndirectedEdge("A", "B", 4);
        gDij.addUndirectedEdge("A", "C", 2);
        gDij.addUndirectedEdge("B", "C", 6);
        gDij.addUndirectedEdge("B", "D", 5);
        gDij.addUndirectedEdge("B", "E", 3);
        gDij.addUndirectedEdge("C", "E", 7);
        gDij.addUndirectedEdge("D", "E", 1);
        gDij.addUndirectedEdge("D", "F", 8);
        gDij.addUndirectedEdge("E", "F", 4);

        // ── DIJKSTRA ────────────────────────────────────────────────────────────
        System.out.println("\n════════════════════════════════════");
        System.out.println(" DIJKSTRA — Cammini minimi da A");
        System.out.println("════════════════════════════════════");
        ShortestPathResult dResult = gDij.dijkstra("A");
        System.out.println(dResult);
        System.out.println("Cammino A→D: " + dResult.path("A", "D"));
        System.out.println("Cammino A→F: " + dResult.path("A", "F"));
        // Atteso: A=0, B=4, C=2, D=8, E=7, F=11

        // ── BELLMAN-FORD: grafo con pesi negativi ───────────────────────────────
        // Esempio da Cormen Fig 25.7: s,t,x,y,z con archi orientati
        System.out.println("\n════════════════════════════════════");
        System.out.println(" BELLMAN-FORD — Cammini minimi da s (pesi negativi)");
        System.out.println("════════════════════════════════════");
        GraphComplete gBF = new GraphComplete();
        gBF.addDirectedEdge("s", "t",  6);
        gBF.addDirectedEdge("s", "y",  7);
        gBF.addDirectedEdge("t", "x",  5);
        gBF.addDirectedEdge("t", "y",  8);
        gBF.addDirectedEdge("t", "z", -4);
        gBF.addDirectedEdge("x", "t", -2);
        gBF.addDirectedEdge("y", "x", -3);
        gBF.addDirectedEdge("y", "z",  9);
        gBF.addDirectedEdge("z", "s",  2);
        gBF.addDirectedEdge("z", "x",  7);

        ShortestPathResult bfResult = gBF.bellmanFord("s");
        System.out.println(bfResult);
        System.out.println("Ciclo negativo: " + bfResult.negativeCycle);
        System.out.println("Cammino s→z: " + bfResult.path("s", "z"));
        // Atteso: s=0, t=2, x=4, y=7, z=-2

        // ── BELLMAN-FORD: rilevamento ciclo negativo ─────────────────────────────
        System.out.println("\n════════════════════════════════════");
        System.out.println(" BELLMAN-FORD — Rilevamento ciclo negativo");
        System.out.println("════════════════════════════════════");
        GraphComplete gNeg = new GraphComplete();
        gNeg.addDirectedEdge("A", "B",  1);
        gNeg.addDirectedEdge("B", "C", -3);
        gNeg.addDirectedEdge("C", "A",  1);  // ciclo A→B→C→A con peso -1
        ShortestPathResult negResult = gNeg.bellmanFord("A");
        System.out.println("Ciclo negativo rilevato: " + negResult.negativeCycle);
        // Atteso: true
    }
}
