package it.unicam.cs.asdl2526.slides.javaeoop;

import java.awt.Rectangle;

public class RETTANGOLO_calcolo {
    public static void main(String args[]) {
        // TODO code application logic here
        RETTANGOLO_strategico ds = new RETTANGOLO_strategico(new RETTANGOLOMisuratore_classe());
        // add(x) → accumula somme
        ds.add(new Rectangle(3,4)); // area = 12
        System.out.println("Area 1                 : " + 12 + " 3 x 4");
        ds.add(new Rectangle(5,2)); // area = 10
        System.out.println("Area 2                 : " + 10 + " 5 x 2");
        // restituisce media delle aree
        System.out.println("Media delle aree       : " + ds.getAverage());
    }
}
