package it.unicam.cs.asdl2526.slides.javaeoop;

// Generics_CalculatorUtils
import java.util.List;
import java.util.ArrayList;

public class Generics_CalculatorUtils {

    // metodo generico statico che trova il massimo tra due valori qualsiasi, purché siano confrontabili
    public static <T extends Comparable<T>> T max(T a, T b) {
        return a.compareTo(b) >= 0 ? a : b;
    }

    // Il metodo stampaLista con l'uso della Wildcard List<?>
    //      -> non importa il tipo, leggo solo come Object
    // 1. Wildcard unbounded: accetta List di qualsiasi tipo
    public static void stampaLista(List<?> lista) {
        for (Object elem : lista) {
            System.out.print(elem + " ");
        }
        System.out.println();
    }

    // Il metodo somma con l'uso della Wildcard List<?> BOUNDED a tipi numerici
    //      -> vincolo garantendo che gli elementi siano solo del macro-tipo che desidero
    //         Utile in fase di lettura
    // 2. Upper bound: accetta List di Number o qualsiasi suo sottotipo
    //    (Integer, Double, Float...)
    //    ci permette di chiamare .doubleValue() garantito da Number
    public static double somma(List<? extends Number> lista) {
        double totale = 0;
        for (Number n : lista) {
            totale += n.doubleValue();
        }
        return totale;
    }

    // Il metodo aggiungiRisultati
    //      -> se voglio che il metodo possa aggiungere degli Integer alla lista usare List<Integer> funzionerebbe
    //         ma sarebbe troppo restrittivo, non m i permetterebbe di aggiungere List<Number> più generali
    //         List<? super Integer> permette di funzionare con qualsiasi super tipo di Integer (Interni, Numeri o Oggetti)
    //         E' utile per accettare qualsiasi tipo in scrittura, ma in fase di lettura mi verrà restituito un tipo Object
    //         (non saprò se sia un Integer, un Number o cos'altro)
    //      -> acronimo PECS: Producer Extends, Consumer Super.
    //         Se la lista produce elementi che tu leggi usa → extends.
    //         Se la lista consuma elementi che tu aggiungi usa → super
    // 3. Lower bound: accetta List<Integer> o List di qualsiasi supertipo
    //    (List<Number>, List<Object>)
    //    utile quando vuoi AGGIUNGERE elementi Integer o di qualsiasi altro tipo alla lista
    public static void aggiungiRisultati(List<? super Integer> lista) {
        lista.add(10);
        lista.add(20);
        lista.add(30);
    }
}