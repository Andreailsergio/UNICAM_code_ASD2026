package it.unicam.cs.asdl2526.slides.javaeoop;
import java.util.ArrayList;
import java.util.List;

public class Generics_Main {
    public static void main(String[] args) {

        // --- 0. Pair con tipi diversi ---
        System.out.println("0. Pair con tipi diversi");
        // chiave = nome calcolatrice, valore = risultato
        System.out.println("variabile risultato -> chiave = nome calcolatrice, valore = risultato: ");
        Generics_Pair<String, Double> risultato = new Generics_Pair<>("Texas", 42.0);
        System.out.println(risultato.getKey());   // "Texas"
        System.out.println(risultato.getValue()); // 42.0

        // chiave = nome operazione, valore = numero di volte usata
        System.out.println("variabile contatore -> chiave = nome operazione, valore = numero di volte usata: ");
        Generics_Pair<String, Integer> contatore = new Generics_Pair<>("add", 5);
        System.out.println(contatore); // "(add, 5)"

        // chiave = calcolatrice, valore = calcolatrice scientifica
        System.out.println("variabile coppia -> chiave = calcolatrice standard, valore = calcolatrice scientifica: ");
        Generics_Pair<CALCULATOR, SCIENTIFICCALCULATOR> coppia = new Generics_Pair<>(
                new CALCULATOR("Base"),
                new SCIENTIFICCALCULATOR("Texas", 4)
        );
        System.out.println("Lavorando con la variabile coppia (che si porta dietro gli oggetti CALCULATOR + SCIENTIFICCALCULATOR) ");
        System.out.println("Prendo in input 10 e lo stampo. ");
        coppia.getKey().add(10);
        System.out.println(coppia.getKey().getResult());   // 10.0
        System.out.println("Poi, dato 9, faccio la radice quadrata e sottraggo -18,45, stampando il risultato negativo. ");
        coppia.getValue().add(9);
        coppia.getValue().sqrt();
        coppia.getValue().subtract(18.45);
        System.out.println(coppia.getValue().getResult()+"\n"); // 3.0 - 18.45 = -15.45


        // --- 1. Wildcard unbounded List<?> ---
        System.out.println("1. Wildcard unbounded List<?>");
        // stampaLista accetta qualsiasi tipo di lista
        List<String>  nomi    = new ArrayList<>();
        List<Integer> numeri  = new ArrayList<>();
        List<Double>  decimali = new ArrayList<>();

        nomi.add("Texas"); nomi.add("Casio"); nomi.add("Base");
        numeri.add(10); numeri.add(20); numeri.add(30);
        decimali.add(1.5); decimali.add(2.7); decimali.add(3.9);
        System.out.println("LISTA nomi: ");
        Generics_CalculatorUtils.stampaLista(nomi);     // Texas Casio Base
        System.out.println("LISTA numeri: ");
        Generics_CalculatorUtils.stampaLista(numeri);   // 10 20 30
        System.out.println("LISTA decimali: ");
        Generics_CalculatorUtils.stampaLista(decimali); // 1.5 2.7 3.9
        System.out.println("\n");

        // --- 2. Upper bound List<? extends Number> ---
        System.out.println("2. Upper bound List<? extends Number>");
        // somma() funziona con Integer, Double, Float...
        // ma NON con String (non è sottotipo di Number)
        List<Integer> interi  = new ArrayList<>();
        List<Double>  doppi   = new ArrayList<>();

        interi.add(5); interi.add(10); interi.add(15);
        doppi.add(1.1); doppi.add(2.2); doppi.add(3.3);

        System.out.println("sommo 5 + 10 + 15 ");
        System.out.println(Generics_CalculatorUtils.somma(interi)); // 30.0
        System.out.println("sommo 1,1 + 2,2 + 3,3 ");
        System.out.println(Generics_CalculatorUtils.somma(doppi));  // 6.6
        System.out.println("se avessi provato a sommare la lista nomi, contenente stringhe, non sarei riuscito a compilare \n");
        // CalculatorUtils.somma(nomi); ← ❌ non compila: String non è Number


        // --- 3. Lower bound List<? super Integer> ---
        System.out.println("3. Lower bound List<? super Integer>");
        // aggiungiRisultati() accetta List<Integer>, List<Number>, List<Object>
        List<Integer> listaInt    = new ArrayList<>();
        List<Number>  listaNum    = new ArrayList<>();
        List<Object>  listaObj    = new ArrayList<>();

        System.out.println("sto chiamando il metodo aggiungiRisultati per inserire nella lista 10 20 30 ");
        System.out.println("nella 1° lista in quanto interi, nella 2° in quanto numeri, nella 3° in quanto oggetti ");
        Generics_CalculatorUtils.aggiungiRisultati(listaInt); // ✅
        Generics_CalculatorUtils.aggiungiRisultati(listaNum); // ✅ Number è supertipo di Integer
        Generics_CalculatorUtils.aggiungiRisultati(listaObj); // ✅ Object è supertipo di Integer
        System.out.println("quale che sia il tipo l'inserimento è andato a buon fine: ecco cosa c'è nelle 3 liste ");
        Generics_CalculatorUtils.stampaLista(listaInt); // 10 20 30
        Generics_CalculatorUtils.stampaLista(listaNum); // 10 20 30
        Generics_CalculatorUtils.stampaLista(listaObj); // 10 20 30
        System.out.println("non avrei potuto fare il giochetto con dei Double -> che non sono supertipi di Integer ");
        // CalculatorUtils.aggiungiRisultati(doppi); ← ❌ non compila:
        //   Double non è supertipo di Integer
    }
}
