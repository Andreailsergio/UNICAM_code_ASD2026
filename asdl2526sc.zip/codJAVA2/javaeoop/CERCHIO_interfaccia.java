package it.unicam.cs.asdl2526.slides.javaeoop;
// Interfaccia: solo la firma, nessuna implementazione
// è un contratto che una classe può sottoscrivere
public abstract interface CERCHIO_interfaccia {
    // metodi astratti (automaticamente public)
    double Circonferenza();
    double Area();
}