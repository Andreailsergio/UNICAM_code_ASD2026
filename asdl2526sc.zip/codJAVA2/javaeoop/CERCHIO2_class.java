package it.unicam.cs.asdl2526.slides.javaeoop;

public class CERCHIO2_class implements CERCHIO_interfaccia
{
    private final double Raggio;
    private double Pigreco;

    public CERCHIO2_class(double r) {Raggio = r;}
    @Override
    public double Circonferenza()
    {
        return 2*Raggio*Math.PI;
    }
    public double Area()
    {
        return (Raggio*Raggio*Math.PI);
    }
    public double StampaPigreco() {this.Pigreco = Math.PI;return this.Pigreco;}
}
