package it.unicam.cs.asdl2526.slides.javaeoop;
import java.io.*;
public class ECCEZIONI_methodCALC_LOADER {
    // questo metodo NON gestisce IOException: la propaga al chiamante
    public double leggiValore(String nomeFile) throws IOException {
        BufferedReader in = new BufferedReader(new FileReader(nomeFile));
        String riga = in.readLine();
        in.close();
        return Double.parseDouble(riga);
    }

    // il chiamante deve gestirla
    public void avvia() {
        try {
            double valore = leggiValore("dati.txt");
            System.out.println("Valore letto: " + valore);
        } catch (IOException e) {
            System.out.println("Errore lettura file: " + e.getMessage());
        }
    }
}
