package it.unicam.cs.asdl2526.slides.javaeoop;

public class CALC_MAIN {
    public static void main(String[] args) {
        // uso la Superclasse CALCULATOR
        CALCULATOR c = new CALCULATOR("Casio");
        System.out.println("SUPERCLASSE CALCULATOR: " +c.getName());
        c.add(10);
        c.multiply(3);
        System.out.println("10 x 3 ");
        System.out.println(c.getResult()); // 30.0

        // uso la sottoclasse SCIENTIFICCALCULATOR
        // con precision 2
        SCIENTIFICCALCULATOR sc = new SCIENTIFICCALCULATOR("Texas", 2);
        System.out.println("\nSOTTOCLASSE SCIENTIFIC CALCULATOR: " +sc.getName());
        sc.add(9);       // ereditato da Calculator
        sc.sqrt();       // metodo
        System.out.println("radice quadrata di 9 ");
        System.out.println(sc.getResult()); // 3.0
        sc.subtract(1);
        System.out.println("meno 1 ");
        System.out.println(sc.getResult()); // 2.0
        // con precision 4
        SCIENTIFICCALCULATOR sc2 = new SCIENTIFICCALCULATOR("Texas", 4);
        sc2.add(Math.PI);
        System.out.println("PI greco con 4 decimali ");
        System.out.println(sc2.getFormattedResult()); // "3.1416"

        // uso la sottoclasse LOGGINGCALCULATOR
        LOGGINGCALCULATOR lc = new LOGGINGCALCULATOR("Logger");
        System.out.println("\nSOTTOCLASSE LOGGING CALCULATOR: " +lc.getName());
        lc.add(20);     // stampa "Operazione #1: add(20.0)"
        System.out.println("divido 20 per 0 ");
        lc.divide(0);   // stampa "Errore: divisione per zero!"
        System.out.println("divido 20 per 4 ");
        lc.divide(4);   // funziona normalmente
        System.out.println(lc.getResult()); // 5.0
        System.out.println("Operazioni fatte: " + lc.getOperationCount()); // 2

        // Polimorfismo dinamico: array di Calculator che contiene tipi diversi
        CALCULATOR[] calcolatrici = {
                new CALCULATOR("Base"),
                new SCIENTIFICCALCULATOR("Texas", 2),
                new LOGGINGCALCULATOR("Logger")
        };

        System.out.println("\nTUTTI I CALCULATOR: ");
        for (CALCULATOR cn : calcolatrici) {
            System.out.println(cn.getName());
            cn.add(100); // ognuna esegue il SUO add()
            // Calculator  -> add normale
            // Scientific  -> add normale (non override)
            // Logging     -> add con stampa del log!

            cn.multiply(2);
            System.out.println("100 per 2 ");
            System.out.println(cn.getResult()+"\n"); // 200.0
        }

        // CAST e instanceof
        CALCULATOR c2 = new SCIENTIFICCALCULATOR("Texas", 4);

        // c2 è dichiarato Calculator: non puoi chiamare c2.sqrt() direttamente!
        // c2.sqrt(); ← ERRORE di compilazione

        // Prima verifichi, poi fai il cast
        if (c2 instanceof SCIENTIFICCALCULATOR) {
            SCIENTIFICCALCULATOR sc3 = (SCIENTIFICCALCULATOR) c2; // cast esplicito
            sc3.add(16);
            sc3.sqrt();
            System.out.println("\nRADICE QUADRATA DI 16 con SCIENTIFICACALCULATOR CASTATO: "+sc3.getName());
            System.out.println(sc3.getResult()); // 4.0
        }

        // Esempio con LoggingCalculator
        CALCULATOR c3 = new LOGGINGCALCULATOR("Logger");
        System.out.println("\n50 - 40,5 con LOGGINGCALCULATOR CASTATO: "+c3.getName());
        c3.add(50);
        c3.subtract(40.5);
        if (c3 instanceof LOGGINGCALCULATOR) {
            LOGGINGCALCULATOR lc2 = (LOGGINGCALCULATOR) c3;
            System.out.println("Operazioni fatte: " + lc2.getOperationCount()); // 1
            System.out.println(lc2.getResult()); // 9.5
        }
    }
}
