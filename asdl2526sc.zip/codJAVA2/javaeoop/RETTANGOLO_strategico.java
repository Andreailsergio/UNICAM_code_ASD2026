package it.unicam.cs.asdl2526.slides.javaeoop;

public class RETTANGOLO_strategico {
    private RETTANGOLO_interfaccia misuratore;
    private double somma;
    private int contatore;
    public RETTANGOLO_strategico(RETTANGOLO_interfaccia m) {
        this.misuratore = m;
    }
    public void add(Object x) {
        // chiama l'oggetto esterno (misuratore) per "misurare" il valore di x
        // (in questo caso l'area del rettangolo date le lunghezze dei lati)
        // e aggiunge il risultato alla somma totale
        // il punto chiave è che questo metodo non sa come misurare x
        // (lo chiede al misuratore, che invece lo sa -> delega)
        // (è il pattern strategy:
        // si può addirittura cambiare il criterio di misurazione
        // usando sempre questa classe)
        somma += misuratore.measure(x); // delega la misurazione
        contatore++; // incrementa il conteggio
    }
    public double getAverage() {
        // calcolo media aritmetica in modo incrementale
        // se contatore è 0 (nessun elemento) restituisce 0 per evitare divisione per 0
        // Altrimenti divide somma (delle aree del rettangolo) per contatore
        return contatore == 0 ? 0 : somma / contatore;
    }
}
