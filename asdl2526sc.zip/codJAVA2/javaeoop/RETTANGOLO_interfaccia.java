package it.unicam.cs.asdl2526.slides.javaeoop;

// Interfaccia strategica: chi la implementa SA misurare oggetti -> Measurer
public interface RETTANGOLO_interfaccia {
    double measure(Object anObject);
}
