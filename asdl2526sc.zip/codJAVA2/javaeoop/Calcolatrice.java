package it.unicam.cs.asdl2526.slides.javaeoop;

public class Calcolatrice {

    public int somma(int a, int b) {
        return a + b;
    }

    public boolean isPositivo(int n) {
        return n > 0;
    }

    public int dividi(int a, int b) {
        if (b == 0) throw new IllegalArgumentException("Divisione per zero!");
        return a / b;
    }

    // Restituisce una stringa con la descrizione divisore/dividendo e il risultato,
    // oppure null se b è zero
    public String descriviDivisione(int a, int b) {
        if (b == 0) return null;
        return a + " / " + b + " = " + (a / b);
    }
}
