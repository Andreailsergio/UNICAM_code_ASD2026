package it.unicam.cs.asdl2526.slides.javaeoop;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CalcolatriceTest {

    // @Test indica a JUnit che questo è un metodo di test
    @Test
    public void testSommaPositivi() {
        Calcolatrice calc = new Calcolatrice();
        int risultato = calc.somma(3, 4);
        assertEquals(7, risultato);  // verifica che 3+4 == 7
    }

    @Test
    public void testSommaConNegativo() {
        Calcolatrice calc = new Calcolatrice();
        assertEquals(-1, calc.somma(3, -4));
    }

    @Test
    public void testDivisioneNormale() {
        Calcolatrice calc = new Calcolatrice();
        assertEquals(5, calc.dividi(10, 2));
    }

    @Test
    public void testNumeriPositivi_Negativi() {
        Calcolatrice calc = new Calcolatrice();
        assertTrue(calc.isPositivo(5));    // passa se la condizione è TRUE;
        assertFalse(calc.isPositivo(-3));  // passa se la condizione è FALSE
    }

    @Test
    public void testDescriviDivisioneNull_NonNull() {
        Calcolatrice calc = new Calcolatrice();

        String risultato = calc.descriviDivisione(10, 2);
        assertNotNull(risultato);  // ✅ passa: risultato è "10 / 2 = 5", non null

        String risultato2 = calc.descriviDivisione(10, 0);
        assertNull(risultato2);     // ✅ passa: il metodo ritorna null quando b == 0
    }

    @Test
    public void testDivisionePerZeroLanciaEccezione() {
        Calcolatrice calc = new Calcolatrice();
        // assertThrows verifica che venga lanciata l'eccezione attesa
        assertThrows(IllegalArgumentException.class, () -> calc.dividi(10, 0));
    }
}
