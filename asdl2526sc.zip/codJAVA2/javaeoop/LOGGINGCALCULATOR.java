package it.unicam.cs.asdl2526.slides.javaeoop;

// SOTTOCLASSE: tiene un log di tutte le operazioni
public class LOGGINGCALCULATOR extends CALCULATOR {

    private int operationCount;

    public LOGGINGCALCULATOR(String name) {
        super(name);
        this.operationCount = 0;
    }

    @Override
    // aggiungo una funzione per contare le operazioni eseguite
    public void add(double n) {
        operationCount++;
        System.out.println("Operazione #" + operationCount + ": add(" + n + ")");
        super.add(n); // chiama il metodo ORIGINALE di Calculator
    }

    @Override
    // aggiungo il controllo della divisione per zero
    public void divide(double n) {
        if (n == 0) {
            System.out.println("Errore: divisione per zero!");
            return; // non fa nulla, lascia il risultato invariato
        }
        operationCount++;
        super.divide(n); // chiama il divide() di Calculator
    }

    public int getOperationCount() { return operationCount; }
}
