package it.unicam.cs.asdl2526.slides.javaeoop;

// SUPERCLASSE: calcolatrice base
public class CALCULATOR {
    private double result;   // risultato corrente (privato!)
    private String name;

    public CALCULATOR(String name) {
        this.name = name;
        this.result = 0.0;
    }

    public void add(double n)      { result += n; }
    public void subtract(double n) { result -= n; }
    public void multiply(double n) { result *= n; }
    public void divide(double n)   { result /= n; }
    public void divide_controllo_errore(double n)   {
        if (n == 0) {
            throw new ECCEZIONI_classDIV_ZERO(getResult()); // eccezione nostra
        }
        result /= n;
    }

    public double getResult() { return result; }
    public String getName()   { return name; }

    public void reset() { result = 0.0; }
}