package it.unicam.cs.asdl2526.slides.javaeoop;

// SOTTOCLASSE: aggiunge operazioni scientifiche
public class SCIENTIFICCALCULATOR extends CALCULATOR {

    private int precision; // NUOVA variabile istanza
    // servirà ad indicare il numero di cifre decimali da mostrare nel risultato
    public String getFormattedResult() {
        // "%.4f" con precision=4 → "3.1416"
        return String.format("%." + precision + "f", getResult());
    }

    public SCIENTIFICCALCULATOR(String name, int precision) {
        super(name);           // PRIMA RIGA: chiama il costruttore di CALCULATOR
        this.precision = precision;
    }

    // NB non posso scrivere codice che accede direttamente a result o name
    // (variabili private di CALCULATOR) sebbene tecnicamente sia un oggetto derivato
    // ma posso usare i metodi ereditati, come getResult() o add()
    /*
    * private significa:
    * "solo la classe che ha dichiarato questa variabile può toccarla"
    * é il principio dell'incapsulamento:
    * la Classe CALCULATOR protegge il suo stato interno e decide lei come gestirlo,
    * esponendo solo i metodi pubblici come "sportelli" controllati.
    * Le sottoclassi devono passare per quegli sportelli,
    * non possono entrare dalla finestra.
    * */

    // NUOVO metodo: eleva il risultato corrente alla potenza n
    public void power(double n) {
        double powered = Math.pow(getResult(), n); // getResult() è ereditato
        reset();                                   // reset() è ereditato
        add(powered);                              // add() è ereditato
    }

    // NUOVO metodo: radice quadrata del risultato corrente
    public void sqrt() {
        double root = Math.sqrt(getResult());
        reset();
        add(root);
    }

    public int getPrecision() { return precision; }
}
