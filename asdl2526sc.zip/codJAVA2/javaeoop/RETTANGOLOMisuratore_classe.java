package it.unicam.cs.asdl2526.slides.javaeoop;

import java.awt.Rectangle;

public class RETTANGOLOMisuratore_classe implements RETTANGOLO_interfaccia {
    @Override
    public double measure(Object anObject) {
        // cast necessario per usare Rectangle da libreria standard esterna
        Rectangle r = (Rectangle) anObject;
        return r.getWidth() * r.getHeight();
    }
}
