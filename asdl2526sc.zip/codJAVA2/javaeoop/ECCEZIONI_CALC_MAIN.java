package it.unicam.cs.asdl2526.slides.javaeoop;

import java.io.IOException;

public class ECCEZIONI_CALC_MAIN {
    public static void main(String[] args) {
        // uso la Superclasse CALCULATOR
        CALCULATOR c = new CALCULATOR("Casio");
        try {
            String input = "abc";
            double n = Double.parseDouble(input); // NumberFormatException
            c.add(n);
            c.divide(0);                          // IllegalArgumentException
        } catch (NumberFormatException e) {
            System.out.println("Input non valido: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            // questo secondo catch non viene mai raggiunto
            // perché un'eccezione è già stata eseguita dal precedente
            // dopo il quale si passa al FINALLY
            System.out.println("Operazione non valida: " + e.getMessage());
        } finally {
            // eseguito SEMPRE: qui azzeriamo la calcolatrice
            c.reset();
            System.out.println("Calcolatrice azzerata. Risultato: " + c.getResult());
        }

        // usare ECCEZIONI_methodCALC_LOADER
        ECCEZIONI_methodCALC_LOADER loader = new ECCEZIONI_methodCALC_LOADER();
        CALCULATOR c1 = new CALCULATOR("8088");
        // Scenario 1: il file esiste e contiene "42.0"
        // se da codice cerco un altro file inesistente con leggiValore() ma la prima lettura da dati.txt non va a buon fine
        // l'istruzione leggiValore("altri_dati.txt") non viene mai eseguita
        // ⚠️ così al primo errore salti tutto il resto
        try {
            double valore1 = loader.leggiValore("C:\\Users\\andrea_sergiacomi\\IdeaProjects\\OOP_base\\src\\main\\java\\it\\unicam\\cs\\asdl2526\\slides\\javaeoop\\dati.txt");
            double valore2 = loader.leggiValore("altri_dati.txt");
            c1.add(valore1);
            c1.add(valore2);
            System.out.println("Valore caricato: " + valore1);
            System.out.println("Valore caricato: " + valore2);
            System.out.println("Risultato calcolatrice: " + c1.getResult()); // 42.0
        } catch (IOException e) {
            System.out.println("File non trovato o illeggibile: " + e.getMessage());
            // se dati.txt fallisce, non si prova nemmeno altri_dati.txt
        }

        // Scenario 2: il file NON esiste e il TRY CATCH eè separato
        // Quale delle due strutture usare dipende dal contesto:
        // se i due valori sono indipendenti conviene il primo approccio,
        // se invece il secondo dipende dal primo ha senso il blocco unico.
        /*
        * SE GESTISCO CON TRY SEPARATO IL PROGRAMMA TERMINA CON ERRORE - non trovando inestistente.txt
        * Errore: inesistente.txt (Impossibile trovare il file specificato)
        * Programma terminato.
        * Exception in thread "main" it.unicam.cs.asdl2526.slides.javaeoop.ECCEZIONI_classDIV_ZERO:
        * Impossibile dividere 42.0 per zero
	    * at it.unicam.cs.asdl2526.slides.javaeoop.CALCULATOR.divide_controllo_errore(CALCULATOR.java:19)
	    * at it.unicam.cs.asdl2526.slides.javaeoop.ECCEZIONI_CALC_MAIN.main(ECCEZIONI_CALC_MAIN.java:74)
        *
        *
        try {
            double valore = loader.leggiValore("inesistente.txt");
            c1.add(valore);
        } catch (IOException e) {
            System.out.println("Errore: " + e.getMessage());
            // "Errore: inesistente.txt (No such file or directory)"
        }
        */

        // il programma continua normalmente in entrambi i casi
        System.out.println("Programma terminato.");


        // usare nel CATCH il metodo getDividendo() nella classe ECCEZIONI_classDIV_ZERO
        CALCULATOR c2 = new CALCULATOR("Base");
        c2.add(42);
        try {
            c2.divide(0);
            // Il vantaggio rispetto a usare IllegalArgumentException generica
            // è che il tipo ECCEZIONI_classDIV_ZERO è preciso e riconoscibile:
            // chi legge il codice capisce immediatamente di che errore si tratta,
            // e può catturarlo in modo selettivo con un suo catch dedicato
        } catch (ECCEZIONI_classDIV_ZERO e) {
            System.out.println(e.getMessage());
            // "Impossibile dividere 42.0 per zero"

            System.out.println("Stavi cercando di dividere: " + e.getDividendo());
            // "Stavi cercando di dividere: 42.0"
        }

        // richiamare direttamente il metodo divide() di ECCEZIONI_classDIV_ZERO
        // che implementa il controllo errori
        CALCULATOR c3 = new CALCULATOR("Base");
        c3.add(42);
        c3.divide_controllo_errore(0);
    }
}
