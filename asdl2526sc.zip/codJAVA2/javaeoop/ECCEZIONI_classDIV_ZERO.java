package it.unicam.cs.asdl2526.slides.javaeoop;

// Eccezione personalizzata NON controllata (extends RuntimeException)
// con extends Exception potrei anche gestire le eccezioni CONTROLLATE
public class ECCEZIONI_classDIV_ZERO extends RuntimeException  {
    private double dividendo;
    public ECCEZIONI_classDIV_ZERO(double dividendo) {
        super("Impossibile dividere " + dividendo + " per zero");
        this.dividendo = dividendo;
    }

    public double getDividendo() {
        return dividendo;
    }
}
