package it.unicam.cs.asdl2526.es11;

/**
 * Un oggetto di questa classe è un risolutore del problema della più lunga
 * sottosequenza comune tra due stringhe date.
 *
 * Una sottosequenza di una stringa X è una sequenza di caratteri di X mantenendo l'ordine originale ma non necessariamente contigui.
 * La LCS è la sottosequenza comune più lunga tra due stringhe X e Y.
 * Esempio: X = "ABCBDAB", Y = "BDCABA" → LCS = "BCBA" (lunghezza 4).
 *
 * Complessità: Θ(m·n) dove m = x.length(), n = y.length().
 * 
 * @author Template: Luca Tesei, Implementation: Collective
 *
 */
public class LCSSolver {

    /* Prima stringa immutabile */
    private final String x;

    /* Seconda stringa immutabile */
    private final String y;

    /* Matrice dei costi ottimi -> per il calcolo di una soluzione ottima */
    // matrice m: (x.length+1) × (y.length+1)
    private int[][] m;

    /*
     * Flag che indica che questo solver ha svolto il proprio calcolo.
     * Pattern LAZY: alla creazione del solver (nel costruttore) non viene svolto il calcolo.
     * Esso viene eseguito successivamente alla chiamata del metodo solve().
     * Chiamate successive a solve() vengono ignorate grazie a if (this.isSolved) return.
     * Questo permette di creare l'oggetto e interrogarlo (isSolved(), getX(), getY())
     * senza pagare il costo computazionale finché non serve.
     */
    private boolean isSolved;

    /**
     * Costruisce un risolutore LCS fra due stringhe date.
     * 
     * @param x
     *              la prima stringa
     * @param y
     *              la seconda stringa
     * @throws NullPointerException
     *                                  se almeno una delle due stringhe passate
     *                                  è nulla
     */
    public LCSSolver(String x, String y) {
        if (x == null || y == null)
            throw new NullPointerException(
                    "Creazione di un solver con una o due stringhe null");
        this.x = x;
        this.y = y;
        // creo la matrice
        this.m = new int[this.x.length() + 1][this.y.length() + 1];
        this.isSolved = false;
    }

    /**
     * @return the string x
     */
    public String getX() {
        return x;
    }

    /**
     * @return the string y
     */
    public String getY() {
        return y;
    }

    /**
     * Risolve il problema LCS delle due stringhe di questo solver, se non è stato già risolto precedentemente.
     * Dopo l'esecuzione di questo metodo la prima volta il problema verrà considerato risolto.
     *
     *      * Nota cruciale sull'indicizzazione: solve utilizzerà x.charAt(i-1) e y.charAt(j-1)
     *      * perché la matrice ha una riga e una colonna extra (indice 0) che rappresentano la stringa vuota,
     *      * quindi i caratteri della stringa sono offset di 1.
     *      *
     *      * La ricorrenza LCS
     *      * m[i][j] = lunghezza della LCS tra il prefisso x[0..i-1] e il prefisso y[0..j-1].
     *      * m[i][0] = 0  per ogni i   (qualsiasi stringa vs stringa vuota → LCS = 0)
     *      * m[0][j] = 0  per ogni j   (stringa vuota vs qualsiasi → LCS = 0)
     *      *
     *      * m[i][j] = m[i-1][j-1] + 1    se x[i-1] == y[j-1]  (caratteri uguali)
     *      *         = m[i-1][j]          se m[i-1][j] >= m[i][j-1]  (prendo il max da sopra)
     *      *         = m[i][j-1]          altrimenti  (prendo il max da sinistra)
     *
     *
     *      Trace su X="ABCBDAB", Y="BDCABA" (dal test, atteso LCS=4):
     *       ""  B  D  C  A  B  A
     *       j:  0  1  2  3  4  5  6
     *   ""  0:  0  0  0  0  0  0  0
     *   A   1:  0  0  0  0  1  1  1
     *   B   2:  0  1  1  1  1  2  2
     *   C   3:  0  1  1  2  2  2  2
     *   B   4:  0  1  1  2  2  3  3
     *   D   5:  0  1  2  2  2  3  3
     *   A   6:  0  1  2  2  3  3  4
     *   B   7:  0  1  2  2  3  4  4
     *
     * SOLUZIONE -> m[7][6] = 4 ✓
     */
    public void solve() {
        // TODO implementare
        if (this.isSolved)
            return;
        // inizializzazione a zero (si può evitare perché le caselle dell'array sono già inizializzate a zero)
        for (int i = 0; i <= this.x.length(); i++) {
            this.m[i][0] = 0;
        }
        // inizializzazione a zero (si può evitare perché le caselle dell'array sono già inizializzate a zero)
        for (int j = 1; j <= this.y.length(); j++) {
            this.m[0][j] = 0;
        }
        // Ciclo di riempimento BOTTOM-UP della matrice
        for (int i = 1; i <= this.x.length(); i++)
            for (int j = 1; j <= this.y.length(); j++) {
                if (this.x.charAt(i - 1) == this.y.charAt(j - 1)) {
                    this.m[i][j] = this.m[i - 1][j - 1] + 1;            // diagonale +1
                } else if (this.m[i - 1][j] >= this.m[i][j - 1]) {
                    this.m[i][j] = this.m[i - 1][j];                    // da sopra
                } else {
                    this.m[i][j] = this.m[i][j - 1];                    // da sinistra
                }
            }
        // Cambio del flag
        this.isSolved = true;
    }

    /**
     * Determina se questo solver ha già risolto il problema.
     * 
     * @return true se il problema LCS di questo solver è già stato risolto
     *         precedentemente, false altrimenti
     */
    public boolean isSolved() {
        return this.isSolved;
    }

    /**
     * Determina la lunghezza massima delle sottosequenze comuni.
     * 
     * @return la massima lunghezza delle sottosequenze comuni di x e y.
     * @throws IllegalStateException
     *                                   se il solver non ha ancora risolto il
     *                                   problema LCS
     */
    public int getLengthOfSolution() {
        if (!this.isSolved)
            throw new IllegalStateException(
                    "Richiesta delle soluzioni prima della risoluzione del problema");
        return this.m[this.x.length()][this.y.length()];
    }

    /**
     * Restituisce una soluzione del problema LCS.
     * 
     * @return una sottosequenza di this.x e this.y di lunghezza massima
     * @throws IllegalStateException
     *                                   se il solver non ha ancora risolto il
     *                                   problema LCS
     */
    public String getOneSolution() {
        if (!this.isSolved)
            throw new IllegalStateException(
                    "Richiesta delle soluzioni prima della risoluzione del problema");
        return traceBack(this.x.length(), this.y.length());
    }

    /*
     * NOTA: Determina una soluzione ottime ripercorrendo le caselle della matrice m
     * seguendo le condizioni con cui sono state costruite. Dal basso verso l'alto.
     * Ogni carattere uguale trovato viene appeso in fondo alla stringa restituita dalla chiamata ricorsiva.
     * In questo caso non deve venire usata una matrice di "supporto" aggiuntiva per ricostruire una soluzione ottima,
     * ma viene usata la stessa matrice m
     */
    private String traceBack(int i, int j) {
        // TODO implementare ricorsivamente
        // caso base: prefisso vuoto
        if (i == 0 || j == 0) {
            return "";
        }
        if (this.x.charAt(i - 1) == this.y.charAt(j - 1)) {
            // carattere fa parte della LCS
            return traceBack(i - 1, j - 1) + this.x.charAt(i - 1);
        } else if (this.m[i - 1][j] >= this.m[i][j - 1]) {
            // si è venuti da sopra
            return traceBack(i - 1, j);
        } else {
            // si è venuti da sinistra
            return traceBack(i, j - 1);
        }
        // return null;
    }

    /**
     * Determina se una certa stringa z è una sottosequenza comune delle due stringhe di questo solver (cioé sia di x che di y).
     * Usa il metodo statico isSubsequence(z, w)
     *
     * @param z
     *              la string da controllare
     * @return true se z è sottosequenza di this.x e di this.y, false altrimenti
     * @throws NullPointerException
     *                                  se z è null
     */
    public boolean isCommonSubsequence(String z) {
        if (z == null)
            throw new NullPointerException("Test di una sequenza nulla");
        return isSubsequence(z, this.x) && isSubsequence(z, this.y);
    }

    /*
     * Determina se una stringa è sottosequenza di un'altra stringa.
     * isSubsequence è ricorsiva e non usa la programmazione dinamica.
     * Sfrutta indexOf per trovare la prima occorrenza del primo carattere di z in w, poi ricorre sul resto di entrambi.
     * 
     * @param z la stringa da testare
     * 
     * @param w la stringa di cui z dovrebbe essere sottosequenza
     * 
     * @return true se z è sottosequenza di w, false altrimenti
     */
    private static boolean isSubsequence(String z, String w) {
        // TODO implementare ricorsivamente
        // Caso base: stringa vuota è sottosequenza di tutto
        if (z.equals(""))
            return true;
        // considero il primo carattere di z
        char c = z.charAt(0);
        // cerco la prima occorrenza di c in w
        int i = w.indexOf(c);
        if (i != -1)             // il primo carattere di z non occorre mai in w, quindi z non può essere una sottosequenza
            // richiamo la funzione sul resto di z dopo aver fatto match del primo carattere di z in w ___ avanzo di 1 in entrambe z e w
            return isSubsequence(z.substring(1), w.substring(i + 1));
        else
            // c non appare in w → z non è sottosequenza
            return false;
        // return false;
    }
}
