package it.unicam.cs.asdl2526.es11;

import java.util.List;

/**
 * Un solver prende una certa sequenza di matrici da moltiplicare e calcola una
 * parentesizzazione ottima, cioè che minimizza il numero di moltiplicazioni
 * scalari necessarie per moltiplicare tutte le matrici.
 *
 * Complessità: Θ(n³) tempo, Θ(n²) spazio -> usa matrice b separata.
 * 
 * @author Template: Luca Tesei, Implementation: Collective
 *
 */
public class MatrixMultiplicationSolver {

    // sequenza delle dimensioni delle matrici da moltiplicare (n+1 valori per n matrici)
    private List<Integer> p;

    // Entrambe le matrici
    //      m[i][j] = costo minimo per moltiplicare A_i ... A_j
    //      b[i][j] = k ottimo che divide il prodotto A_i...A_j
    // sono (n-1) × (n-1) con indici 0-based

    // matrice dei costi minimi
    private int[][] m;

    // matrice delle scelte dei k che corrispondono al costo minimo
    private int[][] b;

    /**
     * Costruisce un solver per una certa sequenza di matrici da moltiplicare,
     * date le loro dimensioni righeXcolonne. Il calcolo della soluzione ottima
     * viene eseguito subito, cioè come parte di questo costruttore (non in modo lazy).
     * 
     * @param p
     *              è una lista di valori che sono le dimensioni delle matrici,
     *              ad esempio se p = [10, 100, 5, 50] allora sto moltiplicando
     *              3 matrici (p.size() - 1) le cui dimensioni sono A_{0} =
     *              10x100, A_{1} = 100x5, A_{2} = 5x50
     * @throws NullPointerException
     *                                      se la lista passata è null
     * @throws IllegalArgumentException
     *                                      se la lista p contiene meno di due
     *                                      elementi (cioè deve contenere almeno
     *                                      una matrice. Nel caso di una unica
     *                                      matrice la soluzione è 0 e la
     *                                      parentesizzazione è la matrice
     *                                      stessa, cioè "A_{0}")
     */
    public MatrixMultiplicationSolver(List<Integer> p) {
        if (p == null)
            throw new NullPointerException("Lista nulla");
        if (p.size() <= 1)
            throw new IllegalArgumentException(
                    "Lista di dimensione non valida");
        this.p = p;
        this.m = new int[p.size() - 1][p.size() - 1];
        this.b = new int[p.size() - 1][p.size() - 1];
        this.solve();
    }

    /*
     * Risolve il problema della parentesizzazione ottima con la programmazione
     * dinamica.
     */
    private void solve() {
        // TODO implementare
        // riempimento bottom-up per lunghezze crescenti
        // inizializzo la diagonale principale della matrice m a zero (singole matrici, costo zero)
        for (int i = 0; i < p.size() - 1; i++) {
            m[i][i] = 0;
            b[i][i] = -1; // non c'è nessun k da usare
        }
        // // h = lunghezza della sottocatena (da 1 a n-1)
        for (int h = 1; h < p.size() - 1; h++)
            for (int i = 0; i < p.size() - 1 - h; i++) {
                int j = i + h;
                // posso assegnare a m[i][j] il minimo dei valori al variare di
                // k
                m[i][j] = Integer.MAX_VALUE; // fa il ruolo di + infinito
                b[i][j] = -1; // valore dummy
                for (int k = i; k < j; k++) {
                    // Calcolo il numero di operazioni per moltiplicare (A_i x ... x A_k) e (A_{k+1} x ... x A_j)
                    // NB nelle dimensioni si usa p.get(i), p.get(k+1), p.get(j+1) —
                    // gli indici nella lista p sono sfasati di 1 rispetto agli indici delle matrici,
                    // perché p ha n+1 elementi e la matrice A_i ha dimensioni p[i] × p[i+1]
                    int costo = p.get(i).intValue() * p.get(k + 1).intValue()
                            * p.get(j + 1).intValue();
                    if (m[i][j] > (m[i][k] + m[k + 1][j] + costo)) {
                        // aggiorno il valore di m[i][j] per arrivare a
                        // calcolare il minimo
                        m[i][j] = m[i][k] + m[k + 1][j] + costo;
                        // salvo in b il k che corrisponde al minimo attuale
                        b[i][j] = k;
                    }
                }
            }
    }

    /**
     * Restituisce il numero minimo di moltiplicazioni necessarie per
     * moltiplicare la sequenza di matrici di questo solver. Nel caso di una
     * sola matrice restituisce zero.
     * 
     * @return il numero minimo di moltiplicazioni soluzione del problema di
     *         parentesizzazione
     */
    public int getOptimalCost() {
        return m[0][p.size() - 2];
    }

    /**
     * Restituisce una parentesizzazione ottima.
     * 
     * Il formato prevede l'uso di "A_{i}" per indicare la i-esima matrice di
     * dimensione p.get(i) x p.get(i+1) con 0 <= i <= p.size() - 2. Ad esempio
     * la parentesizzazione con una sola matrice deve restituire "A_{0}", la
     * parentesizzazione con due matrici deve restituire "(A_{0} x A_{1})", la
     * parentesizzazione con tre matrici deve restituire "((A_{0} x A_{1}) x
     * A_{2})" oppure "(A_{0} x (A_{1} x A_{2}))" e così via.
     * 
     * @return una parentesizzazione ottima
     */
    public String getOptimalParenthesization() {
        return traceBack(0, p.size() - 2);
    }

    /*
     * Effettua il traceback (ricostruzione della parentesizzazione) utilizzando una matrice b separata
     * che è stata riempita appositamente durante il processo di calcolo del costo minimo
     */
    private String traceBack(int i, int j) {
        // TODO implementare ricorsivamente
        // caso base: singola matrice
        if (i == j)
            return "A_{" + i + "}";
        // i < j
        return "(" + traceBack(i, b[i][j]) // b[i][j]== k
                + " x " + traceBack(b[i][j] + 1, j) + ")";
        // return null;
    }

}
