package it.unicam.cs.asdl2526.tutorato.pe1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Classe di test per la classe DijkstraSP.
 *
 * Il grafo di riferimento principale è quello usato nelle animazioni del corso:
 *
 *   Nodi: A, B, C, D, E, F
 *   Archi (non orientato, pesato):
 *     A-B(4), A-C(2), B-C(6), B-D(5), B-E(3), C-E(7), D-E(1), D-F(8), E-F(4)
 *
 * Distanze minime da A (verificate manualmente):
 *   d[A]=0, d[B]=4, d[C]=2, d[D]=8, d[E]=7, d[F]=11
 *
 * @author Luca Tesei, Federico Di Petta (template)
 */
class DijkstraSPTest {

    // =========================================================
    //  TEST ECCEZIONI
    // =========================================================

    @Test
    final void testExceptions() {
        DijkstraSP<String> alg = new DijkstraSP<String>();

        // grafo null → NullPointerException
        assertThrows(NullPointerException.class,
                () -> alg.computeSP(null, null));

        Graph<String> gr = new MatrixGraph<String>();
        gr.addNode("a");
        GraphNode<String> a = new GraphNode<String>("a");

        // sorgente null → NullPointerException
        assertThrows(NullPointerException.class,
                () -> alg.computeSP(gr, null));

        // grafo null (con sorgente non null) → NullPointerException
        assertThrows(NullPointerException.class,
                () -> alg.computeSP(null, a));

        // sorgente non nel grafo → IllegalArgumentException
        GraphNode<String> z = new GraphNode<String>("z");
        assertThrows(IllegalArgumentException.class,
                () -> alg.computeSP(gr, z));

        // grafo non pesato → IllegalArgumentException
        gr.addNode("b");
        gr.addEdge("a", "b");   // arco senza peso
        assertThrows(IllegalArgumentException.class,
                () -> alg.computeSP(gr, gr.getNode("a")));

        // grafo con peso negativo → IllegalArgumentException
        gr.clear();
        gr.addNode("a");
        gr.addNode("b");
        gr.addWeightedEdge("a", "b", -3.0);
        assertThrows(IllegalArgumentException.class,
                () -> alg.computeSP(gr, gr.getNode("a")));
    }

    // =========================================================
    //  TEST grafo con un solo nodo
    // =========================================================

    @Test
    final void testSingleNode() {
        Graph<String> gr = new MatrixGraph<String>();
        gr.addNode("a");
        GraphNode<String> a = gr.getNode("a");

        DijkstraSP<String> alg = new DijkstraSP<String>();
        alg.computeSP(gr, a);

        assertTrue(a.getPrevious() == null);
        assertEquals(0.0, a.getFloatingPointDistance(), 0.001);
        assertEquals(GraphNode.COLOR_BLACK, a.getColor());
    }

    // =========================================================
    //  TEST grafo con due nodi connessi
    // =========================================================

    @Test
    final void testTwoNodes() {
        Graph<String> gr = new MatrixGraph<String>();
        gr.addNode("a");
        gr.addNode("b");
        gr.addWeightedEdge("a", "b", 7.0);
        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");

        DijkstraSP<String> alg = new DijkstraSP<String>();
        alg.computeSP(gr, a);

        // sorgente
        assertTrue(a.getPrevious() == null);
        assertEquals(0.0, a.getFloatingPointDistance(), 0.001);
        assertEquals(GraphNode.COLOR_BLACK, a.getColor());

        // nodo b raggiungibile con distanza 7
        assertTrue(b.getPrevious() == a);
        assertEquals(7.0, b.getFloatingPointDistance(), 0.001);
        assertEquals(GraphNode.COLOR_BLACK, b.getColor());
    }

    // =========================================================
    //  TEST grafo con due nodi NON connessi (componenti separate)
    // =========================================================

    @Test
    final void testDisconnectedNode() {
        Graph<String> gr = new MatrixGraph<String>();
        gr.addNode("a");
        gr.addNode("b");
        // nessun arco
        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");

        DijkstraSP<String> alg = new DijkstraSP<String>();
        alg.computeSP(gr, a);

        // sorgente
        assertTrue(a.getPrevious() == null);
        assertEquals(0.0, a.getFloatingPointDistance(), 0.001);

        // b non raggiungibile → distanza infinita, predecessore null
        assertTrue(b.getPrevious() == null);
        assertEquals(Double.POSITIVE_INFINITY, b.getFloatingPointDistance(), 0.001);
        assertEquals(GraphNode.COLOR_BLACK, b.getColor());
    }

    // =========================================================
    //  TEST grafo principale del corso (6 nodi)
    //  Sorgente: A
    //  Distanze attese: A=0, B=4, C=2, D=8, E=7, F=11
    // =========================================================

    @Test
    final void testDijkstra1FromA() {
        Graph<String> gr = buildMainGraph();

        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");
        GraphNode<String> c = gr.getNode("c");
        GraphNode<String> d = gr.getNode("d");
        GraphNode<String> e = gr.getNode("e");
        GraphNode<String> f = gr.getNode("f");

        DijkstraSP<String> alg = new DijkstraSP<String>();
        alg.computeSP(gr, a);

        // Distanze
        assertEquals(0.0,  a.getFloatingPointDistance(), 0.001);
        assertEquals(4.0,  b.getFloatingPointDistance(), 0.001);
        assertEquals(2.0,  c.getFloatingPointDistance(), 0.001);
        assertEquals(8.0,  d.getFloatingPointDistance(), 0.001);
        assertEquals(7.0,  e.getFloatingPointDistance(), 0.001);
        assertEquals(11.0, f.getFloatingPointDistance(), 0.001);

        // Predecessori — albero dei cammini minimi da A
        // A→A: null (radice)
        // A→B: direttamente A
        // A→C: direttamente A (peso 2 < qualsiasi alternativa)
        // A→D: A→B→E→D (4+3+1=8)
        // A→E: A→B→E (4+3=7)
        // A→F: A→B→E→F (4+3+4=11)
        assertTrue(a.getPrevious() == null);
        assertTrue(b.getPrevious() == a);
        assertTrue(c.getPrevious() == a);
        assertTrue(e.getPrevious() == b);
        assertTrue(d.getPrevious() == e);
        assertTrue(f.getPrevious() == e);

        // Tutti i nodi devono essere stati visitati (BLACK)
        assertEquals(GraphNode.COLOR_BLACK, a.getColor());
        assertEquals(GraphNode.COLOR_BLACK, b.getColor());
        assertEquals(GraphNode.COLOR_BLACK, c.getColor());
        assertEquals(GraphNode.COLOR_BLACK, d.getColor());
        assertEquals(GraphNode.COLOR_BLACK, e.getColor());
        assertEquals(GraphNode.COLOR_BLACK, f.getColor());
    }

    // =========================================================
    //  TEST stesso grafo, sorgente diversa: B
    //  Distanze attese da B:
    //    B=0, A=4, C=6(B-C) o 6(B-A-C=4+2), D=4(B-E-D=3+1) o 5,
    //    E=3, F=7(B-E-F=3+4)
    //  Calcolo: B=0, A=4(B-A), C=min(6,4+2)=6, E=3(B-E),
    //           D=min(5,3+1)=4(B-E-D), F=min(3+1+8,3+4)=7(B-E-F)
    // =========================================================

    @Test
    final void testDijkstra2FromB() {
        Graph<String> gr = buildMainGraph();

        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");
        GraphNode<String> c = gr.getNode("c");
        GraphNode<String> d = gr.getNode("d");
        GraphNode<String> e = gr.getNode("e");
        GraphNode<String> f = gr.getNode("f");

        DijkstraSP<String> alg = new DijkstraSP<String>();
        alg.computeSP(gr, b);

        assertEquals(0.0, b.getFloatingPointDistance(), 0.001);
        assertEquals(4.0, a.getFloatingPointDistance(), 0.001);
        assertEquals(6.0, c.getFloatingPointDistance(), 0.001);
        assertEquals(4.0, d.getFloatingPointDistance(), 0.001);
        assertEquals(3.0, e.getFloatingPointDistance(), 0.001);
        assertEquals(7.0, f.getFloatingPointDistance(), 0.001);

        // Predecessori
        assertTrue(b.getPrevious() == null);
        assertTrue(a.getPrevious() == b);
        // c: min(B-C=6, B-A-C=6) → entrambi hanno peso 6, Dijkstra sceglie
        // il primo trovato; accettiamo sia b che a come predecessore di c
        assertTrue(c.getPrevious() == b || c.getPrevious() == a);
        assertTrue(e.getPrevious() == b);
        assertTrue(d.getPrevious() == e);
        assertTrue(f.getPrevious() == e);
    }

    // =========================================================
    //  TEST stesso grafo, sorgente: E
    //  Distanze da E:
    //    E=0, D=1(E-D), B=3(E-B), F=4(E-F), A=7(E-B-A),
    //    C=min(7, 3+6, 0+7)=7 (E-C o E-B-A-C)
    // =========================================================

    @Test
    final void testDijkstra3FromE() {
        Graph<String> gr = buildMainGraph();

        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");
        GraphNode<String> c = gr.getNode("c");
        GraphNode<String> d = gr.getNode("d");
        GraphNode<String> e = gr.getNode("e");
        GraphNode<String> f = gr.getNode("f");

        DijkstraSP<String> alg = new DijkstraSP<String>();
        alg.computeSP(gr, e);

        assertEquals(0.0, e.getFloatingPointDistance(), 0.001);
        assertEquals(1.0, d.getFloatingPointDistance(), 0.001);
        assertEquals(3.0, b.getFloatingPointDistance(), 0.001);
        assertEquals(4.0, f.getFloatingPointDistance(), 0.001);
        assertEquals(7.0, a.getFloatingPointDistance(), 0.001);
        // c: E-C=7 oppure E-B-A-C=3+4+2=9 → minimo è 7 via E-C
        assertEquals(7.0, c.getFloatingPointDistance(), 0.001);

        assertTrue(e.getPrevious() == null);
        assertTrue(d.getPrevious() == e);
        assertTrue(b.getPrevious() == e);
        assertTrue(f.getPrevious() == e);
        assertTrue(a.getPrevious() == b);
        assertTrue(c.getPrevious() == e || c.getPrevious() == a);
    }

    // =========================================================
    //  TEST grafo semplice a catena: A-B-C-D con pesi crescenti
    //  Distanze da A: A=0, B=1, C=3, D=6
    // =========================================================

    @Test
    final void testChainGraph() {
        Graph<String> gr = new MatrixGraph<String>();
        gr.addNode("a"); gr.addNode("b");
        gr.addNode("c"); gr.addNode("d");
        gr.addWeightedEdge("a", "b", 1);
        gr.addWeightedEdge("b", "c", 2);
        gr.addWeightedEdge("c", "d", 3);

        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");
        GraphNode<String> c = gr.getNode("c");
        GraphNode<String> d = gr.getNode("d");

        DijkstraSP<String> alg = new DijkstraSP<String>();
        alg.computeSP(gr, a);

        assertEquals(0.0, a.getFloatingPointDistance(), 0.001);
        assertEquals(1.0, b.getFloatingPointDistance(), 0.001);
        assertEquals(3.0, c.getFloatingPointDistance(), 0.001);
        assertEquals(6.0, d.getFloatingPointDistance(), 0.001);

        assertTrue(a.getPrevious() == null);
        assertTrue(b.getPrevious() == a);
        assertTrue(c.getPrevious() == b);
        assertTrue(d.getPrevious() == c);
    }

    // =========================================================
    //  TEST grafo triangolo: verifica scelta del cammino più breve
    //  A-B(10), B-C(1), A-C(5)
    //  Da A: d[B]=10, d[C]=5 → predecessore di B: A (diretto)
    //  Ma se si aggiungesse A-B(10): cammino A-C-B=6 < 10
    //  Qui con A-B(10), A-C(5), C-B(1):
    //  d[B] = min(10, 5+1) = 6  → predecessore B = C
    // =========================================================

    @Test
    final void testShortcut() {
        Graph<String> gr = new MatrixGraph<String>();
        gr.addNode("a"); gr.addNode("b"); gr.addNode("c");
        gr.addWeightedEdge("a", "b", 10);
        gr.addWeightedEdge("a", "c", 5);
        gr.addWeightedEdge("c", "b", 1);

        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");
        GraphNode<String> c = gr.getNode("c");

        DijkstraSP<String> alg = new DijkstraSP<String>();
        alg.computeSP(gr, a);

        assertEquals(0.0, a.getFloatingPointDistance(), 0.001);
        assertEquals(5.0, c.getFloatingPointDistance(), 0.001);
        // cammino più breve verso B è A→C→B = 6, non A→B = 10
        assertEquals(6.0, b.getFloatingPointDistance(), 0.001);

        assertTrue(a.getPrevious() == null);
        assertTrue(c.getPrevious() == a);
        assertTrue(b.getPrevious() == c);   // scorciatoia via C
    }

    // =========================================================
    //  TEST: chiamate successive sovrascrivono i risultati
    // =========================================================

    @Test
    final void testComputeOverwrite() {
        Graph<String> gr = buildMainGraph();
        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");
        GraphNode<String> e = gr.getNode("e");

        DijkstraSP<String> alg = new DijkstraSP<String>();

        // Prima esecuzione da A
        alg.computeSP(gr, a);
        assertEquals(7.0, e.getFloatingPointDistance(), 0.001);
        assertTrue(e.getPrevious() == b);

        // Seconda esecuzione da E — sovrascrive i risultati precedenti
        alg.computeSP(gr, e);
        assertEquals(0.0, e.getFloatingPointDistance(), 0.001);
        assertTrue(e.getPrevious() == null);
        // Ora a è raggiunto da b (E→B→A)
        assertTrue(a.getPrevious() == b);
    }

    // =========================================================
    //  TEST: grafo Cormen 9 nodi (stesso di PrimMSP testFindMSP1)
    //  Sorgente: a
    //  Distanze attese da a:
    //    a=0, b=4, c=12(a-b-c=4+8), d=19(a-b-c-d=4+8+7),
    //    e=21(a-h-g-f-e?), f=16(a-b-c-f=4+8+4), g=9.5(a-h-g=8.5+1),
    //    h=8.5(a-h), i=14(a-b-c-i=4+8+2)
    // =========================================================

    @Test
    final void testDijkstraLargeGraph() {
        Graph<String> gr = new MatrixGraph<String>();
        gr.addNode("a"); gr.addNode("b"); gr.addNode("c");
        gr.addNode("d"); gr.addNode("e"); gr.addNode("f");
        gr.addNode("g"); gr.addNode("h"); gr.addNode("i");
        gr.addWeightedEdge("a", "b", 4);
        gr.addWeightedEdge("a", "h", 8.5);
        gr.addWeightedEdge("b", "h", 11);
        gr.addWeightedEdge("b", "c", 8);
        gr.addWeightedEdge("c", "i", 2);
        gr.addWeightedEdge("c", "d", 7);
        gr.addWeightedEdge("c", "f", 4);
        gr.addWeightedEdge("d", "f", 14);
        gr.addWeightedEdge("d", "e", 9);
        gr.addWeightedEdge("e", "f", 10);
        gr.addWeightedEdge("f", "g", 2);
        gr.addWeightedEdge("g", "i", 6);
        gr.addWeightedEdge("g", "h", 1);
        gr.addWeightedEdge("h", "i", 7);

        DijkstraSP<String> alg = new DijkstraSP<String>();
        alg.computeSP(gr, gr.getNode("a"));

        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");
        GraphNode<String> c = gr.getNode("c");
        GraphNode<String> d = gr.getNode("d");
        GraphNode<String> e = gr.getNode("e");
        GraphNode<String> f = gr.getNode("f");
        GraphNode<String> g = gr.getNode("g");
        GraphNode<String> h = gr.getNode("h");
        GraphNode<String> i = gr.getNode("i");

        // Distanze verificate manualmente
        assertEquals(0.0,  a.getFloatingPointDistance(), 0.001);
        assertEquals(4.0,  b.getFloatingPointDistance(), 0.001);
        assertEquals(12.0, c.getFloatingPointDistance(), 0.001); // a-b-c
        assertEquals(8.5,  h.getFloatingPointDistance(), 0.001); // a-h
        assertEquals(9.5,  g.getFloatingPointDistance(), 0.001); // a-h-g
        assertEquals(11.5, f.getFloatingPointDistance(), 0.001); // a-h-g-f
        assertEquals(14.0, i.getFloatingPointDistance(), 0.001); // a-b-c-i
        assertEquals(19.0, d.getFloatingPointDistance(), 0.001); // a-b-c-d
        assertEquals(21.5, e.getFloatingPointDistance(), 0.001); // a-h-g-f-e? no: a-b-c-d-e=4+8+7+9=28; a-h-g-f-e=8.5+1+2+10=21.5

        // Verifica predecessori dei cammini principali
        assertTrue(a.getPrevious() == null);
        assertTrue(b.getPrevious() == a);
        assertTrue(h.getPrevious() == a);
        assertTrue(g.getPrevious() == h);
        assertTrue(f.getPrevious() == g);
        assertTrue(c.getPrevious() == b);
        assertTrue(i.getPrevious() == c);
    }

    // =========================================================
    //  METODO HELPER: costruisce il grafo principale del corso
    //  Nodi: a, b, c, d, e, f
    //  Archi: a-b(4), a-c(2), b-c(6), b-d(5), b-e(3),
    //         c-e(7), d-e(1), d-f(8), e-f(4)
    // =========================================================

    private Graph<String> buildMainGraph() {
        Graph<String> gr = new MatrixGraph<String>();
        gr.addNode("a"); gr.addNode("b"); gr.addNode("c");
        gr.addNode("d"); gr.addNode("e"); gr.addNode("f");
        gr.addWeightedEdge("a", "b", 4);
        gr.addWeightedEdge("a", "c", 2);
        gr.addWeightedEdge("b", "c", 6);
        gr.addWeightedEdge("b", "d", 5);
        gr.addWeightedEdge("b", "e", 3);
        gr.addWeightedEdge("c", "e", 7);
        gr.addWeightedEdge("d", "e", 1);
        gr.addWeightedEdge("d", "f", 8);
        gr.addWeightedEdge("e", "f", 4);
        return gr;
    }
}
