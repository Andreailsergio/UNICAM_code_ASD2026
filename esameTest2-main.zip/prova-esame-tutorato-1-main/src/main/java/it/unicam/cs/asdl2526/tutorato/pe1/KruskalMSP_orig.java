package it.unicam.cs.asdl2526.tutorato.pe1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

// ATTENZIONE: è vietato includere import a pacchetti che non siano della Java SE

/**
 * Classe singoletto che implementa l'algoritmo di Kruskal per trovare un
 * Minimum Spanning Tree di un grafo non orientato, pesato e con pesi non
 * negativi.
 *
 * L'algoritmo utilizza la struttura dati Union-Find (insiemi disgiunti) per
 * verificare efficientemente se l'aggiunta di un arco creerebbe un ciclo.
 * La Union-Find è implementata tramite due mappe (parent e rank) che
 * supportano le operazioni MAKE-SET, FIND-SET e UNION con union-by-rank
 * e path compression.
 *
 * Dopo l'esecuzione del metodo {@code computeMSP}, il campo
 * {@code mstEdges} contiene gli archi dell'MST trovato.
 *
 * @author Luca Tesei, Federico Di Petta (template)
 *         INSERIRE NOME, COGNOME ED EMAIL xxxx@studenti.unicam.it DELLO STUDENTE
 *         (implementazione)
 *
 * @param <L>
 *                tipo delle etichette dei nodi del grafo
 */
public class KruskalMSP_orig<L> {

    /*
     * Insieme degli archi appartenenti all'MST calcolato dall'ultima chiamata
     * a computeMSP. È null se computeMSP non è ancora stato chiamato.
     */
    private Set<GraphEdge<L>> mstEdges;

    /*
     * Struttura Union-Find: mappa ogni nodo al proprio rappresentante
     * (radice dell'albero Union-Find).
     */
    private Map<GraphNode<L>, GraphNode<L>> parent;

    /*
     * Struttura Union-Find: mappa ogni nodo al proprio rango (altezza
     * approssimativa dell'albero radicato in quel nodo).
     */
    private Map<GraphNode<L>, Integer> rank;

    /**
     * Costruisce un nuovo oggetto KruskalMSP inizializzando le strutture dati.
     */
    public KruskalMSP_orig() {
        this.mstEdges = null;
        this.parent = new HashMap<>();
        this.rank = new HashMap<>();
    }

    /**
     * Restituisce l'insieme degli archi dell'MST calcolato dall'ultima chiamata
     * a {@code computeMSP}, oppure null se {@code computeMSP} non è ancora
     * stato chiamato.
     *
     * @return l'insieme degli archi dell'MST, o null
     */
    public Set<GraphEdge<L>> getMstEdges() {
        return this.mstEdges;
    }

    /**
     * Utilizza l'algoritmo di Kruskal per trovare un albero di copertura
     * minimo in un grafo non orientato, pesato, con pesi non negativi.
     *
     * Pseudocodice (Cormen):
     *   A = ∅
     *   per ogni v ∈ V: MAKE-SET(v)
     *   ordina E per peso non decrescente
     *   per ogni arco (u,v) ∈ E in ordine:
     *     se FIND-SET(u) ≠ FIND-SET(v):
     *       A = A ∪ {(u,v)}
     *       UNION(u, v)
     *   return A
     *
     * Dopo l'esecuzione il campo {@code mstEdges} contiene gli archi dell'MST.
     *
     * @param g
     *              un grafo non orientato, pesato, con pesi non negativi
     *
     * @throws NullPointerException
     *              se il grafo g è null
     * @throws IllegalArgumentException
     *              se il grafo g è orientato, non pesato o con pesi negativi
     */
    public void computeMSP(Graph<L> g) {
        // TODO implementare
    }

    /**
     * Inizializza la struttura Union-Find per tutti i nodi del grafo.
     * Ogni nodo diventa un insieme singleton: parent[v] = v, rank[v] = 0.
     *
     * Corrisponde all'operazione MAKE-SET del Cormen per tutti i vertici.
     *
     * @param nodes
     *              l'insieme dei nodi da inizializzare
     */
    private void makeSet(Set<GraphNode<L>> nodes) {
        // TODO implementare
    }

    /**
     * Restituisce il rappresentante (radice) dell'insieme che contiene il
     * nodo {@code v} nella struttura Union-Find, applicando la
     * <b>path compression</b>: tutti i nodi incontrati durante la risalita
     * vengono collegati direttamente alla radice.
     *
     * Corrisponde all'operazione FIND-SET del Cormen con path compression.
     *
     * @param v
     *              il nodo di cui trovare il rappresentante
     * @return il rappresentante dell'insieme che contiene v
     */
    private GraphNode<L> findSet(GraphNode<L> v) {
        // TODO implementare
        return null;
    }

    /**
     * Unisce i due insiemi che contengono rispettivamente i nodi {@code u}
     * e {@code v} nella struttura Union-Find, usando la strategia
     * <b>union-by-rank</b>: l'albero di rango minore viene attaccato sotto
     * la radice di quello di rango maggiore. Se i ranghi sono uguali,
     * la radice di v viene attaccata sotto la radice di u e il rango di u
     * viene incrementato di 1.
     *
     * Corrisponde all'operazione UNION del Cormen con union-by-rank.
     *
     * Precondizione: u e v devono già essere radici dei rispettivi insiemi
     * (cioè essere il risultato di findSet).
     *
     * @param u
     *              radice del primo insieme
     * @param v
     *              radice del secondo insieme
     */
    private void union(GraphNode<L> u, GraphNode<L> v) {
        // TODO implementare
    }
}
