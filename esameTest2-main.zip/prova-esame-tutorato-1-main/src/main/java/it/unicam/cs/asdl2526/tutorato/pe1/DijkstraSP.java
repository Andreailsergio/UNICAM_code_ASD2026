package it.unicam.cs.asdl2526.tutorato.pe1;

import java.util.ArrayList;
import java.util.List;

// ATTENZIONE: è vietato includere import a pacchetti che non siano della Java SE

/**
 * Classe singoletto che implementa l'algoritmo di Dijkstra per trovare i
 * cammini minimi da un nodo sorgente in un grafo non orientato, pesato e con
 * pesi non negativi.
 *
 * L'algoritmo utilizza una coda con priorità realizzata tramite una semplice
 * ArrayList (non è richiesta ottimizzazione tramite heap).
 *
 * Dopo l'esecuzione del metodo {@code computeSP}, per ogni nodo v del grafo:
 * <ul>
 *   <li>{@code v.getFloatingPointDistance()} contiene δ(s, v), cioè il peso
 *       del cammino minimo dalla sorgente s a v (Double.POSITIVE_INFINITY se
 *       v non è raggiungibile).</li>
 *   <li>{@code v.getPrevious()} contiene il predecessore di v nell'albero
 *       dei cammini minimi (null per la sorgente e per i nodi non raggiungibili).</li>
 *   <li>{@code v.getColor()} è {@code GraphNode.COLOR_BLACK} per tutti i nodi
 *       estratti dalla coda durante l'esecuzione.</li>
 * </ul>
 *
 * Pseudocodice (Cormen, DIJKSTRA):
 * <pre>
 *   INITIALIZE-SINGLE-SOURCE(G, s)
 *   S = ∅
 *   Q = V[G]
 *   mentre Q ≠ ∅:
 *     u = EXTRACT-MIN(Q)
 *     S = S ∪ {u}
 *     per ogni v in Adj[u]:
 *       RELAX(u, v, w)
 * </pre>
 *
 * @author Luca Tesei, Federico Di Petta (template)
 *         INSERIRE NOME, COGNOME ED EMAIL xxxx@studenti.unicam.it DELLO STUDENTE
 *         (implementazione)
 *
 * @param <L>
 *                tipo delle etichette dei nodi del grafo
 */
public class DijkstraSP<L> {

    /*
     * Coda con priorità realizzata come semplice ArrayList.
     * Contiene i nodi non ancora estratti (non ancora in S).
     * La priorità è data da floatingPointDistance (d[v]).
     */
    private List<GraphNode<L>> queue;

    /**
     * Crea un nuovo oggetto DijkstraSP con coda vuota.
     */
    public DijkstraSP() {
        this.queue = new ArrayList<>();
    }

    /**
     * Calcola i cammini minimi dalla sorgente s verso tutti gli altri nodi del
     * grafo g, usando l'algoritmo di Dijkstra.
     *
     * Dopo l'esecuzione, per ogni nodo v:
     * <ul>
     *   <li>{@code v.getFloatingPointDistance()} = δ(s, v)</li>
     *   <li>{@code v.getPrevious()} = predecessore di v nel cammino minimo</li>
     *   <li>{@code v.getColor()} = {@code GraphNode.COLOR_BLACK}</li>
     * </ul>
     *
     * @param g
     *              un grafo non orientato, pesato, con pesi non negativi
     * @param s
     *              il nodo sorgente da cui calcolare i cammini minimi
     *
     * @throws NullPointerException
     *              se il grafo g o il nodo sorgente s sono null
     * @throws IllegalArgumentException
     *              se s non appartiene a g
     * @throws IllegalArgumentException
     *              se g è orientato, non pesato o con pesi negativi
     */
    public void computeSP(Graph<L> g, GraphNode<L> s) {
        // TODO implementato
        // ── Validazione ──────────────────────────────────────────────────

        if (g == null || s == null)
            throw new NullPointerException(
                    "Il grafo e il nodo sorgente non possono essere null");

        GraphNode<L> sInGraph = g.getNode(s.getLabel());
        if (sInGraph == null)
            throw new IllegalArgumentException(
                    "Il nodo sorgente non esiste nel grafo");

        if (g.isDirected())
            throw new IllegalArgumentException(
                    "Il grafo deve essere non orientato");

        for (GraphEdge<L> edge : g.getEdges()) {
            if (!edge.hasWeight())
                throw new IllegalArgumentException(
                        "Il grafo deve essere pesato");
            if (edge.getWeight() < 0)
                throw new IllegalArgumentException(
                        "I pesi non possono essere negativi");
        }

        // ── INITIALIZE-SINGLE-SOURCE(G, s)  (Cormen riga 1) ─────────────
        initializeSingleSource(g, sInGraph);

        // ── Q = V[G]  (Cormen riga 3) ────────────────────────────────────
        queue.clear();
        queue.addAll(g.getNodes());

        // ── mentre Q ≠ ∅  (Cormen righe 4-8) ────────────────────────────
        while (!queue.isEmpty()) {

            // u = EXTRACT-MIN(Q)
            GraphNode<L> u = extractMin();

            // S = S ∪ {u}  — u diventa definitivo
            u.setColor(GraphNode.COLOR_BLACK);

            // per ogni v ∈ Adj[u]: RELAX(u, v, w)
            int indexU = g.getNodeIndexOf(u.getLabel());
            for (GraphEdge<L> edge : g.getEdgesOf(indexU)) {

                // Salta i self-loop
                if (edge.getNode1().equals(edge.getNode2()))
                    continue;

                // Recupera il vicino tramite getNode() → riferimento reale garantito
                L neighborLabel = edge.getNode1().equals(u)
                        ? edge.getNode2().getLabel()
                        : edge.getNode1().getLabel();

                GraphNode<L> v = g.getNode(neighborLabel);
                if (v == null) continue;

                // Rilassa solo i nodi ancora nella coda (non ancora definitivi)
                if (queue.contains(v)) {
                    relax(u, edge, v);
                }
            }
        }
    }

    /**
     * Inizializza i campi di ogni nodo del grafo come richiesto dall'operazione
     * INITIALIZE-SINGLE-SOURCE del Cormen:
     * <ul>
     *   <li>d[v] = +∞ per ogni v ≠ s</li>
     *   <li>d[s] = 0</li>
     *   <li>π[v] = null per ogni v</li>
     *   <li>colore = WHITE per ogni v</li>
     * </ul>
     *
     * @param g
     *              il grafo da inizializzare
     * @param s
     *              il nodo sorgente (il suo riferimento REALE nel grafo)
     */
    private void initializeSingleSource(Graph<L> g, GraphNode<L> s) {
        // TODO implementato
        // Per ogni v ∈ V[G]: d[v] = +∞, π[v] = null, colore = WHITE
        for (GraphNode<L> v : g.getNodes()) {
            v.setFloatingPointDistance(Double.POSITIVE_INFINITY);
            v.setPrevious(null);
            v.setColor(GraphNode.COLOR_WHITE);
        }

        // d[s] = 0 → la sorgente ha distanza 0 da sé stessa
        // s è già il riferimento reale recuperato con g.getNode() in computeSP
        s.setFloatingPointDistance(0.0);
    }

    /**
     * Esegue l'operazione di rilassamento RELAX(u, v, w) del Cormen:
     * se d[u] + w(u,v) < d[v], aggiorna d[v] = d[u] + w(u,v) e π[v] = u.
     *
     * @param u
     *              il nodo corrente (già estratto dalla coda)
     * @param edge
     *              l'arco tra u e v (contiene il peso w(u,v))
     * @param v
     *              il nodo vicino da eventualmente aggiornare
     */
    private void relax(GraphNode<L> u, GraphEdge<L> edge, GraphNode<L> v) {
        // TODO implementato
        double weight = edge.getWeight();

        // RELAX(u, v, w) del Cormen:
        // se d[u] + w(u,v) < d[v]:
        //     d[v] = d[u] + w(u,v)
        //     π[v] = u
        if (u.getFloatingPointDistance() + weight < v.getFloatingPointDistance()) {
            v.setFloatingPointDistance(u.getFloatingPointDistance() + weight);
            v.setPrevious(u);
        }
    }

    /**
     * Estrae dalla coda il nodo con d[v] (floatingPointDistance) minima.
     * Corrisponde a EXTRACT-MIN sulla coda con priorità.
     * Complessità O(n) — accettabile perché non è richiesta ottimizzazione.
     *
     * @return il nodo con distanza minima, rimosso dalla coda
     */
    private GraphNode<L> extractMin() {
        // TODO implementato
        GraphNode<L> min = queue.get(0);

        for (GraphNode<L> node : queue) {
            if (node.getFloatingPointDistance() < min.getFloatingPointDistance()) {
                min = node;
            }
        }

        queue.remove(min);
        return min;
    }
}
