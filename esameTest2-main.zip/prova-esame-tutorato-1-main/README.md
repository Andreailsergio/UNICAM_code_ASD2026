## Prova d'esame tutorato



Implementare



in MatrixGraph.java i metodi:

removeEdge(int i, int j)

getAdjacentNodesOf(L label)



in PrimMSP :

completare import di librerie

import java.util.ArrayList;

import java.util.List;

// import java.util.Set;



definire variabili necessarie:

this.queue = new ArrayList<>();



implementare:

computeMSP(Graph<L> g, GraphNode<L> s)

\[aggiunta del metodo extractMin()]

