**Struttura dell'esercizio**

KruskalMSP.java — **4 metodi da implementare**



**computeMSP(Graph<L> g)** — il metodo principale. Deve validare il grafo, ordinare gli archi per peso crescente, e applicare il ciclo greedy di Kruskal usando i tre metodi privati.



**makeSet(Set<GraphNode<L>> nodes)** — inizializza la Union-Find: ogni nodo diventa un singleton con parent\[v] = v e rank\[v] = 0. Corrisponde a MAKE-SET del Cormen per tutti i vertici.



**findSet(GraphNode<L> v)** — risale alla radice dell'albero Union-Find applicando la path compression: collega direttamente ogni nodo incontrato alla radice. Corrisponde a FIND-SET del Cormen.



**union(GraphNode<L> u, GraphNode<L> v)** — fonde i due insiemi con union-by-rank: l'albero di rango minore viene attaccato sotto quello di rango maggiore; a parità di rango si incrementa il rango della nuova radice. Corrisponde a UNION del Cormen.



KruskalMSPTest.java — **8 test**

**Test					Cosa verifica**

testExceptions				NullPointerException e IllegalArgumentException

testGetMstEdgesBeforeCompute		getMstEdges() restituisce null prima della chiamata

testSingleNode				grafo con un nodo → MST vuoto

testTwoNodes				grafo con due nodi connessi → 1 arco

testTwoNodesDisconnected		grafo sconnesso → foresta vuota

testKruskal1				grafo 9 nodi del Cormen, verifica ogni arco dell'MST

testKruskal2				grafo 4 nodi, stesso dell'esempio Prim

testKruskalTriangle			grafo triangolo, verifica esclusione arco più pesante

testKruskalEqualWeights			pesi uguali: MST valido tra i possibili

testComputeOverwrite			chiamate successive sovrascrivono correttamente

