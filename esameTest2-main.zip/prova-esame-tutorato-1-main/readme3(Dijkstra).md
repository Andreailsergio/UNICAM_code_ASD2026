**Struttura dell'esercizio**

DijkstraSP.java — **4 metodi da implementare**

**computeSP(Graph<L> g, GraphNode<L> s)** — metodo principale. Valida il grafo, chiama initializeSingleSource, popola la coda, esegue il ciclo principale estraendo il minimo e chiamando relax su ogni arco incidente.



**initializeSingleSource(Graph<L> g, GraphNode<L> s)** — corrisponde a INITIALIZE-SINGLE-SOURCE del Cormen: imposta d\[v] = +∞ e π\[v] = null per tutti i nodi, poi d\[s] = 0. Importante usare il riferimento reale di s recuperato dal grafo.



**relax(GraphNode<L> u, GraphEdge<L> edge, GraphNode<L> v)** — il cuore dell'algoritmo: se d\[u] + w(u,v) < d\[v] aggiorna d\[v] e π\[v] = u. Il peso viene letto direttamente dall'arco (edge.getWeight()).



**extractMin()** — scansione lineare della coda per trovare il nodo con floatingPointDistance minima, poi rimozione e restituzione. O(n) accettabile come in PrimMSP.



**Differenza chiave rispetto a Prim**

**Aspetto						Prim					Dijkstra**

Cosa memorizza in floatingPointDistance		peso dell'arco verso l'MST		distanza cumulativa da s

Aggiornamento in relax/DECREASE-KEY		weight < v.key				d\[u] + weight < d\[v]

previous punta a				predecessore nell'MST			predecessore nel cammino minimo

Obiettivo					minimizza peso totale albero		minimizza distanza da sorgente



DijkstraSPTest.java — **8 test**

**Test				Cosa verifica**

testExceptions			NullPointerException e IllegalArgumentException

testSingleNode			grafo con un nodo → d=0, predecessore null

testTwoNodes			due nodi connessi → distanza e predecessore corretti

testDisconnectedNode		nodo irraggiungibile → d=+∞, predecessore null

testDijkstra1FromA		grafo principale corso, da A: tutte le 6 distanze e predecessori

testDijkstra2FromB		stesso grafo da B: distanze e predecessori

testDijkstra3FromE		stesso grafo da E: distanze e predecessori

testChainGraph			catena A-B-C-D: verifica accumulo distanze

testShortcut			triangolo con scorciatoia: Dijkstra deve scegliere il percorso indiretto più breve

testComputeOverwrite		chiamate successive sovrascrivono correttamente

testDijkstraLargeGraph		grafo 9 nodi del Cormen (stesso di PrimMSP)

