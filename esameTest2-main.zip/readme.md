BASE

&#x09;INTRO: https://unicam.webex.com/unicam/ldr.php?RCID=5d35680c72cade8a2dfbb493a28c5942



1\.	Equazione 2° grado modificabile con risolutore (programmazione OO e testing JUnit)

https://github.com/unicam-cs-algorithms-lab/esercitazione-1-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es1.git

https://github.com/unicam-cs-algorithms-lab/es1-sol

https://unicam.webex.com/unicam/ldr.php?RCID=f271784d2aab435f2056ba01c707a470



2\.	Cassaforte combination\_lock e scassinatore burglar \[Macchina astratta, hashCode, equals oppure comparable compareTo, toString() x creare una stringa di descrizione dell’oggetto – diverso da systems.out]

https://github.com/unicam-cs-algorithms-lab/esercitazione-2-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es2.git

https://github.com/unicam-cs-algorithms-lab/es2-sol

https://unicam.webex.com/unicam/ldr.php?RCID=8a4344e37ce908954c3cbd4cf1a417a4



3\.	Prenotazioni e TimeSlot = intervallo di tempo continuo – non può essere 0 (equals + compareTo + hashCode + toString \_ utilizzare una classe predefinita: Calendar – classe in api java.util basata sul calendario Gregoriano che introduce i bisestili tranne per gli anni divisibili per 400 - 0 è l’ora 0 del 01/01/1970; 1 è 0 + 1 millisecondo / interfacce polimorfismo / codice generico con ARRAY)

I numeri dei mesi partono da 0

start e stop definiscono i momenti di inizio calendario e fine calendario (il TimeSlot)

start 10:00 stop 13:00 (dello stesso giorno) – viene prima di start 11:00 stop 13:00 (stesso giorno)

start 10:00 stop 12:00 (stesso giorno) – viene prima di start 10:00 stop 13:00 (stesso giorno)

start e stop uguali sono equals

overlapsWith dati due timeslot dice se si sovrappongono (ma c’è una tolleranza di 5 minuti preimpostata per cui la sovrapposizione non rileva) public static final int MINUTES\_OF\_TOLERANCE\_FOR\_OVERLAPPING = 5

getMinutesOfOverlappingWith calcola di quanti minuti – troncati per difetto - è la sovrapposizione (se c’è)

Prenotazione: prende timeslot aula docente e motivo \[aula A viene prima di aula B]

https://github.com/unicam-cs-algorithms-lab/esercitazione-3-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es3.git

https://github.com/unicam-cs-algorithms-lab/es3-sol

https://unicam.webex.com/unicam/ldr.php?RCID=7254090f1e6f89970cb1f3f78d010464



4\.	Aule, prenotazione, facilities (ereditarietà / eccezioni / codice generico con LISTE)

https://github.com/unicam-cs-algorithms-lab/esercitazione-4-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es4.git

https://github.com/unicam-cs-algorithms-lab/es4-sol

https://github.com/unicam-cs-algorithms-lab/ereditarieta

https://github.com/unicam-cs-algorithms-lab/gestione-delle-eccezioni

https://unicam.webex.com/unicam/ldr.php?RCID=d217acf543f42c2f05a85aadd6dbda46



5\.	Collections Java SE: Set, Map e Sorted Set

https://github.com/unicam-cs-algorithms-lab/esercitazione-5-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es5.git

https://github.com/unicam-cs-algorithms-lab/es5-sol

https://github.com/unicam-cs-algorithms-lab/collections





STRUTTURE DATI E ORDINAMENTI

6\.	Liste concatenate (utili in tabelle Hash e Graph)

https://github.com/unicam-cs-algorithms-lab/esercitazione-6-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es6.git

https://github.com/unicam-cs-algorithms-lab/es6-sol

https://unicam.webex.com/unicam/ldr.php?RCID=080007f65e3919ccff143f149ef72dc4



\*  qual è il senso di metodi con stesso nome: 

&#x20;         --- add(E e)  con ritorno di boolean: che differenza c'è con public void add(int index, E element)

&#x20;         --- remove(Object o) con ritorno di boolean: che differenza c'è con public E remove(int index)

1\. add(E e) vs add(int index, E element) — e remove(Object o) vs remove(int index)

Sono metodi con lo stesso nome ma firma diversa: è l'overloading di Java. Il compilatore sceglie quale chiamare in base ai parametri che passi.

boolean add(E e) — aggiunge in coda

Node<E> n = new Node<E>(e, null);

// se vuota: head = tail = n

// altrimenti: tail.next = n; tail = n

this.size++;

this.numeroModifiche++;

return true;

Aggiunge sempre in fondo alla lista. Restituisce boolean perché così impone l'interfaccia Collection di Java (in teoria potrebbe fallire, in pratica qui restituisce sempre true).

void add(int index, E element) — aggiunge in posizione specifica

// scorre fino all'indice, aggiusta i puntatori next

// può inserire in testa, in coda, o in mezzo

this.size++;

this.numeroModifiche++;

// non restituisce nulla

Puoi scegliere dove inserire. Restituisce void perché non c'è nulla di utile da restituire: l'indice lo hai già fornito tu.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

boolean remove(Object o) — rimuove per valore

int index = this.indexOf(o);   // cerca il valore

if (index == -1) return false; // non trovato

this.remove(index);            // delega alla versione per indice

return true;

Cerca il primo elemento uguale a o (usando equals) e lo elimina. Restituisce boolean per dirti se l'elemento esisteva oppure no.

E remove(int index) — rimuove per posizione

// scorre fino all'indice, scollega il nodo

this.size--;

this.numeroModifiche++;

return n.item;  // restituisce l'elemento eliminato

Sai già dove vuoi rimuovere. Restituisce l'elemento rimosso — utile perché magari vuoi usarlo dopo averlo tolto.



Riassunto comparativo

Metodo	Come identifica l'elemento	Ritorno	Quando usarlo

add(E e)	—	boolean	Aggiungere in coda

add(int index, E e)	posizione	void	Aggiungere in un punto preciso

remove(Object o)	valore (equals)	boolean	Rimuovere un elemento di cui conosci il valore

remove(int index)	posizione	E (elemento rimosso)	Rimuovere un elemento di cui conosci l'indice





\*  che differenza c'è tra IndexOf e lastIndexOf (che restituiscono entrambi intero indice)

Entrambi restituiscono l'indice di un elemento nella lista, ma cercano in modo diverso in presenza di duplicati.

indexOf — prima occorrenza

while (n != null) {

&#x20;   index++;

&#x20;   if (o.equals(n.item))

&#x20;       return index;   // si ferma appena trova

&#x20;   else

&#x20;       n = n.next;

}

return -1;

Scorre da sinistra, si ferma al primo elemento uguale e restituisce quell'indice.

lastIndexOf — ultima occorrenza

while (n != null) {

&#x20;   index++;

&#x20;   if (o.equals(n.item))

&#x20;       lastIndex = index;  // aggiorna ma NON si ferma

&#x20;   n = n.next;             // continua sempre

}

return lastIndex;

Scorre tutta la lista, aggiornando lastIndex ogni volta che trova una corrispondenza. Alla fine restituisce l'indice dell'ultima occorrenza trovata. Se l'elemento non c'è, lastIndex è rimasto a -1.

Esempio con lista \[A, B, A, C, A]

Metodo	Risultato

indexOf("A")	0 (primo)

lastIndexOf("A")	4 (ultimo)

indexOf("D")	-1

lastIndexOf("D")	-1



\*  a che serve numeroModifiche e i suoi incrementi

È il meccanismo che rende l'iteratore fail-fast.

Il problema da risolvere

Immagina di stare iterando sulla lista con un for-each e, nel mezzo del ciclo, qualcuno modifica la lista (aggiunge o rimuove elementi). L'iteratore potrebbe saltare elementi, restituire dati sbagliati, o andare in loop infinito. Questo è pericoloso e difficile da debuggare.

La soluzione

// Campo della lista:

private int numeroModifiche;   // parte da 0



// Viene incrementato in ogni metodo che modifica strutturalmente la lista:

// add(E e), add(int,E), remove(Object), remove(int), clear()

this.numeroModifiche++;



// Nel costruttore dell'iteratore:

this.numeroModificheAtteso = SingleLinkedList.this.numeroModifiche;

// "fotografa" il valore attuale



// In next():

if (this.numeroModificheAtteso != SingleLinkedList.this.numeroModifiche)

&#x20;   throw new ConcurrentModificationException(...);

In parole semplici

Quando crei l'iteratore, esso "ricorda" il numero di modifiche in quel momento. Ad ogni chiamata di next() controlla: "la lista è cambiata da quando sono nato?". Se sì, lancia subito l'eccezione invece di produrre risultati inconsistenti.

set() non incrementa numeroModifiche perché non è una modifica strutturale: non cambia quanti nodi ci sono, cambia solo il valore dentro un nodo esistente.



\* come funziona l'iteratore (SINTASSI e SIGNIFICATO):

&#x20;        che cosa fa con cicli for tipo:

&#x20;        for (E el : this) {result\[i] = el;  i++; }

4\. Come funziona l'iteratore

Struttura della classe Itr

private class Itr implements Iterator<E> {

&#x20;   private Node<E> lastReturned;       // ultimo nodo restituito

&#x20;   private int numeroModificheAtteso;  // "fotografia" al momento della creazione

}

È una classe interna non-statica: può accedere ai campi di SingleLinkedList (come head e numeroModifiche) usando la sintassi SingleLinkedList.this.nomeCampo.

hasNext()

if (this.lastReturned == null)

&#x20;   return SingleLinkedList.this.head != null;  // mai partiti: c'è una testa?

else

&#x20;   return lastReturned.next != null;           // partiti: c'è un prossimo?

lastReturned == null significa che non è ancora stato chiamato next() nemmeno una volta.

next()

// 1. Controllo fail-fast

if (this.numeroModificheAtteso != SingleLinkedList.this.numeroModifiche)

&#x20;   throw new ConcurrentModificationException(...);



// 2. Se è il primo next(): parto da head

if (this.lastReturned == null) {

&#x20;   this.lastReturned = SingleLinkedList.this.head;

&#x20;   return SingleLinkedList.this.head.item;

}

// 3. Altrimenti avanzo di un nodo

lastReturned = lastReturned.next;

return lastReturned.item;

Il for-each — sintassi e significato

// E è il parametro di tipo generico della classe SingleLinkedList<E>. Quando scrivi SingleLinkedList<String>, E diventa String, quindi il for-each diventa concettualmente for (String el : this). È il tipo di ogni elemento che l'iteratore restituirà ad ogni passo.

// el è la variabile di ciclo

È una variabile locale dichiarata lì sul momento, che ad ogni iterazione riceve il valore restituito da it.next(). Puoi chiamarla come vuoi — el, elemento, x, ecc. — esiste solo dentro le { } del ciclo.

// : this — la cosa su cui iterare

I due punti si leggono "di" o "in": "per ogni elemento di this".

this qui è l'oggetto SingleLinkedList stesso. Il for-each può usare this (o qualsiasi altra espressione) solo se quella cosa implementa Iterable<E>, cioè solo se ha un metodo iterator(). La classe SingleLinkedList implementa List<E>, che estende Iterable<E>, quindi è lecito.

for (E el : this) {

&#x20;   result\[i] = el;

&#x20;   i++;

}

Il compilatore Java traduce automaticamente questo for-each in:

Iterator<E> it = this.iterator();   // chiama iterator() → crea un Itr

while (it.hasNext()) {

&#x20;   E el = it.next();               // avanza di un nodo e restituisce l'elemento

&#x20;   result\[i] = el;

&#x20;   i++;

}

Funziona perché SingleLinkedList implementa Iterable<E> (tramite List<E>), cioè ha il metodo iterator() che restituisce un Itr. Il for-each è quindi solo zucchero sintattico per rendere questo pattern più leggibile.

Normalmente scrivi:

for (E el : myList) { ... }

dove myList è una variabile che contiene una lista. Qui invece il for-each è dentro un metodo della lista stessa, quindi this è la lista corrente — è esattamente equivalente, solo che non c'è un nome di variabile separato.





\* come funzionano le dichiarazioni di variabili oggetto come queste

&#x20;        <SingleLinkedList<?> other = (SingleLinkedList<?>) obj;

SingleLinkedList<?> other = (SingleLinkedList<?>) obj;

Si scompone in due parti:

Il tipo <?> (wildcard) significa "lista di qualcosa, non so cosa". Si usa quando non importa il tipo preciso degli elementi, ma vuoi comunque chiamare metodi sulla lista (come iterator()). Non puoi scrivere SingleLinkedList<E> perché obj potrebbe essere una SingleLinkedList<String> mentre this è una SingleLinkedList<Integer>: in equals vuoi solo confrontare gli elementi con equals(), non importa il tipo generico.

Il cast (SingleLinkedList<?>) obj è necessario perché obj è dichiarato come Object: il compilatore non sa che è una SingleLinkedList finché non fai il cast esplicitamente (dopo aver verificato con instanceof).





&#x20;        Node<E> n = new Node<E>(e, null);

Node<E> n = new Node<E>(e, null);

private static class Node<E> {

&#x20;   private E item;

&#x20;   private Node<E> next;

&#x20;   Node(E item, Node<E> next) { ... }

}

Node<E> è una classe interna generica: rappresenta un singolo nodo della lista che contiene un elemento di tipo E. La riga:

Node<E> n = new Node<E>(e, null);

si legge così: "crea un nuovo nodo che contiene l'elemento e come valore, e null come puntatore al nodo successivo" — cioè un nodo isolato, senza successore, pronto per essere agganciato in coda. Il <E> ripetuto sia nel tipo della variabile che nella new garantisce la coerenza di tipo a tempo di compilazione.





7\.	Hashtable con vettore bucket resizable per collisioni

https://github.com/unicam-cs-algorithms-lab/es6-sol

https://github.com/unicam-cs-algorithms-lab/es7.git

https://github.com/unicam-cs-algorithms-lab/es7-sol

https://unicam.webex.com/unicam/ldr.php?RCID=a51e08d2c015eac9491ea7f4327efb5f



Significato di public boolean addAll(Collection<? extends E> c)

public boolean addAll(Collection<? extends E> c)

Collection<? extends E> è il punto chiave. Si scompone così:

Collection<...> — accetta qualsiasi collezione (lista, set, coda, ecc.), non solo una CollisionListResizableHashTable.

? extends E — wildcard con upper bound. Significa: "una collezione il cui tipo di elemento è E oppure una sottoclasse di E". Esempio concreto: se la hash table è CollisionListResizableHashTable<Animale>, puoi passarle una List<Cane> (dove Cane extends Animale), perché ogni Cane è anche un Animale e può essere inserito. Senza il ? extends, potresti passare solo esattamente Collection<Animale>.

boolean — restituisce true se il set è stato modificato (cioè se almeno un elemento è stato effettivamente aggiunto), false se tutti gli elementi erano già presenti.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Come funziona il corpo

boolean changed = false;

Iterator<? extends E> iter = c.iterator();

while (iter.hasNext()) {

&#x20;   E item = iter.next();          // ogni elemento di c è assegnabile a E

&#x20;   if (item == null)

&#x20;       throw new NullPointerException(...);

&#x20;   changed = changed | this.add(item);   // OR non pigro

}

return changed;

E item = iter.next() — funziona perché la wildcard ? extends E garantisce che ogni elemento estratto sia compatibile con E. Il compilatore lo accetta.

changed | this.add(item) — usa l'OR non pigro (| invece di ||). La differenza è cruciale:

•	|| (pigro): se changed è già true, non valuta il lato destro → add() non verrebbe mai chiamato per gli elementi successivi al primo inserito.

•	| (non pigro): valuta sempre entrambi i lati → add() viene chiamato per ogni elemento, garantendo che tutti vengano davvero inseriti.



Spiega come funziona l’Iteratore di una collection 

Iterator<? extends E> iter = c.iterator();

while (iter.hasNext()) {…}

Il meccanismo generale

Qualsiasi classe che implementa Collection (e quindi Iterable) deve avere un metodo iterator() che restituisce un oggetto Iterator. Quando scrivi:

Iterator<? extends E> iter = c.iterator();

while (iter.hasNext()) {

&#x20;   E item = iter.next();

&#x20;   ...

}

stai usando l'iteratore di c, qualunque sia la sua implementazione interna. Non ti interessa se c è una ArrayList, una HashSet, o altro: ti basta che abbia hasNext() e next().

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Iterator<? extends E> — perché la wildcard anche qui?

Iterator<? extends E> iter = c.iterator();

Perché c è Collection<? extends E>, il suo iterator() restituisce un Iterator<? extends E>, non un Iterator<E>. Il tipo si "propaga". Però:

E item = iter.next();

funziona comunque, perché ? extends E garantisce che ciò che viene estratto è assegnabile a E.

Confronta con containsAll e removeAll nello stesso file, dove la collection è Collection<?> (nessun bound), quindi l'iteratore è Iterator<?> e ogni elemento viene estratto come Object:

// In containsAll e removeAll:

Iterator<?> iter = c.iterator();

Object item = iter.next();   // tipo Object, non E

La differenza è che in addAll devi inserire gli elementi nella hash table di tipo E, quindi serve il tipo E (o un suo sottotipo). In containsAll e removeAll non inserisci nulla: usi solo equals(), che è un metodo di Object, quindi basta Object.

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Come funziona l'iteratore interno Itr di questa hash table

Questo iteratore è più complesso di quello della SingleLinkedList perché deve navigare un array di liste concatenate — non una singola catena lineare.

Tiene traccia di due cose:

private int currentPos;    // quale bucket dell'array stiamo visitando

private Node<E> lastNode;  // quale nodo della lista di collisioni corrente

hasNext() — scorre l'array saltando i bucket null finché non trova un bucket non vuoto. Se lastNode è già nel mezzo di una lista di collisioni, controlla se c'è un next. Se ha esaurito la lista corrente, avanza currentPos e si richiama ricorsivamente.

next() — dopo che hasNext() ha posizionato currentPos correttamente:

•	se lastNode == null: prende il primo nodo del bucket corrente.

•	altrimenti: avanza di un nodo nella lista di collisioni corrente.

Schema visivo

table\[0]  →  null

table\[1]  →  \[A] → \[B] → null

table\[2]  →  null

table\[3]  →  \[C] → null

table\[4]  →  null



Iteratore visita:  A, B, C

&#x20;                  ↑        ↑

&#x20;             currentPos=1  currentPos=3

L'ordine degli elementi restituiti dall'iteratore non è prevedibile (dipende dalla funzione di hash), ma ogni elemento presente viene restituito esattamente una volta.

&#x20;ereditarieta-main





gestione-delle-eccezioni-main





8\.	Ricorsioni su Liste e BST

https://github.com/unicam-cs-algorithms-lab/esercitazione-8-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es8.git

https://github.com/unicam-cs-algorithms-lab/es8-sol

https://unicam.webex.com/unicam/ldr.php?RCID=dd33884cadb56f14122b488c095b6c9e







9\.	Algoritmi di ordinamento: quicksort (fisso e random), mergesort, insertionsort (+ excel x calcolo tempo computazionale)

https://github.com/unicam-cs-algorithms-lab/esercitazione-9-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es9.git

https://github.com/unicam-cs-algorithms-lab/es9-sol

https://unicam.webex.com/unicam/ldr.php?RCID=548c2e5b1c2bc2bd59c2dd35470b7563





10\.	Heap (max, min) e heapsort

https://github.com/unicam-cs-algorithms-lab/esercitazione-10-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es10.git

https://github.com/unicam-cs-algorithms-lab/es10sol

https://unicam.webex.com/unicam/ldr.php?RCID=921f67d33ae9b7c3db9e40656c17f3e1 





11\.	Programmazione dinamica (moltiplicazione matriciale con memoizzazione)

https://github.com/unicam-cs-algorithms-lab/esercitazione-11-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es11.git

https://github.com/unicam-cs-algorithms-lab/es11-sol

https://drive.google.com/file/d/1g4IOTOo\_j4uu\_9rQwpnejpTVCb0\_Tva7/view?usp=sharing

https://drive.google.com/file/d/1L-Eii8UfmEKbm94bD6WFM7DyDFLvFqfs/view?usp=sharing

https://drive.google.com/file/d/1Iuix36xSEMR518VcqEQ9hjK1fhsdFQ2k/view?usp=sharing





12\.	Grafi: liste adiacenza, visite BFS e DFS, MST Prim

https://github.com/unicam-cs-algorithms-lab/esercitazione-12-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es12.git

https://github.com/unicam-cs-algorithms-lab/es12-sol

https://drive.google.com/file/d/1zUBbVp1Y9JsKuU4Ug7TnP7e2q-m\_QavC/view?usp=sharing

https://drive.google.com/file/d/15PwdwLwF8DWQcjRiOG2AgN6Il3\_m48wD/view?usp=sharing

https://drive.google.com/file/d/1rO37rSjjFwr7XnNNpoyUz-FuTwKzH9B7/view?usp=sharing



13\.	Grafici: matrici adiacenza, Cammino più corto Dijkstra

https://github.com/unicam-cs-algorithms-lab/esercitazione-13-Andreailsergio

https://github.com/unicam-cs-algorithms-lab/es13.git

https://github.com/unicam-cs-algorithms-lab/es13-sol

https://drive.google.com/file/d/1wdNocLRFisQ87-zOMK4Ew9KhXvPNjvqA/view?usp=sharing

https://drive.google.com/file/d/1UCIiy2fGaKIkYDzswdsxx95wzh1V6qEX/view?usp=sharing

https://drive.google.com/file/d/1RoEwLJU5AOiO2F6fxPXdJx-M2uCc2gzH/view?usp=sharing

https://drive.google.com/file/d/1cbogvIbS\_pXB9tlixNqTmEaeQ2r96Q2C/view?usp=sharing

https://drive.google.com/file/d/1qXzr6sS5b7OGvgpl42Ts6\_882LB\_iANe/view?usp=sharing

https://drive.google.com/file/d/1rz\_d1AFd2Slc0CyCQhYV0yZMfmPMxG3V/view?usp=sharing



PROVE ESAME (varianti)

•	BST normale \& reverse

•	AVL

•	Pile e code / Heap (min e max) / Heapsort

•	Mergesort decrescente



•	Memoizzazione – matrix

•	Hash e liste circolari

•	Grafi



