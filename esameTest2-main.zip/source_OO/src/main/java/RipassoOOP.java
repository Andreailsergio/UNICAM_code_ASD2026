// package it.unicam.cs.asdl2526.ripasso;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

// =============================================================================
// RIPASSO OOP JAVA — tema: libreria musicale
// Argomenti: interfacce, polimorfismo, casting, ereditarietà,
//            gestione eccezioni, generics, collections
// Stile: corso ASDL UNICAM, prof. Tesei
// =============================================================================

// NOTE SU GENERICS, EREDITARIETA', COLLECTIONS
// 0)
// PRINCIPIO DI INCAPSULAMENTO ogni classe espone solo ciò che serve, nascondendo i dettagli interni
// Le variabili (ma vale anche per metodi o classi) sono dichiarate:
// - private (interne solo a costruttore/classe) o public (esposte all'esterno x permettere lettura e scrittura)
//      in realtà ci sono più opzioni (alcune più rare: protected è per esigenze di test JUnit):
//                          Stessa    Stesso     Sottoclasse    Sottoclasse    Altro (anche non sottocl.)
//                          classe    package    stesso pkg     altro pkg      altro pkg
// private                    ✓          ✗            ✗              ✗             ✗
// (default)                  ✓          ✓            ✓              ✗             ✗
// protected                  ✓          ✓            ✓              ✓             ✗
// public                     ✓          ✓            ✓              ✓             ✓
// - per tipo restituito (es. int, String, double, boolean)
//      o void (se metodo non restituisce nulla con return)
// - static (condivise da tutte le istanze della classe)
//      senza "static" ogni oggetto creato genera una sua copia
// - final (immutabilità dopo la prima inizializzazione)
//      senza "final" è possibile riassegnare valori
// ---> una variabile public static final è una costante universale
//      (valore condiviso da tutto il programma, accessibile da ovunque, che non cambia mai)
//      per convenzione si scrivono in MAIUSCOLO_CON_UNDERSCORE
//
// 1)
// <T> o <E> sono solo etichette diverse per lo stesso concetto — il tipo generico — scelte per leggibilità
// a seconda del contesto useremo:
// T (sta per Type) -> per indicare il tipo di una classe generale "contenitore".
//          class Contenitore<T extends ElementoMusica> { ... }
// E (sta per Element) -> per lavorare con metodi che trattano "elementi" delle collezioni
//    (ad es. di Liste List<E> = sequenze ordinate di elementi accessibili per indice,
//    di insiemi senza duplicati Set<E>, di Dizionari con coppie chiave-valore Map<K,V>).
//          public static <E extends ElementoMusica> List<E> intersezione(...) { ... }
// K (Key) e V (Value) -> per lavorare con la chiave o il valore di una Mappa Map.
// L (sta per Label) -> etichetta di un nodo/grafo
//  es. class GraphNode<L> {
//                      ↑
//                      └─ "Questa classe lavora con un tipo generico
//                          che chiamo L (Label). Il tipo vero lo decide chi la usa."
//
//      GraphNode<String> n = new GraphNode<>("ciao");
//                  ↑
//                  └─ "In QUESTO oggetto, L = String"
//
// 2)
// - uso List<T> per memorizzare una sequenza di oggetti in un contenitore di dati
//          private final List<T> elementi;
// - uso Iterator<T> non per creare una nuova collezione, ma per avere un meccanismo
//    con cui scorrere uno alla volta (con for-each) i dati di una collezione che ho già
//          NB Iterable e Iterator sono interfacce specifiche definite nei package java.lang e java.util
//          anche il metodo iterator() va richiamato con quel nome specifico, così come hasNext() e next()
//
//          class Contenitore<T extends ElementoMusica> implements Iterable<T>
//
//          @Override
//          public Iterator<T> iterator() { return elementi.iterator(); }
//
//          Contenitore<Brano> playlist = new Contenitore<>("MyPlaylist");
//          for (Brano b : playlist) {  // playlist è la "collezione" ... }
//
// 3)
// Distinguere le Interfacce (il "cosa") dalle Implementazioni reali (il "come")
// - List<E>  -> ArrayList<E> (permette accesso veloce per indice, ammette duplicati)
// - Set<E>   -> HashSet<E> (accesso veloce con hash, non ordinato) o TreeSet<E> (ordinato, grazie a Comparable)
// - Map<K,V> -> HashMap<K,V> (accesso veloce con hash, non ordinato) o TreeMap<K,V> (ordinato per chiave)
//
// es. pratico
//      List<String> lista = new ArrayList<String>(); // dichiaro con l'interfaccia e creo con implementazione
//        ↑ tipo dichiarato         ↑ tipo reale
//      lista.add("ciao");
//
// 4)
// Le Collections non sono collezioni, ma una classe di utilità, con metodi statici per lavorare su collezioni
// ad es.   Collections.sort(lista);        // ordina una List
//          Collections.reverse(lista);     // inverte l'ordine
//          Collections.max(lista);         // trova il massimo

// =============================================================================
// 1. INTERFACCE
//    Un'interfaccia definisce un contratto (metodi pubblici astratti).
//    Una classe che la implementa si impegna a fornire quei metodi.
// =============================================================================

/**
 * Qualsiasi elemento della libreria che può essere riprodotto.
 * Nota: i metodi di un'interfaccia sono implicitamente public abstract.
 */
interface Riproducibile {
    void riproduci();            // ogni classe che implementa deve fornire questo
    double getDurata();          // durata in minuti
}

/**
 * Elemento che può essere valutato con un voto da 1 a 5.
 * Un'interfaccia può avere un metodo default (implementato direttamente).
 */
interface Valutabile {
    int getVoto();               // da implementare nella classe concreta

    /**
     * Metodo default: disponibile a tutte le classi che implementano l'interfaccia
     * senza doverlo riscrivere. Può essere sovrascritto (override).
     */
    default String getStelle() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < getVoto(); i++)
            s.append("★");
        for (int i = getVoto(); i < 5; i++)
            s.append("☆");
        return s.toString();
    }
}

/**
 * Interfaccia per elementi che possono essere confrontati per ordinamento.
 * T è un tipo parametrico: un segnaposto che verrà sostituito con un tipo reale quando si usa l'interfaccia.
 * Imponendo Comparable<T extends ElementoMusica> non accettiamo più qualsiasi tipo, ma obblighiamo che T sia
 * un sottotipo di ElementoMusica (bounded type parameter),
 * cioè ad es. un brano, un album, un podcast (ma non una String o un Integer)
 * Inoltre estendiamo anche Comparable<T> un'interfaccia generica della libreria Java standard
 * che ci consentirà di utilizzare il metodo compareTo(T variabile_parametro),
 * in modo che gli oggetti di questa classe sapranno confrontarsi tra loro per capire il loro ordine naturale.
 *
 * es. public int compareTo(Brano titolo_passato)
 * { return this.getTitolo().compareTo(titolo_passato.getTitolo());}
 * Se this fosse Brano("Bohemian Rhapsody", ...) e titolo_passato fosse Brano("Hotel California", ...)
 * compareTo restiruirebbe un valore negativo (this viene prima).
 * Se i titoli fossero uguali compareTo restituirebbe 0.
 * Restituirebbe un valore positivo invece se il titolo_passato venise prima, ad es. Brano("Angie", ...)
 *
 * Il metodo equals servirà a definire su che basi effettuare il confronto
 * (nel nostro caso per titolo e a parità per artista).
 */
interface Catalogabile<T extends ElementoMusica> extends Comparable<T> {
    String getTitolo();
    String getArtista();
}


// =============================================================================
// 2. CLASSI ASTRATTE ed EREDITARIETÀ
//    Una classe astratta può avere sia metodi astratti (da implementare nelle
//    sottoclassi) sia metodi concreti (già implementati, ereditati).
//    Non può essere istanziata direttamente.
// =============================================================================

/**
 * Classe astratta base per ogni elemento della libreria musicale.
 * Implementa Riproducibile e Catalogabile, ma lascia alcuni metodi
 * astratti da completare nelle sottoclassi.
 */
abstract class ElementoMusica
        implements Riproducibile, Catalogabile<ElementoMusica> {

    // Campi privati: accessibili solo tramite i getter (encapsulation)
    private final String titolo;
    private final String artista;
    private final int annoPubblicazione;

    /**
     * Costruttore della classe astratta.
     * Le sottoclassi lo invocano con super(...).
     *
     * @param titolo             titolo dell'elemento
     * @param artista            nome dell'artista
     * @param annoPubblicazione  anno di pubblicazione
     * @throws NullPointerException     se titolo o artista sono null
     * @throws IllegalArgumentException se l'anno è fuori range
     */
    public ElementoMusica(String titolo, String artista, int annoPubblicazione) {
        if (titolo == null)
            throw new NullPointerException("Il titolo non può essere null");
        if (artista == null)
            throw new NullPointerException("L'artista non può essere null");
        if (annoPubblicazione < 1900 || annoPubblicazione > 2100)
            throw new IllegalArgumentException(
                    "Anno non valido: " + annoPubblicazione);
        this.titolo = titolo;
        this.artista = artista;
        this.annoPubblicazione = annoPubblicazione;
    }

    // Getter — le sottoclassi li ereditano direttamente
    @Override
    public String getTitolo() { return titolo; }

    @Override
    public String getArtista() { return artista; }

    public int getAnnoPubblicazione() { return annoPubblicazione; }

    /**
     * Metodo astratto: ogni sottoclasse deve specificare il suo tipo (Brano, Album...).
     */
    public abstract String getTipo();

    /**
     * Implementazione di Comparable: ordina per artista, poi per titolo.
     * Ereditata da tutte le sottoclassi (possono fare override se vogliono).
     */
    @Override
    public int compareTo(ElementoMusica altro) {
        int cmpArtista = this.artista.compareTo(altro.artista);
        if (cmpArtista != 0) return cmpArtista;
        return this.titolo.compareTo(altro.titolo);
    }

    /**
     * equals basato su titolo + artista (uguale a GraphNode basato sull'etichetta).
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (!(obj instanceof ElementoMusica)) return false;
        ElementoMusica altro = (ElementoMusica) obj; // CASTING (downcast sicuro)
        return this.titolo.equals(altro.titolo)
                && this.artista.equals(altro.artista);
    }

    @Override
    public int hashCode() {
        return 31 * titolo.hashCode() + artista.hashCode();
    }

    @Override
    public String toString() {
        return getTipo() + " [" + artista + " - " + titolo
                + " (" + annoPubblicazione + ")]";
    }
}


// =============================================================================
// 3. SOTTOCLASSI CONCRETE — ereditarietà + polimorfismo
//    Ogni sottoclasse specializza ElementoMusica aggiungendo campi e metodi
//    propri, e implementa i metodi astratti e quelli delle interfacce.
// =============================================================================

/**
 * Un singolo brano musicale.
 * Estende ElementoMusica e implementa Valutabile (interfaccia aggiuntiva).
 */
class Brano extends ElementoMusica implements Valutabile {

    private final double durata;     // in minuti
    private final String genere;
    private int voto;                // 1-5, modificabile

    /**
     * @param titolo   titolo del brano
     * @param artista  artista
     * @param anno     anno di pubblicazione
     * @param durata   durata in minuti (deve essere positiva)
     * @param genere   genere musicale
     * @param voto     voto iniziale (1-5)
     * @throws IllegalArgumentException se durata non è positiva o voto fuori range
     */
    public Brano(String titolo, String artista, int anno,
                 double durata, String genere, int voto) {
        super(titolo, artista, anno);   // con super invoco il costruttore della superclasse
        // in altre parole richiamo gli attributi o talvolta i metodi della classe genitore superiore
        // gli attributi per poterli utilizzare (altrimenti sarebbero private)
        // i metodi se voglio chiamare il default - non il personalizzato - senza doverlo riscrivere
        if (durata <= 0)
            throw new IllegalArgumentException("Durata deve essere positiva");
        if (voto < 1 || voto > 5)
            throw new IllegalArgumentException("Voto deve essere tra 1 e 5");
        this.durata = durata;
        this.genere = genere;
        this.voto = voto;
    }

    @Override
    public double getDurata() { return durata; }

    @Override
    public String getTipo() { return "Brano"; }

    @Override
    public int getVoto() { return voto; }

    public String getGenere() { return genere; }

    /**
     * Override del metodo getStelle() di Valutabile:
     * aggiunge il numero di stelle per maggiore chiarezza.
     */
    @Override
    public String getStelle() {
        return Valutabile.super.getStelle() + " (" + voto + "/5)";
    }

    /** Imposta un nuovo voto, con validazione. */
    public void setVoto(int voto) {
        if (voto < 1 || voto > 5)
            throw new IllegalArgumentException("Voto non valido: " + voto);
        this.voto = voto;
    }

    /**
     * Implementazione di riproduci() — POLIMORFISMO:
     * la stessa chiamata riproduci() produce comportamenti diversi
     * a seconda del tipo reale dell'oggetto a runtime.
     */
    @Override
    public void riproduci() {
        System.out.println("♪ Riproduco brano: " + getArtista()
                + " - " + getTitolo()
                + " [" + String.format("%.2f", durata) + " min]");
    }
}


/**
 * Un album musicale, contenente una lista di brani.
 * Estende ElementoMusica. La durata totale è la somma delle durate dei brani.
 */
class Album extends ElementoMusica {

    private final List<Brano> tracce;  // lista ordinata di brani

    public Album(String titolo, String artista, int anno) {
        super(titolo, artista, anno);
        this.tracce = new ArrayList<Brano>();
    }

    /**
     * Aggiunge un brano all'album.
     * @throws NullPointerException se il brano è null
     */
    public void aggiungiBrano(Brano brano) {
        if (brano == null)
            throw new NullPointerException("Impossibile aggiungere un brano null");
        tracce.add(brano);
    }

    /** Restituisce una copia della lista tracce (difensiva: l'esterno non può modificarla). */
    public List<Brano> getTracce() {
        return new ArrayList<Brano>(tracce);
    }

    /** La durata dell'album è la somma delle durate di tutti i brani. */
    @Override
    public double getDurata() {
        double totale = 0;
        for (Brano b : tracce)
            totale += b.getDurata();
        return totale;
    }

    @Override
    public String getTipo() { return "Album"; }

    @Override
    public void riproduci() {
        System.out.println("▶ Riproduco album: " + getArtista()
                + " - " + getTitolo()
                + " (" + tracce.size() + " tracce, "
                + String.format("%.2f", getDurata()) + " min totali)");
        for (int i = 0; i < tracce.size(); i++)
            System.out.println("  " + (i + 1) + ". " + tracce.get(i).getTitolo());
    }
}


/**
 * Un podcast (elemento non musicale ma riproducibile).
 * Estende ElementoMusica. Non implementa Valutabile.
 */
class Podcast extends ElementoMusica {

    private final double durata;
    private final String descrizione;

    public Podcast(String titolo, String conduttore, int anno,
                   double durata, String descrizione) {
        super(titolo, conduttore, anno);
        if (durata <= 0)
            throw new IllegalArgumentException("Durata deve essere positiva");
        this.durata = durata;
        this.descrizione = descrizione;
    }

    @Override
    public double getDurata() { return durata; }

    @Override
    public String getTipo() { return "Podcast"; }

    @Override
    public void riproduci() {
        System.out.println("🎙 Riproduco podcast: " + getArtista()
                + " - " + getTitolo()
                + " [" + String.format("%.2f", durata) + " min]");
        System.out.println("   " + descrizione);
    }
}


// =============================================================================
// 4. ECCEZIONI PERSONALIZZATE
//    Estendono Exception (checked) o RuntimeException (unchecked).
//    Unchecked: non serve dichiararle con throws, non serve catturarle.
//    Checked: il compilatore obbliga a gestirle (try/catch o throws).
// =============================================================================

/**
 * Eccezione unchecked: elemento già presente nella libreria.
 * Estende RuntimeException — non serve dichiararla con throws.
 */
class ElementoDuplicatoException extends RuntimeException {
    public ElementoDuplicatoException(String messaggio) {
        super(messaggio);
    }
}

/**
 * Eccezione checked: la libreria non contiene l'elemento cercato.
 * Estende Exception — chi la lancia DEVE dichiararla con throws,
 * e chi la chiama DEVE gestirla con try/catch o rilanciarla.
 */
class ElementoNonTrovatoException extends Exception {
    public ElementoNonTrovatoException(String messaggio) {
        super(messaggio);
    }
}

/**
 * Eccezione checked per operazione non consentita su un tipo sbagliato.
 */
class TipoNonCompatibileException extends Exception {
    public TipoNonCompatibileException(String messaggio) {
        super(messaggio);
    }
}


// =============================================================================
// 5. GENERICS — classe generica con bounded type parameter
//    Contenitore<T extends ElementoMusica> funziona con qualsiasi
//    sottoclasse di ElementoMusica (Brano, Album, Podcast, ...).
// =============================================================================

/**
 * Contenitore generico: può contenere qualsiasi tipo che estende ElementoMusica.
 * Equivalente a come GraphNode<L> è parametrico sul tipo di etichetta.
 *
 * @param <T> tipo degli elementi, deve estendere ElementoMusica
 */
class Contenitore<T extends ElementoMusica> implements Iterable<T> {

    private final String nome;
    private final List<T> elementi;

    public Contenitore(String nome) {
        if (nome == null)
            throw new NullPointerException("Il nome del contenitore non può essere null");
        this.nome = nome;
        this.elementi = new ArrayList<T>();
    }

    public String getNome() { return nome; }

    /**
     * Aggiunge un elemento. Lancia eccezione unchecked se già presente.
     * @throws ElementoDuplicatoException se l'elemento è già nel contenitore
     * @throws NullPointerException       se l'elemento è null
     */
    public void aggiungi(T elemento) {
        if (elemento == null)
            throw new NullPointerException("Impossibile aggiungere elemento null");
        if (elementi.contains(elemento))
            throw new ElementoDuplicatoException(
                    "Elemento già presente: " + elemento.getTitolo());
        elementi.add(elemento);
    }

    /**
     * Cerca un elemento per titolo.
     * @throws ElementoNonTrovatoException eccezione checked — chi chiama deve gestirla
     */
    public T cercaPerTitolo(String titolo) throws ElementoNonTrovatoException {
        if (titolo == null)
            throw new NullPointerException("Il titolo da cercare non può essere null");
        for (T e : elementi)
            if (e.getTitolo().equals(titolo))
                return e;
        throw new ElementoNonTrovatoException("Nessun elemento con titolo: " + titolo);
    }

    /** Restituisce il numero di elementi. */
    public int size() { return elementi.size(); }

    /** Durata totale di tutti gli elementi. */
    public double getDurataTotale() {
        double totale = 0;
        // con l'iteratore abilito un for-each richiamando (Tipo variabile : collezione di elementi da scorrere)
        for (T e : elementi)
            totale += e.getDurata();
        return totale;
    }

    /**
     * Metodo generico statico: confronta due contenitori e restituisce
     * gli elementi in comune. Il tipo parametrico E è del metodo, non della classe.
     * Nota: non si può usare new E[] — quindi si usa List.
     */
    public static <E extends ElementoMusica> List<E> intersezione(
            Contenitore<E> c1, Contenitore<E> c2) {
        List<E> risultato = new ArrayList<E>();
        for (E e : c1)
            if (c2.elementi.contains(e))
                risultato.add(e);
        return risultato;
    }

    /**
     * Implementa Iterable<T>: permette di usare il for-each sul contenitore.
     */
    @Override
    public Iterator<T> iterator() {
        return elementi.iterator();
    }

    @Override
    public String toString() {
        return "Contenitore[" + nome + ", " + elementi.size() + " elementi]";
    }
}


// =============================================================================
// 6. COLLECTIONS — uso pratico di List, Set, Map con i tipi del dominio
// =============================================================================

/**
 * Libreria musicale principale.
 * Dimostra l'uso di ArrayList, HashSet, TreeSet, HashMap, TreeMap.
 */
class LibreriaMusica {

    // HashMap: accesso O(1) medio per chiave — richiede equals + hashCode su ElementoMusica
    private final Map<String, ElementoMusica> catalogoPerTitolo;

    // TreeSet: insieme ordinato (usa compareTo di ElementoMusica — artista, poi titolo)
    // Nessun duplicato, iterazione sempre ordinata
    private final Set<ElementoMusica> catalogoOrdinato;

    // TreeMap: mappa ordinata per chiave (artista) → lista degli elementi di quell'artista
    private final Map<String, List<ElementoMusica>> perArtista;

    public LibreriaMusica() {
        this.catalogoPerTitolo = new HashMap<String, ElementoMusica>();
        this.catalogoOrdinato  = new TreeSet<ElementoMusica>();
        this.perArtista        = new TreeMap<String, List<ElementoMusica>>();
    }

    /**
     * Aggiunge un elemento alla libreria.
     * @throws ElementoDuplicatoException se già presente (unchecked)
     * @throws NullPointerException se l'elemento è null
     */
    public void aggiungi(ElementoMusica elemento) {
        if (elemento == null)
            throw new NullPointerException("Elemento null non ammesso");
        String chiave = elemento.getTitolo() + "|" + elemento.getArtista();
        if (catalogoPerTitolo.containsKey(chiave))
            throw new ElementoDuplicatoException(
                    "Elemento già in libreria: " + elemento);
        catalogoPerTitolo.put(chiave, elemento);
        catalogoOrdinato.add(elemento);
        // Aggiunge alla mappa artista → lista
        perArtista.computeIfAbsent(
                elemento.getArtista(), k -> new ArrayList<ElementoMusica>()
        ).add(elemento);
    }

    /**
     * Cerca per titolo (ricerca esatta nell'HashMap).
     * @throws ElementoNonTrovatoException eccezione checked
     */
    public ElementoMusica cercaPerTitolo(String titolo, String artista)
            throws ElementoNonTrovatoException {
        String chiave = titolo + "|" + artista;
        ElementoMusica trovato = catalogoPerTitolo.get(chiave);
        if (trovato == null)
            throw new ElementoNonTrovatoException(
                    "Nessun elemento con titolo '" + titolo
                    + "' di '" + artista + "'");
        return trovato;
    }

    /**
     * Restituisce tutti gli elementi di un artista (dalla TreeMap).
     * La lista è già ordinata per artista/titolo grazie a TreeSet.
     */
    public List<ElementoMusica> getElementiDiArtista(String artista) {
        List<ElementoMusica> lista = perArtista.get(artista);
        if (lista == null)
            return new ArrayList<ElementoMusica>();
        return new ArrayList<ElementoMusica>(lista); // copia difensiva
    }

    /**
     * Restituisce tutti gli elementi ordinati (da TreeSet).
     * TreeSet usa compareTo quindi l'ordine è: artista → titolo.
     */
    public List<ElementoMusica> getTuttiOrdinati() {
        return new ArrayList<ElementoMusica>(catalogoOrdinato);
    }

    /**
     * Riproduce tutti gli elementi — POLIMORFISMO:
     * il tipo dichiarato è ElementoMusica, ma riproduci() chiama
     * l'implementazione del tipo reale (Brano, Album, Podcast).
     */
    public void riproduciTutto() {
        System.out.println("=== Riproduzione libreria ===");
        for (ElementoMusica e : catalogoOrdinato)
            e.riproduci();   // dispatch dinamico → polimorfismo
        System.out.println("=== Fine ===");
    }

    /**
     * Restituisce solo i brani valutati (instanceof + casting).
     * HashSet: nessun duplicato, nessun ordine garantito.
     *
     * @param votoMinimo voto minimo (1-5)
     */
    public Set<Brano> getBraniConVoto(int votoMinimo) {
        Set<Brano> risultato = new HashSet<Brano>();
        for (ElementoMusica e : catalogoOrdinato) {
            // instanceof: verifica il tipo reale a runtime prima del cast
            if (e instanceof Brano) {
                Brano b = (Brano) e;  // DOWNCAST — sicuro perché controllato da instanceof
                if (b.getVoto() >= votoMinimo)
                    risultato.add(b);
            }
        }
        return risultato;
    }

    /**
     * Restituisce la durata totale della libreria.
     */
    public double getDurataTotale() {
        double totale = 0;
        for (ElementoMusica e : catalogoOrdinato)
            totale += e.getDurata();
        return totale;
    }

    /** Numero di elementi in libreria. */
    public int size() { return catalogoOrdinato.size(); }
}


// =============================================================================
// 7. MAIN — dimostrazione di tutto il codice
// =============================================================================

/**
 * Classe main: dimostra l'uso di tutto il codice sopra.
 * Ogni sezione è numerata e commentata.
 */
public class RipassoOOP {

    public static void main(String[] args) {

        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║       RIPASSO OOP JAVA — ASDL 2526       ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        // -------------------------------------------------------------------
        // 1. CREAZIONE OGGETTI — costruttori + eccezioni nel costruttore
        // -------------------------------------------------------------------
        System.out.println("── 1. Creazione oggetti ─────────────────────");

        Brano b1 = new Brano("Bohemian Rhapsody", "Queen", 1975, 5.55, "Rock", 5);
        Brano b2 = new Brano("We Will Rock You",  "Queen", 1977, 2.02, "Rock", 4);
        Brano b3 = new Brano("Hotel California",  "Eagles", 1977, 6.30, "Rock", 5);
        Brano b4 = new Brano("Come as You Are",   "Nirvana", 1991, 3.39, "Grunge", 4);

        Album album1 = new Album("A Night at the Opera", "Queen", 1975);
        album1.aggiungiBrano(b1);
        album1.aggiungiBrano(b2);

        Podcast p1 = new Podcast("Storia del Rock", "Mario Rossi", 2022,
                45.0, "Dal blues alle origini dell'elettrico");

        System.out.println("Creati: " + b1);
        System.out.println("Creati: " + album1);
        System.out.println("Creati: " + p1);

        // Tentativo di costruttore con dato non valido
        System.out.println("\nTest eccezione nel costruttore:");
        try {
            Brano bSbagliato = new Brano("X", "Y", 1800, 3.0, "Pop", 3);
        } catch (IllegalArgumentException e) {
            System.out.println("  IllegalArgumentException catturata: " + e.getMessage());
        }

        // -------------------------------------------------------------------
        // 2. POLIMORFISMO — stessa variabile, comportamento diverso a runtime
        // -------------------------------------------------------------------
        System.out.println("\n── 2. Polimorfismo ──────────────────────────");

        // Il tipo statico (dichiarato) è Riproducibile,
        // il tipo dinamico (reale) è Brano / Album / Podcast.
        // La JVM chiama il metodo riproduci() del tipo reale.
        Riproducibile[] elementi = { b1, album1, p1 };
        for (Riproducibile r : elementi) {
            r.riproduci();  // comportamento diverso per ogni tipo
        }

        // -------------------------------------------------------------------
        // 3. INSTANCEOF E CASTING
        // -------------------------------------------------------------------
        System.out.println("\n── 3. instanceof e casting ─────────────────");

        ElementoMusica[] mix = { b1, b2, album1, p1, b3 };
        for (ElementoMusica e : mix) {
            System.out.print("  " + e.getTipo() + " '" + e.getTitolo() + "' → ");

            if (e instanceof Brano) {
                // Downcast sicuro: prima si controlla con instanceof, poi si fa il cast
                Brano b = (Brano) e;
                System.out.println("voto: " + b.getStelle());
            } else if (e instanceof Album) {
                Album a = (Album) e;
                System.out.println("tracce: " + a.getTracce().size());
            } else {
                System.out.println("nessun voto disponibile");
            }
        }

        // ClassCastException se si fa il cast senza instanceof
        System.out.println("\nTest ClassCastException:");
        try {
            ElementoMusica e = p1;         // tipo dichiarato: ElementoMusica
            Brano b = (Brano) e;           // cast errato — Podcast non è Brano!
        } catch (ClassCastException e) {
            System.out.println("  ClassCastException catturata: " + e.getMessage());
        }

        // -------------------------------------------------------------------
        // 4. INTERFACCE — uso di Valutabile separato da Riproducibile
        // -------------------------------------------------------------------
        System.out.println("\n── 4. Interfacce ────────────────────────────");

        // Solo Brano implementa Valutabile, non Album né Podcast
        Valutabile[] valutabili = { b1, b2, b3, b4 };
        System.out.println("Brani valutabili:");
        for (Valutabile v : valutabili)
            System.out.println("  " + v.getStelle()); // chiama l'override di Brano

        // Metodo default dell'interfaccia:
        // se Brano non avesse fatto override, userebbe il metodo default di Valutabile
        System.out.println("\nMetodo default su un Valutabile anonimo:");
        Valutabile vAnonimo = new Valutabile() {
            @Override
            public int getVoto() { return 3; }
            // non fa override di getStelle() → usa il default dell'interfaccia
        };
        System.out.println("  Stelle default: " + vAnonimo.getStelle());

        // -------------------------------------------------------------------
        // 5. GENERICS — Contenitore<T>
        // -------------------------------------------------------------------
        System.out.println("\n── 5. Generics ──────────────────────────────");

        // Contenitore<Brano>: accetta solo Brano
        Contenitore<Brano> playlist = new Contenitore<Brano>("MyPlaylist");
        playlist.aggiungi(b1);
        playlist.aggiungi(b2);
        playlist.aggiungi(b3);
        playlist.aggiungi(b4);
        System.out.println("Playlist: " + playlist);
        System.out.println("Durata totale: "
                + String.format("%.2f", playlist.getDurataTotale()) + " min");

        // Test eccezione unchecked ElementoDuplicatoException
        System.out.println("\nTest ElementoDuplicatoException:");
        try {
            playlist.aggiungi(b1);  // b1 è già nella playlist
        } catch (ElementoDuplicatoException e) {
            System.out.println("  ElementoDuplicatoException: " + e.getMessage());
        }

        // Ricerca con eccezione checked ElementoNonTrovatoException
        System.out.println("\nTest ElementoNonTrovatoException:");
        try {
            Brano trovato = playlist.cercaPerTitolo("Bohemian Rhapsody");
            System.out.println("  Trovato: " + trovato);
            playlist.cercaPerTitolo("Canzone Inesistente"); // lancia eccezione
        } catch (ElementoNonTrovatoException e) {
            // Eccezione checked: il compilatore ci OBBLIGA a catturarla o dichiararla
            System.out.println("  ElementoNonTrovatoException: " + e.getMessage());
        }

        // Metodo generico statico: intersezione di due contenitori
        Contenitore<Brano> altrePlaylist = new Contenitore<Brano>("AltrePlaylist");
        altrePlaylist.aggiungi(b1);
        altrePlaylist.aggiungi(b4);
        List<Brano> comuni = Contenitore.intersezione(playlist, altrePlaylist);
        System.out.println("\nBrani in comune tra le due playlist:");
        for (Brano b : comuni)
            System.out.println("  " + b.getTitolo());

        // -------------------------------------------------------------------
        // 6. COLLECTIONS — List, Set, Map nella LibreriaMusica
        // -------------------------------------------------------------------
        System.out.println("\n── 6. Collections ───────────────────────────");

        LibreriaMusica libreria = new LibreriaMusica();
        libreria.aggiungi(b1);
        libreria.aggiungi(b2);
        libreria.aggiungi(b3);
        libreria.aggiungi(b4);
        libreria.aggiungi(album1);
        libreria.aggiungi(p1);

        // TreeSet → iterazione in ordine (artista → titolo)
        System.out.println("Tutti gli elementi ordinati (TreeSet):");
        for (ElementoMusica e : libreria.getTuttiOrdinati())
            System.out.println("  " + e);

        // TreeMap → elementi per artista
        System.out.println("\nElementi di Queen (TreeMap per artista):");
        for (ElementoMusica e : libreria.getElementiDiArtista("Queen"))
            System.out.println("  " + e);

        // HashSet → brani con voto >= 5
        System.out.println("\nBrani con voto 5 (HashSet):");
        for (Brano b : libreria.getBraniConVoto(5))
            System.out.println("  " + b.getTitolo() + " " + b.getStelle());

        // Durata totale
        System.out.println("\nDurata totale libreria: "
                + String.format("%.2f", libreria.getDurataTotale()) + " min");

        // Eccezione checked nella libreria
        System.out.println("\nTest ricerca in libreria:");
        try {
            ElementoMusica trovato = libreria.cercaPerTitolo("Hotel California", "Eagles");
            System.out.println("  Trovato: " + trovato);
        } catch (ElementoNonTrovatoException e) {
            System.out.println("  Non trovato: " + e.getMessage());
        }

        // -------------------------------------------------------------------
        // 7. COLLECTIONS DIRETTE — uso di ArrayList, TreeSet, HashMap raw
        // -------------------------------------------------------------------
        System.out.println("\n── 7. Collections dirette ───────────────────");

        // ArrayList: accesso per indice O(1), inserimento O(1) ammortizzato
        List<String> nomiArtisti = new ArrayList<String>();
        nomiArtisti.add("Queen");
        nomiArtisti.add("Eagles");
        nomiArtisti.add("Nirvana");
        nomiArtisti.add("Eagles");       // duplicato: ArrayList lo accetta
        Collections.sort(nomiArtisti);   // ordinamento in-place
        System.out.println("ArrayList ordinata: " + nomiArtisti);

        // HashSet: no duplicati, no ordine
        Set<String> generiUnici = new HashSet<String>();
        generiUnici.add("Rock");
        generiUnici.add("Grunge");
        generiUnici.add("Rock");   // ignorato: duplicato
        System.out.println("HashSet generi: " + generiUnici);

        // TreeSet: no duplicati, ordine naturale (alphabetico per String)
        Set<String> generiOrdinati = new TreeSet<String>(generiUnici);
        System.out.println("TreeSet generi: " + generiOrdinati);

        // HashMap: chiave → valore, accesso O(1) medio
        Map<String, Integer> contaPerGenere = new HashMap<String, Integer>();
        for (ElementoMusica e : libreria.getTuttiOrdinati()) {
            if (e instanceof Brano) {
                String genere = ((Brano) e).getGenere();
                // getOrDefault: restituisce 0 se la chiave non esiste
                contaPerGenere.put(genere, contaPerGenere.getOrDefault(genere, 0) + 1);
            }
        }
        System.out.println("Conteggio brani per genere (HashMap): " + contaPerGenere);

        // Iterazione su Map con entrySet()
        System.out.println("Dettaglio:");
        for (Map.Entry<String, Integer> entry : contaPerGenere.entrySet())
            System.out.println("  " + entry.getKey() + ": " + entry.getValue() + " brani");

        // -------------------------------------------------------------------
        // 8. EREDITARIETÀ — super, override, Object
        // -------------------------------------------------------------------
        System.out.println("\n── 8. Ereditarietà + super ──────────────────");

        // compareTo ereditato da ElementoMusica → brani si possono confrontare
        System.out.println("b1 < b3? " + (b1.compareTo(b3) > 0 ? "no" : "sì")
                + "  (Queen < Eagles in ordine alfabetico inverso)");

        // equals ereditato da ElementoMusica
        Brano b1Copia = new Brano("Bohemian Rhapsody", "Queen", 1975, 5.55, "Rock", 5);
        System.out.println("b1.equals(b1Copia) = " + b1.equals(b1Copia));  // true
        System.out.println("b1 == b1Copia      = " + (b1 == b1Copia));     // false

        // toString ereditato
        System.out.println("toString: " + b1);

        System.out.println("\n╔══════════════════════════════════════════╗");
        System.out.println("║               FINE RIPASSO               ║");
        System.out.println("╚══════════════════════════════════════════╝");
    }
}
