package Graph_Matrix;

public class RecursiveMatrixChain {

    /**
     * Calcola il costo minimo di moltiplicazione ricorsivamente (senza memo).
     * p[i-1] x p[i] sono le dimensioni della matrice i-esima (1-indexed).
     * Complessità: esponenziale Omega(2^n) — solo a scopo didattico.
     */
    public static long recursiveMatrixChain(int[] p, int i, int j) {
        // Caso base: una sola matrice, costo zero
        if (i == j) return 0;

        long minCost = Long.MAX_VALUE;

        // Prova tutti i possibili punti di taglio k
        for (int k = i; k < j; k++) {
            long q = recursiveMatrixChain(p, i, k)       // costo parte sinistra
                    + recursiveMatrixChain(p, k + 1, j)   // costo parte destra
                    + (long) p[i - 1] * p[k] * p[j];     // costo della moltiplicazione finale

            if (q < minCost) {
                minCost = q;
            }
        }
        return minCost;
    }

    public static void main(String[] args) {
        // Matrici: A1(30x35), A2(35x15), A3(15x5), A4(5x10), A5(10x20), A6(20x25)
        int[] p = {30, 35, 15, 5, 10, 20, 25};
        int n = p.length - 1; // numero di matrici = 6

        long cost = recursiveMatrixChain(p, 1, n);
        System.out.println("Costo minimo (ricorsivo): " + cost); // atteso: 15125
    }
}
