package Graph_Matrix;

//TODO completati gli import necessari
import java.util.ArrayList;
import java.util.List;
// import java.util.Set;

//ATTENZIONE: è vietato includere import a pacchetti che non siano della Java SE

/**
 * Classe singoletto che implementa l'algoritmo di Prim per trovare un Minimum
 * Spanning Tree di un grafo non orientato, pesato e con pesi non negativi.
 * 
 * L'algoritmo richiede l'uso di una coda di min priorità tra i nodi che può
 * essere realizzata con una semplice ArrayList (non c'è bisogno di ottimizzare
 * le operazioni di inserimento, di estrazione del minimo, o di decremento della
 * priorità).
 * 
 * Si possono usare i colori dei nodi per registrare la scoperta e la visita
 * effettuata dei nodi.
 * 
 * @author Luca Tesei, Federico Di Petta (template) **INSERIRE NOME, COGNOME ED EMAIL
 *         xxxx@studenti.unicam.it DELLO STUDENTE** (implementazione)
 * 
 * @param <L>
 *                tipo delle etichette dei nodi del grafo
 *
 */
public class PrimMSP<L> {

    // TODO inserite le variabili istanza che si ritengono necessarie
    // Coda con priorità realizzata come semplice ArrayList
    // (contiene i nodi non ancora nell'MST, ordinati per key)
    private List<GraphNode<L>> queue;

    /*
     * In particolare: si deve usare una coda con priorità che può semplicemente
     * essere realizzata con una List e si deve mantenere un
     * insieme dei nodi già visitati
     */

    /**
     * Crea un nuovo algoritmo e inizializza la coda di priorità con una coda
     * vuota.
     */
    public PrimMSP() {
        // TODO implementato
        this.queue = new ArrayList<>();
    }

    /**
     * Utilizza l'algoritmo goloso di Prim per trovare un albero di copertura
     * minimo in un grafo non orientato e pesato, con pesi degli archi non
     * negativi. Dopo l'esecuzione del metodo nei nodi del grafo il campo
     * previous deve contenere un puntatore a un nodo in accordo all'albero di
     * copertura minimo calcolato, la cui radice è il nodo sorgente passato.
     * 
     * @param g
     *              un grafo non orientato, pesato, con pesi non negativi
     * @param s
     *              il nodo del grafo g sorgente, cioè da cui parte il calcolo
     *              dell'albero di copertura minimo. Tale nodo sarà la radice
     *              dell'albero di copertura trovato
     * 
     * @throw NullPointerException se il grafo g o il nodo sorgente s sono nulli
     * @throw IllegalArgumentException se il nodo sorgente s non esiste in g
     * @throw IllegalArgumentException se il grafo g è orientato, non pesato o
     *        con pesi negativi
     */
    public void computeMSP(Graph1<L> g, GraphNode<L> s) {
        // TODO implementato
        if (g == null || s == null)
            throw new NullPointerException("Grafo e nodo sorgente non possono essere null");

        // Controllo che s appartenga a g
        // Usa getNode() per ottenere il nodo REALE dal grafo (stesso oggetto)
        GraphNode<L> sInGraph = g.getNode(s.getLabel());
        if (sInGraph == null)
            throw new IllegalArgumentException(
                    "Il nodo sorgente non esiste nel grafo");

        // Controllo che il grafo sia non orientato
        if (g.isDirected())
            throw new IllegalArgumentException(
                    "Il grafo deve essere non orientato");

        // Controllo che il grafo sia pesato e con pesi non negativi
        for (GraphEdge<L> edge : g.getEdges()) {
            if (!edge.hasWeight())
                throw new IllegalArgumentException(
                        "Il grafo deve essere pesato");
            if (edge.getWeight() < 0)
                throw new IllegalArgumentException(
                        "Il grafo non deve avere pesi negativi");
        }

        // ── Inizializzazione (MST-PRIM: righe 1-5) ──────────────────
        // Per ogni nodo: key = +∞, previous = null, colore = WHITE
        for (GraphNode<L> v : g.getNodes()) {
            v.setFloatingPointDistance(Double.POSITIVE_INFINITY); // key[v] = ∞
            v.setPrevious(null);                                   // π[v] = NIL
            v.setColor(GraphNode.COLOR_WHITE);
        }

        // key[s] = 0 → s sarà il primo estratto
        // s.setFloatingPointDistance(0.0);
        // Usa getNode() per ottenere il nodo REALE dal grafo (stesso oggetto)
        sInGraph.setFloatingPointDistance(0.0);
        // g.getNode(s.getLabel()).setFloatingPointDistance(0.0);

        // Inizializza la coda con tutti i nodi del grafo
        queue.clear();
        queue.addAll(g.getNodes());

        // ── Ciclo principale (MST-PRIM: righe 6-11) ──────────────────
        // Ripeti finché la coda non è vuota
        while (!queue.isEmpty()) {

            // EXTRACT-MIN: estrai il nodo u con key minima
            GraphNode<L> u = extractMin();

            // Marca u come visitato (nell'MST)
            u.setColor(GraphNode.COLOR_BLACK);

            // Per ogni vicino v di u
            // for (GraphNode<L> v : g.getAdjacentNodesOf(u.getLabel())) {
            int indexU = g.getNodeIndexOf(u.getLabel());
            for (GraphEdge<L> edge : g.getEdgesOf(indexU)) {

                // Salta i self-loop
                if (edge.getNode1().equals(edge.getNode2()))
                    continue;

                // Ricava il nodo vicino: l'altro estremo dell'arco rispetto a u
                // Recupera il vicino tramite getNode() → riferimento reale garantito
                L neighborLabel = edge.getNode1().equals(u)
                        ? edge.getNode2().getLabel()
                        : edge.getNode1().getLabel();

                GraphNode<L> v = g.getNode(neighborLabel);
                if (v == null) continue;
                // if (edge.getNode1().equals(u)) {
                //     v = edge.getNode2();
                // } else {
                //     v = edge.getNode1();
                // }

                // Considera solo i nodi ancora nella coda (non nell'MST)
                if (queue.contains(v)) {

                    // Recupera il peso dell'arco (u, v)
                    // GraphEdge<L> edge = g.getEdge(u, v);
                    double weight = edge.getWeight();

                    // Se il peso dell'arco è minore della key corrente di v:
                    // aggiorna π[v] e key[v]   (DECREASE-KEY)
                    if (weight < v.getFloatingPointDistance()) {
                        v.setPrevious(u);                    // π[v] = u
                        v.setFloatingPointDistance(weight);  // key[v] = w(u,v)
                    }
                }
            }
        }
    }
    /**
     * Estrae dalla coda il nodo con key (floatingPointDistance) minima.
     * Corrisponde a EXTRACT-MIN nella versione con ArrayList.
     * Complessità O(n) — accettabile perché non si richiede ottimizzazione.
     *
     * @return il nodo con key minima, rimosso dalla coda
     */
    private GraphNode<L> extractMin() {
        GraphNode<L> min = queue.get(0);
        for (GraphNode<L> node : queue) {
            if (node.getFloatingPointDistance() < min.getFloatingPointDistance()) {
                min = node;
            }
        }
        queue.remove(min);
        return min;
    }

}
