package Graph_Matrix;
import java.util.*;

/*
* Struttura del codice:
* Graph gestisce la rappresentazione con liste di adiacenza
* (mappa String → List<int[]>),
* Edge rappresenta un arco pesato con Comparable per l'ordinamento in Kruskal;
* PQEntry è la voce della coda con priorità usata da Prim e Dijkstra.
* I cinque algoritmi sono metodi della classe Graph;
* il main costruisce il grafo degli esempi e li esegue tutti.
* */

// ─────────────────────────────────────────────
//  Strutture dati di supporto
// ─────────────────────────────────────────────

/** Arco pesato non orientato */
class Edge implements Comparable<Edge> {
    String u, v;
    int weight;

    Edge(String u, String v, int weight) {
        this.u = u;
        this.v = v;
        this.weight = weight;
    }

    @Override
    public int compareTo(Edge other) {
        return Integer.compare(this.weight, other.weight);
    }

    @Override
    public String toString() {
        return u + "–" + v + "(" + weight + ")";
    }
}

/** Voce della coda con priorità per Prim e Dijkstra */
class PQEntry implements Comparable<PQEntry> {
    String vertex;
    int key; // distanza (Dijkstra) o peso arco (Prim)

    PQEntry(String vertex, int key) {
        this.vertex = vertex;
        this.key = key;
    }

    @Override
    public int compareTo(PQEntry other) {
        return Integer.compare(this.key, other.key);
    }
}

// ─────────────────────────────────────────────
//  Grafo non orientato pesato (liste di adiacenza)
// ─────────────────────────────────────────────

class Graph {
    // Ogni vertice → lista di (vicino, peso)
    private final Map<String, List<int[]>> adj = new LinkedHashMap<>();
    // Lista globale di tutti gli archi (per Kruskal)
    private final List<Edge> edges = new ArrayList<>();
    // Insieme dei vertici nell'ordine di inserimento
    private final List<String> vertices = new ArrayList<>();

    /** Aggiunge un vertice isolato */
    public void addVertex(String v) {
        if (!adj.containsKey(v)) {
            adj.put(v, new ArrayList<>());
            vertices.add(v);
        }
    }

    /** Aggiunge un arco non orientato con peso */
    public void addEdge(String u, String v, int w) {
        addVertex(u);
        addVertex(v);
        // int[] = {indice vertice vicino come intero? No: usiamo mappa}
        // Memorizziamo il vicino come indice per comodità interna
        adj.get(u).add(new int[]{vertices.indexOf(v), w});
        adj.get(v).add(new int[]{vertices.indexOf(u), w});
        edges.add(new Edge(u, v, w));
    }

    public List<String> getVertices() { return vertices; }
    public List<Edge>   getEdges()    { return edges; }

    /** Restituisce la lista di adiacenza di v come coppie (nomeVicino, peso) */
    public List<int[]> getAdj(String v) {
        return adj.getOrDefault(v, Collections.emptyList());
    }

    /** Converte indice → nome vertice */
    public String nameOf(int idx) { return vertices.get(idx); }

    // ─────────────────────────────────────────
    //  BFS  (Breadth-First Search)
    //  Complessità: O(V + E)
    // ─────────────────────────────────────────

    /**
     * Visita in ampiezza a partire da src.
     * Stampa l'ordine di scoperta e le distanze (in numero di archi).
     */
    public void bfs(String src) {
        System.out.println("\n── BFS da " + src + " ──");
        Map<String, Integer> dist   = new LinkedHashMap<>();
        Map<String, String>  parent = new LinkedHashMap<>();

        // Inizializzazione
        for (String v : vertices) dist.put(v, Integer.MAX_VALUE);
        dist.put(src, 0);
        parent.put(src, null);

        Queue<String> queue = new LinkedList<>();
        queue.add(src);

        while (!queue.isEmpty()) {
            String u = queue.poll();
            System.out.print("Visito " + u + " (d=" + dist.get(u) + ")  ");

            for (int[] edge : getAdj(u)) {
                String v = nameOf(edge[0]);
                if (dist.get(v) == Integer.MAX_VALUE) {   // v non ancora scoperto
                    dist.put(v, dist.get(u) + 1);
                    parent.put(v, u);
                    queue.add(v);
                }
            }
        }
        System.out.println();

        // Stampa distanze finali
        System.out.println("Distanze da " + src + ":");
        for (String v : vertices) {
            int d = dist.get(v);
            System.out.println("  " + src + " → " + v + " = " +
                    (d == Integer.MAX_VALUE ? "∞" : d));
        }
    }

    // ─────────────────────────────────────────
    //  DFS  (Depth-First Search)
    //  Complessità: O(V + E)
    // ─────────────────────────────────────────

    // Variabili di stato per la DFS (usate nei metodi privati)
    private int   time;
    private Map<String, Integer> dfsColor;   // 0=bianco 1=grigio 2=nero
    private Map<String, Integer> dfsDisc;    // timestamp scoperta
    private Map<String, Integer> dfsFinish;  // timestamp fine
    private Map<String, String>  dfsParent;

    /**
     * Visita in profondità dell'intero grafo.
     * Stampa i timestamp d[v]/f[v] per ogni vertice.
     */
    public void dfs(String src) {
        System.out.println("\n── DFS da " + src + " ──");
        time      = 0;
        dfsColor  = new HashMap<>();
        dfsDisc   = new LinkedHashMap<>();
        dfsFinish = new LinkedHashMap<>();
        dfsParent = new HashMap<>();

        for (String v : vertices) {
            dfsColor.put(v, 0);
            dfsParent.put(v, null);
        }

        // Parte dalla sorgente indicata, poi visita eventuali nodi rimasti bianchi
        dfsVisit(src);
        for (String v : vertices)
            if (dfsColor.get(v) == 0) dfsVisit(v);

        // Stampa risultati
        System.out.println("Timestamps d[v]/f[v]:");
        for (String v : vertices)
            System.out.println("  " + v + ": d=" + dfsDisc.get(v) +
                    "  f=" + dfsFinish.get(v) +
                    "  π=" + dfsParent.get(v));
    }

    private void dfsVisit(String u) {
        dfsColor.put(u, 1);           // grigio
        dfsDisc.put(u, ++time);
        System.out.print("Scopro " + u + "(d=" + time + ")  ");

        for (int[] edge : getAdj(u)) {
            String v = nameOf(edge[0]);
            if (dfsColor.get(v) == 0) {    // arco dell'albero
                dfsParent.put(v, u);
                dfsVisit(v);
            }
        }
        dfsColor.put(u, 2);           // nero
        dfsFinish.put(u, ++time);
        System.out.print("Finisco " + u + "(f=" + time + ")  ");
    }

    // ─────────────────────────────────────────
    //  KRUSKAL  (MST)
    //  Complessità: O(E log E)
    // ─────────────────────────────────────────

    /**
     * Algoritmo di Kruskal per il minimo albero di copertura.
     * Usa Union-Find con union-by-rank e path compression.
     */
    public void kruskal() {
        System.out.println("\n── Kruskal MST ──");

        // Ordina gli archi per peso crescente
        List<Edge> sorted = new ArrayList<>(edges);
        Collections.sort(sorted);

        // Union-Find: parent e rank
        Map<String, String> parent = new HashMap<>();
        Map<String, Integer> rank  = new HashMap<>();
        for (String v : vertices) {
            parent.put(v, v);
            rank.put(v, 0);
        }

        List<Edge> mst   = new ArrayList<>();
        int        total = 0;

        for (Edge e : sorted) {
            String ru = find(parent, e.u);
            String rv = find(parent, e.v);

            if (!ru.equals(rv)) {           // componenti diverse → accetto
                mst.add(e);
                total += e.weight;
                union(parent, rank, ru, rv);
                System.out.println("  Accetto " + e);
            } else {
                System.out.println("  Scarto  " + e + " (creerebbe ciclo)");
            }

            if (mst.size() == vertices.size() - 1) break; // MST completo
        }

        System.out.println("MST: " + mst + "  peso totale = " + total);
    }

    // Find con path compression
    private String find(Map<String, String> parent, String v) {
        if (!parent.get(v).equals(v))
            parent.put(v, find(parent, parent.get(v)));
        return parent.get(v);
    }

    // Union by rank
    private void union(Map<String, String> parent,
                       Map<String, Integer> rank,
                       String u, String v) {
        if (rank.get(u) < rank.get(v))      parent.put(u, v);
        else if (rank.get(u) > rank.get(v)) parent.put(v, u);
        else { parent.put(v, u); rank.put(u, rank.get(u) + 1); }
    }

    // ─────────────────────────────────────────
    //  PRIM  (MST)
    //  Complessità: O((V + E) log V) con heap binario
    // ─────────────────────────────────────────

    /**
     * Algoritmo di Prim per il minimo albero di copertura.
     * Parte dalla radice indicata.
     */
    public void prim(String root) {
        System.out.println("\n── Prim MST da " + root + " ──");

        Map<String, Integer> key    = new HashMap<>(); // peso arco più leggero verso l'albero
        Map<String, String>  parent = new HashMap<>();
        Set<String>          inMST  = new HashSet<>();

        for (String v : vertices) {
            key.put(v, Integer.MAX_VALUE);
            parent.put(v, null);
        }
        key.put(root, 0);

        // Coda con priorità (min-heap)
        PriorityQueue<PQEntry> pq = new PriorityQueue<>();
        pq.add(new PQEntry(root, 0));

        int totalWeight = 0;
        List<String> mstEdges = new ArrayList<>();

        while (!pq.isEmpty()) {
            PQEntry entry = pq.poll();
            String  u     = entry.vertex;

            if (inMST.contains(u)) continue;  // già estratto
            inMST.add(u);

            if (parent.get(u) != null) {
                String edgeStr = parent.get(u) + "–" + u + "(" + key.get(u) + ")";
                mstEdges.add(edgeStr);
                totalWeight += key.get(u);
                System.out.println("  Aggiungo " + edgeStr);
            }

            // Rilassa i vicini
            for (int[] edge : getAdj(u)) {
                String v = nameOf(edge[0]);
                int    w = edge[1];
                if (!inMST.contains(v) && w < key.get(v)) {
                    key.put(v, w);
                    parent.put(v, u);
                    pq.add(new PQEntry(v, w));
                }
            }
        }

        System.out.println("MST: " + mstEdges + "  peso totale = " + totalWeight);
    }

    // ─────────────────────────────────────────
    //  DIJKSTRA  (cammini minimi da sorgente)
    //  Complessità: O((V + E) log V) con heap binario
    // ─────────────────────────────────────────

    /**
     * Algoritmo di Dijkstra per i cammini minimi da src.
     * Richiede pesi non negativi.
     */
    public void dijkstra(String src) {
        System.out.println("\n── Dijkstra da " + src + " ──");

        Map<String, Integer> dist   = new HashMap<>();
        Map<String, String>  parent = new HashMap<>();
        Set<String>          settled = new HashSet<>();

        for (String v : vertices) {
            dist.put(v, Integer.MAX_VALUE);
            parent.put(v, null);
        }
        dist.put(src, 0);

        PriorityQueue<PQEntry> pq = new PriorityQueue<>();
        pq.add(new PQEntry(src, 0));

        while (!pq.isEmpty()) {
            PQEntry entry = pq.poll();
            String  u     = entry.vertex;

            if (settled.contains(u)) continue;
            settled.add(u);
            System.out.println("  Estraggo " + u + "  d=" + dist.get(u));

            // Rilassamento archi uscenti da u
            for (int[] edge : getAdj(u)) {
                String v    = nameOf(edge[0]);
                int    w    = edge[1];
                int    newD = dist.get(u) + w;

                if (newD < dist.get(v)) {
                    dist.put(v, newD);
                    parent.put(v, u);
                    pq.add(new PQEntry(v, newD));
                    System.out.println("    Rilasso " + u + "→" + v +
                            "  nuova stima d[" + v + "]=" + newD);
                }
            }
        }

        // Stampa distanze e cammini minimi
        System.out.println("\nDistanze minime da " + src + ":");
        for (String v : vertices) {
            int d = dist.get(v);
            System.out.print("  " + src + " → " + v + " = " +
                    (d == Integer.MAX_VALUE ? "∞" : d) + "   cammino: ");
            System.out.println(buildPath(parent, src, v));
        }
    }

    /** Ricostruisce il cammino da src a dst usando la mappa dei predecessori */
    private String buildPath(Map<String, String> parent, String src, String dst) {
        if (dst.equals(src)) return src;
        if (parent.get(dst) == null) return "non raggiungibile";
        LinkedList<String> path = new LinkedList<>();
        String cur = dst;
        while (cur != null) {
            path.addFirst(cur);
            cur = parent.get(cur);
        }
        return String.join(" → ", path);
    }
}

// ─────────────────────────────────────────────
//  Main
// ─────────────────────────────────────────────

public class GraphAlgorithms {

    public static void main(String[] args) {

        // Grafo degli esempi:
        // A–B(4), A–C(2), B–C(6), B–D(5), B–E(3)
        // C–E(7), D–E(1), D–F(8), E–F(4)
        Graph g = new Graph();
        g.addEdge("A", "B", 4);
        g.addEdge("A", "C", 2);
        g.addEdge("B", "C", 6);
        g.addEdge("B", "D", 5);
        g.addEdge("B", "E", 3);
        g.addEdge("C", "E", 7);
        g.addEdge("D", "E", 1);
        g.addEdge("D", "F", 8);
        g.addEdge("E", "F", 4);

        // ── BFS da A ──────────────────────────
        g.bfs("A");

        // ── DFS da B ──────────────────────────
        g.dfs("B");

        // ── Kruskal MST ───────────────────────
        g.kruskal();

        // ── Prim MST da A ─────────────────────
        g.prim("A");

        // ── Dijkstra da A ─────────────────────
        g.dijkstra("A");
    }
}
