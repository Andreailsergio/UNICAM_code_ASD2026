package Graph_Matrix;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

// ATTENZIONE: è vietato includere import a pacchetti che non siano della Java SE

/**
 * Classe singoletto che implementa l'algoritmo di Kruskal per trovare un
 * Minimum Spanning Tree di un grafo non orientato, pesato e con pesi non
 * negativi.
 *
 * L'algoritmo utilizza la struttura dati Union-Find (insiemi disgiunti) per
 * verificare efficientemente se l'aggiunta di un arco creerebbe un ciclo.
 * La Union-Find è implementata tramite due mappe (parent e rank) che
 * supportano le operazioni MAKE-SET, FIND-SET e UNION con union-by-rank
 * e path compression.
 *
 * Dopo l'esecuzione del metodo {@code computeMSP}, il campo
 * {@code mstEdges} contiene gli archi dell'MST trovato.
 *
 * @author Luca Tesei, Federico Di Petta (template)
 *         INSERIRE NOME, COGNOME ED EMAIL xxxx@studenti.unicam.it DELLO STUDENTE
 *         (implementazione)
 *
 * @param <L>
 *                tipo delle etichette dei nodi del grafo
 */
public class KruskalMSP<L> {

    /*
     * Insieme degli archi appartenenti all'MST calcolato dall'ultima chiamata
     * a computeMSP. È null se computeMSP non è ancora stato chiamato.
     */
    private Set<GraphEdge<L>> mstEdges;

    /*
     * Struttura Union-Find: mappa ogni nodo al proprio rappresentante
     * (radice dell'albero Union-Find).
     */
    private Map<GraphNode<L>, GraphNode<L>> parent;

    /*
     * Struttura Union-Find: mappa ogni nodo al proprio rango (altezza
     * approssimativa dell'albero radicato in quel nodo).
     */
    private Map<GraphNode<L>, Integer> rank;

    /**
     * Costruisce un nuovo oggetto KruskalMSP inizializzando le strutture dati.
     */
    public KruskalMSP() {
        this.mstEdges = null;
        this.parent = new HashMap<>();
        this.rank = new HashMap<>();
    }

    /**
     * Restituisce l'insieme degli archi dell'MST calcolato dall'ultima chiamata
     * a {@code computeMSP}, oppure null se {@code computeMSP} non è ancora
     * stato chiamato.
     *
     * @return l'insieme degli archi dell'MST, o null
     */
    public Set<GraphEdge<L>> getMstEdges() {
        return this.mstEdges;
    }

    /**
     * Utilizza l'algoritmo di Kruskal per trovare un albero di copertura
     * minimo in un grafo non orientato, pesato, con pesi non negativi.
     *
     * Pseudocodice (Cormen):
     *   A = ∅
     *   per ogni v ∈ V: MAKE-SET(v)
     *   ordina E per peso non decrescente
     *   per ogni arco (u,v) ∈ E in ordine:
     *     se FIND-SET(u) ≠ FIND-SET(v):
     *       A = A ∪ {(u,v)}
     *       UNION(u, v)
     *   return A
     *
     * Dopo l'esecuzione il campo {@code mstEdges} contiene gli archi dell'MST.
     *
     * @param g
     *              un grafo non orientato, pesato, con pesi non negativi
     *
     * @throws NullPointerException
     *              se il grafo g è null
     * @throws IllegalArgumentException
     *              se il grafo g è orientato, non pesato o con pesi negativi
     */
    public void computeMSP(Graph1<L> g) {
        // TODO implementato
        // ── Validazione ──────────────────────────────────────────────────

        if (g == null)
            throw new NullPointerException("Il grafo non può essere null");

        if (g.isDirected())
            throw new IllegalArgumentException("Il grafo deve essere non orientato");

        for (GraphEdge<L> edge : g.getEdges()) {
            if (!edge.hasWeight())
                throw new IllegalArgumentException("Il grafo deve essere pesato");
            if (edge.getWeight() < 0)
                throw new IllegalArgumentException("I pesi non possono essere negativi");
        }

        // ── A = ∅  (Cormen riga 1) ───────────────────────────────────────
        this.mstEdges = new HashSet<>();

        // ── per ogni v ∈ V: MAKE-SET(v)  (Cormen righe 2-3) ─────────────
        makeSet(g.getNodes());

        // ── Ordina E per peso non decrescente  (Cormen riga 4) ───────────
        // g.getEdges() restituisce un Set → copiamo in una List per ordinare
        List<GraphEdge<L>> sortedEdges = new ArrayList<>(g.getEdges());
        Collections.sort(sortedEdges, (e1, e2) ->
                Double.compare(e1.getWeight(), e2.getWeight()));

        // ── per ogni arco (u,v) in E in ordine  (Cormen righe 5-9) ───────
        for (GraphEdge<L> edge : sortedEdges) {

            // Recupera i riferimenti REALI dei due nodi estremi dal grafo
            GraphNode<L> u = g.getNode(edge.getNode1().getLabel());
            GraphNode<L> v = g.getNode(edge.getNode2().getLabel());

            // se FIND-SET(u) ≠ FIND-SET(v):  i due nodi sono in componenti diverse
            // → aggiungere l'arco NON crea un ciclo → lo accettiamo
            GraphNode<L> rootU = findSet(u);
            GraphNode<L> rootV = findSet(v);

            if (!rootU.equals(rootV)) {
                // A = A ∪ {(u,v)}
                mstEdges.add(edge);
                // UNION(u, v)  — fondi le due componenti
                union(rootU, rootV);
            }
            // altrimenti: FIND-SET(u) == FIND-SET(v) → stesso insieme → ciclo → scarta
        }
        // ── return A  (Cormen riga 10) ── il risultato è in this.mstEdges ─
    }

    /**
     * Inizializza la struttura Union-Find per tutti i nodi del grafo.
     * Ogni nodo diventa un insieme singleton: parent[v] = v, rank[v] = 0.
     *
     * Corrisponde all'operazione MAKE-SET del Cormen per tutti i vertici.
     *
     * @param nodes
     *              l'insieme dei nodi da inizializzare
     */
    private void makeSet(Set<GraphNode<L>> nodes) {
        // TODO implementato
        // Pulisce le strutture Union-Find da eventuali esecuzioni precedenti
        parent.clear();
        rank.clear();

        // Per ogni nodo v: MAKE-SET(v)
        // parent[v] = v  → ogni nodo è rappresentante di sé stesso (singleton)
        // rank[v]   = 0  → altezza iniziale dell'albero Union-Find è zero
        for (GraphNode<L> v : nodes) {
            parent.put(v, v);
            rank.put(v, 0);
        }
    }

    /**
     * Restituisce il rappresentante (radice) dell'insieme che contiene il
     * nodo {@code v} nella struttura Union-Find, applicando la
     * <b>path compression</b>: tutti i nodi incontrati durante la risalita
     * vengono collegati direttamente alla radice.
     *
     * Corrisponde all'operazione FIND-SET del Cormen con path compression.
     *
     * @param v
     *              il nodo di cui trovare il rappresentante
     * @return il rappresentante dell'insieme che contiene v
     */
    private GraphNode<L> findSet(GraphNode<L> v) {
        // TODO implementato
        // Caso base: v è la radice del proprio albero Union-Find
        // (è il rappresentante del proprio insieme)
        if (parent.get(v).equals(v))
            return v;

        // Caso ricorsivo: v non è la radice → risali verso la radice
        // PATH COMPRESSION: collega v direttamente alla radice
        // così le chiamate future su v (o sui suoi discendenti) costano O(1)
        GraphNode<L> root = findSet(parent.get(v));
        parent.put(v, root);
        return root;
    }

    /**
     * Unisce i due insiemi che contengono rispettivamente i nodi {@code u}
     * e {@code v} nella struttura Union-Find, usando la strategia
     * <b>union-by-rank</b>: l'albero di rango minore viene attaccato sotto
     * la radice di quello di rango maggiore. Se i ranghi sono uguali,
     * la radice di v viene attaccata sotto la radice di u e il rango di u
     * viene incrementato di 1.
     *
     * Corrisponde all'operazione UNION del Cormen con union-by-rank.
     *
     * Precondizione: u e v devono già essere radici dei rispettivi insiemi
     * (cioè essere il risultato di findSet).
     *
     * @param u
     *              radice del primo insieme
     * @param v
     *              radice del secondo insieme
     */
    private void union(GraphNode<L> u, GraphNode<L> v) {
        // TODO implementato
        int rankU = rank.get(u);
        int rankV = rank.get(v);

        // UNION BY RANK: attacca l'albero di rango minore sotto quello di rango maggiore
        // → l'albero risultante è il meno alto possibile → findSet resta veloce

        if (rankU > rankV) {
            // u ha rango maggiore → v diventa figlio di u
            parent.put(v, u);
        } else if (rankU < rankV) {
            // v ha rango maggiore → u diventa figlio di v
            parent.put(u, v);
        } else {
            // ranghi uguali → scelta arbitraria: v diventa figlio di u
            // il rango di u aumenta di 1 perché l'altezza dell'albero cresce
            parent.put(v, u);
            rank.put(u, rankU + 1);
        }
    }
}
