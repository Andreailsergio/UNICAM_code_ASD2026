package Graph_Matrix;

/*
* Memoization (dall'inglese memo, appunto/promemoria) è una tecnica di ottimizzazione
* che consiste nel salvare il risultato di una chiamata ricorsiva la prima volta che viene calcolato,
* in modo da non ricalcolarlo se viene richiesto di nuovo.
*
* Ha un approccio TOP-DOWN (opposto alla Programmazione Dinamica PD che è BOTTOM-UP):
* parte dal problema grande -> scende ricorsivamente verso i sottoproblemi
* -> salva i risultati man mano che li calcola -> calcola solo i sottoproblemi che servono davvero.
*
* PD invece -> parte dai sottoproblemi più piccoli -> riempie una tabella in ordine.
* -> sale verso il problema grande -> calcola TUTTI i sottoproblemi (anche quelli che forse non servivano).
*
* * La memoization è essenzialmente programmazione dinamica con ricorsione.
*
* Questa versione ha la stessa complessità Θ(n³) di Matrix-Chain-Order,
* ma risolve solo i sottoproblemi effettivamente necessari
* (utile se non tutti i sottoproblemi vengono raggiunti).
* */

public class MemoizedMatrixChain {

    static int[][] memo;
    static int[][] s; // tabella per ricostruire la parentesizzazione

    public static int lookupChain(int[] p, int i, int j) {
        if (memo[i][j] != Integer.MAX_VALUE) return memo[i][j];

        if (i == j) {
            memo[i][j] = 0;
            return 0;
        }

        for (int k = i; k < j; k++) {
            int q = lookupChain(p, i, k)
                    + lookupChain(p, k + 1, j)
                    + p[i - 1] * p[k] * p[j];
            if (q < memo[i][j]) {
                memo[i][j] = q;
                s[i][j] = k; // salva il punto di taglio ottimo
            }
        }
        return memo[i][j];
    }

    public static int memoizedMatrixChain(int[] p) {
        int n = p.length - 1;
        memo = new int[n + 1][n + 1];
        s    = new int[n + 1][n + 1];
        for (int[] row : memo)
            java.util.Arrays.fill(row, Integer.MAX_VALUE);
        return lookupChain(p, 1, n);
    }

    public static void printOptimalParens(int i, int j) {
        if (i == j) {
            System.out.print("A" + i);
        } else {
            System.out.print("(");
            printOptimalParens(i, s[i][j]);
            printOptimalParens(s[i][j] + 1, j);
            System.out.print(")");
        }
    }

    public static void main(String[] args) {
        // Matrici: A1(30x35), A2(35x15), A3(15x5), A4(5x10), A5(10x20), A6(20x25)
        int[] p = {30, 35, 15, 5, 10, 20, 25};
        int n = p.length - 1;

        int costoMinimo = memoizedMatrixChain(p);

        System.out.println("Costo minimo: " + costoMinimo);
        // Output atteso: 15125

        System.out.print("Parentesizzazione ottima: ");
        printOptimalParens(1, n);
        System.out.println();
        // Output atteso: ((A1(A2A3))((A4A5)A6))
    }
}