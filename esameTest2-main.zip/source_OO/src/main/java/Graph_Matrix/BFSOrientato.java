package Graph_Matrix;

import java.util.*;

/**
 * BFS su grafo ORIENTATO — Java 8 compatibile.
 * Algoritmo di Cormen (cap. 23.2):
 *   - colori: BIANCO(0), GRIGIO(1), NERO(2)
 *   - d[v] = distanza in numero di archi dalla sorgente
 *   - parent[v] = predecessore nell'albero BFS
 *   - usa una coda FIFO (Queue)
 *
 * Complessità: O(V + E)
 */
public class BFSOrientato {

    // ── Rappresentazione del grafo ──────────────────────────────────────────

    private final List<String>              vertices;
    private final Map<String, List<String>> adj;

    public BFSOrientato() {
        vertices = new ArrayList<String>();
        adj      = new LinkedHashMap<String, List<String>>();
    }

    public void addVertex(String v) {
        if (!adj.containsKey(v)) {
            vertices.add(v);
            adj.put(v, new ArrayList<String>());
        }
    }

    /** Aggiunge arco ORIENTATO u → v */
    public void addEdge(String u, String v) {
        addVertex(u);
        addVertex(v);
        adj.get(u).add(v);
    }

    // ── Algoritmo BFS ───────────────────────────────────────────────────────

    /**
     * BFS a partire dalla sorgente src.
     * Stampa l'ordine di scoperta, le distanze e l'albero BFS.
     * I vertici non raggiungibili da src restano con d = Integer.MAX_VALUE (∞).
     */
    public void bfs(String src) {
        System.out.println("\n════════════════════════════════════════");
        System.out.println(" BFS da " + src);
        System.out.println("════════════════════════════════════════");

        // Inizializzazione (Cormen, righe 1-8)
        Map<String, Integer> color  = new LinkedHashMap<String, Integer>();
        Map<String, Integer> d      = new LinkedHashMap<String, Integer>();
        Map<String, String>  parent = new LinkedHashMap<String, String>();

        for (String v : vertices) {
            color.put(v, 0);                    // BIANCO
            d.put(v, Integer.MAX_VALUE);        // ∞
            parent.put(v, null);
        }

        // Sorgente: distanza 0, GRIGIO, entra in coda
        color.put(src, 1);
        d.put(src, 0);

        Queue<String> queue = new LinkedList<String>();
        queue.add(src);

        System.out.println("Coda iniziale: [ " + src + " ]");
        System.out.println();

        // Ciclo principale (Cormen, righe 9-18)
        while (!queue.isEmpty()) {

            String u = queue.poll();            // estrai dalla testa
            System.out.print("Estraggo " + u
                    + " (d=" + d.get(u) + ")  →  esamino vicini: ");

            List<String> vicini = adj.get(u);
            if (vicini.isEmpty()) {
                System.out.print("nessuno");
            }

            for (String v : vicini) {
                if (color.get(v) == 0) {        // v è BIANCO: non ancora scoperto
                    color.put(v, 1);            // GRIGIO
                    d.put(v, d.get(u) + 1);
                    parent.put(v, u);
                    queue.add(v);
                    System.out.print(v + "(d=" + d.get(v) + ") ");
                } else {
                    // già scoperto: arco non d'albero, lo segnaliamo
                    System.out.print("[" + v + " già scoperto] ");
                }
            }

            color.put(u, 2);                    // NERO: u completato
            System.out.println();
            System.out.println("  Coda ora: " + queue);
        }

        printResults(src, d, parent);
    }

    // ── Stampa risultati ────────────────────────────────────────────────────

    private void printResults(String src,
                              Map<String, Integer> d,
                              Map<String, String>  parent) {

        System.out.println("\n════════════════════════════════════════");
        System.out.println(" Vertice | d[v] | parent");
        System.out.println("─────────┼──────┼────────");
        for (String v : vertices) {
            int dist = d.get(v);
            String distStr  = (dist == Integer.MAX_VALUE) ? "∞" : String.valueOf(dist);
            String parentStr = (parent.get(v) == null)   ? "NIL" : parent.get(v);
            System.out.printf("   %-5s  |  %-3s |  %s%n", v, distStr, parentStr);
        }
        System.out.println("════════════════════════════════════════");

        // Ricostruisce e stampa i cammini minimi
        System.out.println("\nCammini minimi da " + src + ":");
        for (String v : vertices) {
            System.out.print("  " + src + " → " + v + " : ");
            System.out.println(buildPath(src, v, parent, d));
        }
    }

    /**
     * Ricostruisce il cammino minimo da src a dst
     * risalendo la catena dei predecessori.
     */
    private String buildPath(String src, String dst,
                             Map<String, String>  parent,
                             Map<String, Integer> d) {

        if (d.get(dst) == Integer.MAX_VALUE) {
            return "non raggiungibile";
        }
        LinkedList<String> path = new LinkedList<String>();
        String cur = dst;
        while (cur != null) {
            path.addFirst(cur);
            cur = parent.get(cur);
        }
        // Costruisce la stringa "A → B → C"
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.size(); i++) {
            if (i > 0) sb.append(" → ");
            sb.append(path.get(i));
        }
        sb.append("  (distanza = ").append(d.get(dst)).append(")");
        return sb.toString();
    }

    // ── Main di test ────────────────────────────────────────────────────────

    /**
     * Stesso grafo dell'esempio articolato a 8 vertici fatto sopra:
     *   1→2, 1→5, 1→6, 3→7, 4→8, 6→3, 7→3, 7→6, 7→8, 8→7
     *
     * BFS da 1: livelli attesi
     *   d=0: {1}
     *   d=1: {2, 5, 6}
     *   d=2: {3}
     *   d=3: {7}
     *   d=4: {8}
     *   non raggiungibili da 1: {4}
     */
    public static void main(String[] args) {
        BFSOrientato g = new BFSOrientato();

        // Vertici
        g.addVertex("1");
        g.addVertex("2");
        g.addVertex("3");
        g.addVertex("4");
        g.addVertex("5");
        g.addVertex("6");
        g.addVertex("7");
        g.addVertex("8");

        // Archi orientati
        g.addEdge("1", "2");
        g.addEdge("1", "5");
        g.addEdge("1", "6");
        g.addEdge("3", "7");
        g.addEdge("4", "8");
        g.addEdge("6", "3");
        g.addEdge("7", "3");
        g.addEdge("7", "6");
        g.addEdge("7", "8");
        g.addEdge("8", "7");

        // BFS dalla sorgente 1
        g.bfs("1");
    }
}