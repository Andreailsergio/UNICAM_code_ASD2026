package Graph_Matrix;

import java.util.*;

/**
 * DFS su grafo ORIENTATO — Java 8 compatibile.
 * Algoritmo di Cormen (cap. 20): colori, timestamp d[v]/f[v],
 * classificazione degli archi.
 * Complessità: O(V + E)
 */
public class DFSOrientato {

    // ── Rappresentazione del grafo ──────────────────────────────────────────

    private final List<String>              vertices;
    private final Map<String, List<String>> adj;

    public DFSOrientato() {
        vertices = new ArrayList<String>();
        adj      = new LinkedHashMap<String, List<String>>();
    }

    public void addVertex(String v) {
        if (!adj.containsKey(v)) {
            vertices.add(v);
            adj.put(v, new ArrayList<String>());
        }
    }

    /** Aggiunge arco ORIENTATO u → v */
    public void addEdge(String u, String v) {
        addVertex(u);
        addVertex(v);
        adj.get(u).add(v);
    }

    // ── Stato della DFS ─────────────────────────────────────────────────────

    private int                  time;
    private Map<String, Integer> color;   // 0=BIANCO, 1=GRIGIO, 2=NERO
    private Map<String, Integer> d;       // timestamp scoperta
    private Map<String, Integer> f;       // timestamp fine
    private Map<String, String>  parent;  // predecessore nell'albero DFS

    // ── Algoritmo principale ────────────────────────────────────────────────

    /**
     * DFS completa: visita tutti i vertici del grafo (anche sconnesso).
     * Ordine: come appaiono nella lista vertices.
     */
    public void dfs() {
        // Inizializzazione
        color  = new LinkedHashMap<String, Integer>();
        d      = new LinkedHashMap<String, Integer>();
        f      = new LinkedHashMap<String, Integer>();
        parent = new LinkedHashMap<String, String>();
        time   = 0;

        for (String v : vertices) {
            color.put(v, 0);        // BIANCO
            parent.put(v, null);
        }

        // Per ogni vertice ancora BIANCO, avvia una nuova visita
        for (String v : vertices) {
            if (color.get(v) == 0) {
                System.out.println("\n[Nuova radice DFS] " + v);
                dfsVisit(v);
            }
        }

        printResults();
    }

    /**
     * DFS-VISIT ricorsiva (Cormen).
     */
    private void dfsVisit(String u) {
        color.put(u, 1);             // GRIGIO: u scoperto
        time++;
        d.put(u, time);
        System.out.printf("  Scopro (gray)   %-3s  d[%s]=%d%n", u, u, time);

        for (String v : adj.get(u)) {
            int colorV = color.get(v);

            if (colorV == 0) {
                // Arco dell'albero: v era BIANCO
                System.out.printf("    %s → %s : ARCO ALBERO%n", u, v);
                parent.put(v, u);
                dfsVisit(v);

            } else if (colorV == 1) {
                // Arco all'indietro: v è GRIGIO (antenato ancora aperto)
                // Questo implica l'esistenza di un CICLO
                System.out.printf("    %s → %s : ARCO INDIETRO  [CICLO]%n", u, v);

            } else {
                // v è NERO: arco in avanti o trasversale
                if (d.get(u) < d.get(v)) {
                    // u scoperto prima di v → v è discendente → in avanti
                    System.out.printf("    %s → %s : ARCO IN AVANTI%n", u, v);
                } else {
                    // u scoperto dopo v → v è in ramo diverso → trasversale
                    System.out.printf("    %s → %s : ARCO TRASVERSALE%n", u, v);
                }
            }
        }

        color.put(u, 2);             // NERO: u completato
        time++;
        f.put(u, time);
        System.out.printf("  Completo (black) %-3s  f[%s]=%d%n", u, u, time);
    }

    // ── Stampa risultati ────────────────────────────────────────────────────

    private void printResults() {
        System.out.println("\n════════════════════════════════════════");
        System.out.println(" Vertice  | d[v] | f[v] | parent");
        System.out.println("──────────┼──────┼──────┼─────────");
        for (String v : vertices) {
            String par = parent.get(v) == null ? "NIL" : parent.get(v);
            System.out.printf("   %-6s  |  %-3d |  %-3d | %s%n",
                    v, d.get(v), f.get(v), par);
        }
        System.out.println("════════════════════════════════════════");
    }

    // ── Main di test ────────────────────────────────────────────────────────

    /**
     * Grafo orientato del corso (animazione dfs_grafo_B.html):
     *
     *   B → A, B → D, B → E
     *   A → C
     *   C → B, C → E
     *   E → D, E → F
     *   D → F
     *
     * Risultato atteso (DFS da B):
     *   B(1/12), A(2/11), C(3/10), E(4/9), D(5/8), F(6/7)
     */
    public static void main(String[] args) {
        // es. Cormen
        DFSOrientato g = new DFSOrientato();

        // Vertici (ordine = ordine di visita se bianchi)
        g.addVertex("B");
        g.addVertex("A");
        g.addVertex("C");
        g.addVertex("E");
        g.addVertex("D");
        g.addVertex("F");

        // Archi orientati
        g.addEdge("B", "A");
        g.addEdge("B", "D");
        g.addEdge("B", "E");
        g.addEdge("A", "C");
        g.addEdge("C", "B");   // arco all'indietro → ciclo
        g.addEdge("C", "E");
        g.addEdge("E", "D");
        g.addEdge("E", "F");
        g.addEdge("D", "F");

        g.dfs();

        // esercizio
        DFSOrientato g2 = new DFSOrientato();

        // Vertici (ordine = ordine crescente di chiave)
        g2.addVertex("1");
        g2.addVertex("2");
        g2.addVertex("3");
        g2.addVertex("4");
        g2.addVertex("5");
        g2.addVertex("6");
        g2.addVertex("7");
        g2.addVertex("8");

        // Archi orientati
        g2.addEdge("1", "2");
        g2.addEdge("1", "5");
        g2.addEdge("1", "6");
        g2.addEdge("3", "7");
        g2.addEdge("4", "8");
        g2.addEdge("6", "3");
        g2.addEdge("7", "3");
        g2.addEdge("7", "6");
        g2.addEdge("7", "8");
        g2.addEdge("8", "7");



        g2.dfs();
    }
}