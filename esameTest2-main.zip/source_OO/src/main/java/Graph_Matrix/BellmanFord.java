package Graph_Matrix;

import java.util.*;

// ══════════════════════════════════════════════════════════
//  Arco orientato pesato  (nome univoco: BFArc)
// ══════════════════════════════════════════════════════════

class BFArc {
    final String u;
    final String v;
    final int    weight;

    BFArc(String u, String v, int weight) {
        this.u = u;
        this.v = v;
        this.weight = weight;
    }

    @Override
    public String toString() {
        return u + " →" + v + " (" + weight + ")";
    }
}

// ══════════════════════════════════════════════════════════
//  Risultato Bellman-Ford  (nome univoco: BFCammino)
// ══════════════════════════════════════════════════════════

class BFCammino {
    /** Distanza minima dalla sorgente. Integer.MAX_VALUE = ∞ (non raggiungibile). */
    final Map<String, Integer> dist;
    /** Predecessore nel cammino minimo. */
    final Map<String, String>  pred;
    /** true se rilevato ciclo di peso negativo raggiungibile dalla sorgente. */
    final boolean              negativeCycle;

    BFCammino(Map<String, Integer> dist,
              Map<String, String>  pred,
              boolean              negativeCycle) {
        this.dist          = Collections.unmodifiableMap(dist);
        this.pred          = Collections.unmodifiableMap(pred);
        this.negativeCycle = negativeCycle;
    }

    /**
     * Ricostruisce il cammino dalla sorgente a dst come lista di vertici.
     * Restituisce lista vuota se dst non è raggiungibile o c'è ciclo negativo.
     */
    public List<String> path(String src, String dst) {
        if (negativeCycle) return Collections.emptyList();
        if (!dist.containsKey(dst) || dist.get(dst) == Integer.MAX_VALUE)
            return Collections.emptyList();
        LinkedList<String> p = new LinkedList<>();
        for (String cur = dst; cur != null; cur = pred.get(cur))
            p.addFirst(cur);
        return p;
    }

    @Override
    public String toString() {
        if (negativeCycle)
            return "CICLO NEGATIVO RILEVATO — risultati non affidabili";
        Map<String, Integer> reachable = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> e : dist.entrySet())
            if (e.getValue() != Integer.MAX_VALUE)
                reachable.put(e.getKey(), e.getValue());
        return "dist=" + reachable;
    }
}

// ══════════════════════════════════════════════════════════
//  Grafo orientato pesato  (nome univoco: BFGrafo)
// ══════════════════════════════════════════════════════════

/**
 * Grafo orientato pesato per Bellman-Ford.
 * Rappresentato con lista di vertici + lista di archi orientati.
 * Complessità bellmanFord(): O(V · E).
 */
class BFGrafo {

    private final List<String> vertices = new ArrayList<>();
    private final List<BFArc>  edges    = new ArrayList<>();

    public void addVertex(String v) {
        if (!vertices.contains(v))
            vertices.add(v);
    }

    /** Aggiunge arco orientato u → v con peso w (w può essere negativo). */
    public void addEdge(String u, String v, int w) {
        addVertex(u);
        addVertex(v);
        edges.add(new BFArc(u, v, w));
    }

    public List<String> getVertices() { return Collections.unmodifiableList(vertices); }
    public List<BFArc>  getEdges()    { return Collections.unmodifiableList(edges); }

    /**
     * Algoritmo di Bellman-Ford — cammini minimi da sorgente singola.
     *
     * PASSO 1 — Initialize-Single-Source:
     *   dist[v] = ∞ per tutti i vertici, dist[src] = 0
     *
     * PASSO 2 — |V|−1 passate di rilassamento su tutti gli archi:
     *   per ogni arco (u,v,w): se dist[u]+w < dist[v] → dist[v]=dist[u]+w, pred[v]=u
     *   Dopo la i-esima passata sono garantiti corretti i cammini con ≤ i archi.
     *
     * PASSO 3 — Rilevamento ciclo negativo:
     *   se dopo |V|−1 passate esiste ancora un arco rilassabile → ciclo negativo.
     *
     * @param src vertice sorgente
     * @return BFCammino con distanze, predecessori e flag ciclo negativo
     * @throws IllegalArgumentException se src non è nel grafo
     */
    public BFCammino bellmanFord(String src) {
        if (!vertices.contains(src))
            throw new IllegalArgumentException("Sorgente non trovata: " + src);

        // PASSO 1
        Map<String, Integer> dist = new LinkedHashMap<>();
        Map<String, String>  pred = new LinkedHashMap<>();
        for (String v : vertices) {
            dist.put(v, Integer.MAX_VALUE);
            pred.put(v, null);
        }
        dist.put(src, 0);

        // PASSO 2
        int n = vertices.size();
        for (int i = 1; i <= n - 1; i++) {
            boolean updated = false;
            for (BFArc e : edges) {
                if (dist.get(e.u) == Integer.MAX_VALUE) continue;
                int newDist = dist.get(e.u) + e.weight;
                if (newDist < dist.get(e.v)) {
                    dist.put(e.v, newDist);
                    pred.put(e.v, e.u);
                    updated = true;
                }
            }
            if (!updated) break; // convergenza anticipata
        }

        // PASSO 3
        boolean negativeCycle = false;
        for (BFArc e : edges) {
            if (dist.get(e.u) == Integer.MAX_VALUE) continue;
            if (dist.get(e.u) + e.weight < dist.get(e.v)) {
                negativeCycle = true;
                break;
            }
        }

        return new BFCammino(dist, pred, negativeCycle);
    }
}

// ══════════════════════════════════════════════════════════
//  Main — demo
// ══════════════════════════════════════════════════════════

/**
 * Esempio 1: Cormen Fig. 25.7 — pesi negativi, no ciclo
 *   Atteso: s=0, t=2, x=4, y=7, z=-2
 *   Cammino s→z: [s, y, x, t, z]
 *
 * Esempio 2: ciclo negativo A→B→C→A (peso totale -1)
 *   Atteso: negativeCycle = true
 */
public class BellmanFord {

    public static void main(String[] args) {

        // ── Esempio 1: Cormen Fig. 25.7 ──────────────────
        System.out.println("════════════════════════════════════════════════");
        System.out.println(" BELLMAN-FORD — Cormen Fig. 25.7 (pesi negativi)");
        System.out.println("════════════════════════════════════════════════");

        BFGrafo g1 = new BFGrafo();
        g1.addEdge("s", "t",  6);
        g1.addEdge("s", "y",  7);
        g1.addEdge("t", "x",  5);
        g1.addEdge("t", "y",  8);
        g1.addEdge("t", "z", -4);
        g1.addEdge("x", "t", -2);
        g1.addEdge("y", "x", -3);
        g1.addEdge("y", "z",  9);
        g1.addEdge("z", "s",  2);
        g1.addEdge("z", "x",  7);

        BFCammino r1 = g1.bellmanFord("s");
        System.out.println(r1);
        System.out.println("Ciclo negativo : " + r1.negativeCycle);
        System.out.println("Cammino s → z  : " + r1.path("s", "z"));
        System.out.println("Cammino s → t  : " + r1.path("s", "t"));
        System.out.println("Cammino s → x  : " + r1.path("s", "x"));
        // Atteso: s=0, t=2, x=4, y=7, z=-2  |  s→z: [s, y, x, t, z]

        // ── Esempio 2: ciclo negativo ─────────────────────
        System.out.println("\n════════════════════════════════════════════════");
        System.out.println(" BELLMAN-FORD — Rilevamento ciclo negativo");
        System.out.println("════════════════════════════════════════════════");

        BFGrafo g2 = new BFGrafo();
        g2.addEdge("A", "B",  1);
        g2.addEdge("B", "C", -3);
        g2.addEdge("C", "A",  1); // ciclo A→B→C→A, peso totale = -1

        BFCammino r2 = g2.bellmanFord("A");
        System.out.println("Ciclo negativo rilevato: " + r2.negativeCycle);
        // Atteso: true
    }
}