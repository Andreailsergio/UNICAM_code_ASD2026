package Graph_Matrix;

public class MatrixChainOrder {

    static int[][] m; // m[i][j] = costo minimo di moltiplicazione A_i ... A_j
    static int[][] s; // s[i][j] = punto di taglio ottimo per A_i ... A_j

    /**
     * Algoritmo Matrix-Chain-Order (bottom-up, programmazione dinamica).
     * p[0..n] è il vettore delle dimensioni: la matrice A_i ha dimensioni p[i-1] x p[i].
     * Complessità: Theta(n^3) tempo, Theta(n^2) spazio.
     */
    public static void matrixChainOrder(int[] p) {
        int n = p.length - 1; // numero di matrici
        m = new int[n + 1][n + 1];
        s = new int[n + 1][n + 1];

        // Caso base: catene di lunghezza 1 (singola matrice), costo zero
        for (int i = 1; i <= n; i++) {
            m[i][i] = 0;
        }

        // len = lunghezza della sottocatena considerata (da 2 a n)
        for (int len = 2; len <= n; len++) {

            // i = indice di inizio della sottocatena
            for (int i = 1; i <= n - len + 1; i++) {
                int j = i + len - 1; // indice di fine della sottocatena

                m[i][j] = Integer.MAX_VALUE; // inizializza a infinito

                // Prova tutti i possibili punti di taglio k
                for (int k = i; k < j; k++) {
                    int q = m[i][k]              // costo parte sinistra (già calcolato)
                            + m[k + 1][j]          // costo parte destra (già calcolato)
                            + p[i - 1] * p[k] * p[j]; // costo della moltiplicazione finale

                    if (q < m[i][j]) {
                        m[i][j] = q;  // aggiorna il costo minimo
                        s[i][j] = k;  // memorizza il punto di taglio ottimo
                    }
                }
            }
        }
    }

    /**
     * Stampa la parentesizzazione ottima usando la tabella s.
     */
    public static void printOptimalParens(int[][] s, int i, int j) {
        if (i == j) {
            System.out.print("A" + i);
        } else {
            System.out.print("(");
            printOptimalParens(s, i, s[i][j]);       // parte sinistra
            printOptimalParens(s, s[i][j] + 1, j);  // parte destra
            System.out.print(")");
        }
    }

    public static void main(String[] args) {
        // Matrici: A1(30x35), A2(35x15), A3(15x5), A4(5x10), A5(10x20), A6(20x25)
        int[] p = {30, 35, 15, 5, 10, 20, 25};
        int n = p.length - 1;

        matrixChainOrder(p);

        System.out.println("Costo minimo: " + m[1][n]); // atteso: 15125

        System.out.print("Parentesizzazione ottima: ");
        printOptimalParens(s, 1, n);
        System.out.println();
        // Output atteso: ((A1(A2A3))((A4A5)A6))
    }
}
