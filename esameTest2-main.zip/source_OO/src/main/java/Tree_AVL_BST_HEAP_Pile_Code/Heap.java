package Tree_AVL_BST_HEAP_Pile_Code;

import java.util.*;
/**
 * Implementazione di un heap minimo (min-heap) tramite array.
 * L'array è 1-based: la radice è in posizione 1,
 * il figlio sinistro di i è in 2*i, il figlio destro in 2*i+1.
 * La posizione 0 non viene usata.
 *
 * Nota: gli indici helper del template sono 0-based ma la logica che usiamo
 * qui è 1-based per semplicità con parent = index/2.
 */
public class Heap {

    // Helper di indice (presenti nel template, non usati direttamente
    // nell'implementazione 1-based, ma mantenuti per compatibilità)
    private static int getParentIndex(int index) {
        return index / 2;
    }

    private static int getLeftChildIndex(int index) {
        return 2 * index;
    }

    private static int getRightChildIndex(int index) {
        return 2 * index + 1;
    }

    private static final int MAX_DEFAULT_CAPACITY = 200;

    /** L'array che rappresenta l'heap (1-based: posizione 0 inutilizzata). */
    private int[] tree;
    private int maxCapacity;

    /** Numero di elementi attualmente nell'heap. */
    private int size;

    // -------------------------------------------------------------------------
    // Costruttori
    // -------------------------------------------------------------------------

    public Heap() {
        this(MAX_DEFAULT_CAPACITY);
    }

    public Heap(int maxCapacity) {
        this.maxCapacity = maxCapacity;
        // +1 perché usiamo indici 1..maxCapacity (posizione 0 ignorata)
        this.tree = new int[maxCapacity + 1];
        this.size = 0;
    }

    // -------------------------------------------------------------------------
    // Metodi pubblici
    // -------------------------------------------------------------------------

    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Aggiunge un valore all'heap.
     * Restituisce false se il valore è già presente o se l'heap è pieno.
     */
    public boolean add(int value) {
        if (size >= maxCapacity) return false;

        // Controlla duplicati: scansione lineare (heap non è un set per def.,
        // ma il test addDuplicateElementReturnsFalse lo richiede)
        for (int i = 1; i <= size; i++) {
            if (tree[i] == value) return false;
        }

        // Inserisci in fondo e risistema verso l'alto
        size++;
        tree[size] = value;
        heapifyUp(size);
        return true;
    }

    /**
     * Restituisce il valore minimo (radice) senza rimuoverlo.
     *
     * @throws NoSuchElementException se l'heap è vuoto
     */
    public int getMin() {
        if (isEmpty())
            throw new java.util.NoSuchElementException("L'heap è vuoto.");
        return tree[1];
    }

    /**
     * Rimuove e restituisce il valore minimo (radice).
     *
     * @throws NoSuchElementException se l'heap è vuoto
     */
    public int removeMin() {
        if (isEmpty())
            throw new java.util.NoSuchElementException("L'heap è vuoto.");

        int min = tree[1];
        // Sposta l'ultimo elemento alla radice e dimezza
        tree[1] = tree[size];
        tree[size] = 0; // pulisce la posizione (opzionale)
        size--;

        if (size > 0) heapify(1); // ripristina la proprietà heap dall'alto
        return min;
    }

    // -------------------------------------------------------------------------
    // Metodi privati
    // -------------------------------------------------------------------------

    /**
     * Ripristina la proprietà di min-heap risalendo dall'indice dato verso la
     * radice (bubble-up / sift-up). Usato dopo add().
     */
    private void heapifyUp(int index) {
        while (index > 1) {
            int parent = getParentIndex(index);
            if (tree[index] < tree[parent]) {
                swap(index, parent);
                index = parent;
            } else {
                break;
            }
        }
    }

    /**
     * Ripristina la proprietà di min-heap scendendo dall'indice dato verso le
     * foglie (sift-down). Usato dopo removeMin().
     */
    private void heapify(int index) {
        while (true) {
            int left  = getLeftChildIndex(index);
            int right = getRightChildIndex(index);
            int smallest = index;

            if (left <= size && tree[left] < tree[smallest])   smallest = left;
            if (right <= size && tree[right] < tree[smallest]) smallest = right;

            if (smallest != index) {
                swap(index, smallest);
                index = smallest;
            } else {
                break;
            }
        }
    }

    // -------------------------------------------------------------------------
    // Utility
    // -------------------------------------------------------------------------

    /**
     * Ritorna una copia dell'array interno (per i test).
     * L'array restituito è 0-based e ha lunghezza uguale a tree.length.
     */
    protected int[] getTree() {
        int[] copy = new int[tree.length];
        System.arraycopy(tree, 0, copy, 0, tree.length);
        return copy;
    }

    private void swap(int i, int j) {
        int temp = tree[i];
        tree[i] = tree[j];
        tree[j] = temp;
    }
}
