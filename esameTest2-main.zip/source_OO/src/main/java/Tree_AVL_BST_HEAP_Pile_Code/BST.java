package Tree_AVL_BST_HEAP_Pile_Code;

import java.util.*;

/**
 * Implementazione di un insieme (set) basato su un albero binario di ricerca.
 * L'iteratore restituisce gli elementi in ordine crescente (visita in-order).
 *
 * @param <E> il tipo degli elementi contenuti nell'insieme
 */
public class BST<E extends Comparable<E>> implements Set<E>, SortedSet<E> {

    // -------------------------------------------------------------------------
    // Nodo interno
    // -------------------------------------------------------------------------

    private static class Node<E> {
        E key;
        Node<E> left, right;

        Node(E key) {
            this.key = key;
        }
    }

    // -------------------------------------------------------------------------
    // Stato
    // -------------------------------------------------------------------------

    private Node<E> root;
    private int size;

    // -------------------------------------------------------------------------
    // Costruttore
    // -------------------------------------------------------------------------

    public BST() {
        root = null;
        size = 0;
    }

    // -------------------------------------------------------------------------
    // Metodi principali
    // -------------------------------------------------------------------------

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean contains(Object o) {
        if (o == null) throw new NullPointerException();
        E key = (E) o;
        Node<E> cursor = root;
        while (cursor != null) {
            int cmp = key.compareTo(cursor.key);
            if (cmp < 0)      cursor = cursor.left;
            else if (cmp > 0) cursor = cursor.right;
            else              return true;
        }
        return false;
    }

    @Override
    public boolean add(E e) {
        if (e == null) throw new NullPointerException();
        int[] inserted = {0};
        root = insert(root, e, inserted);
        if (inserted[0] == 1) { size++; return true; }
        return false;
    }

    /** Inserimento ricorsivo; usa inserted[0] come flag per segnalare l'inserimento. */
    private Node<E> insert(Node<E> node, E key, int[] inserted) {
        if (node == null) {
            inserted[0] = 1;
            return new Node<>(key);
        }
        int cmp = key.compareTo(node.key);
        if (cmp < 0)      node.left  = insert(node.left,  key, inserted);
        else if (cmp > 0) node.right = insert(node.right, key, inserted);
        // cmp == 0: duplicato, non si inserisce
        return node;
    }

    @Override
    @SuppressWarnings("unchecked")
    public boolean remove(Object o) {
        if (o == null) throw new NullPointerException();
        E key = (E) o;
        int[] removed = {0};
        root = delete(root, key, removed);
        if (removed[0] == 1) { size--; return true; }
        return false;
    }

    /** Eliminazione ricorsiva con sostituzione tramite successore in-order. */
    private Node<E> delete(Node<E> node, E key, int[] removed) {
        if (node == null) return null;
        int cmp = key.compareTo(node.key);
        if (cmp < 0) {
            node.left  = delete(node.left,  key, removed);
        } else if (cmp > 0) {
            node.right = delete(node.right, key, removed);
        } else {
            removed[0] = 1;
            if (node.left == null)  return node.right;
            if (node.right == null) return node.left;
            // Sostituisce il nodo con il minimo del sottoalbero destro
            Node<E> successor = minNode(node.right);
            node.key   = successor.key;
            node.right = delete(node.right, successor.key, new int[1]);
        }
        return node;
    }

    private Node<E> minNode(Node<E> node) {
        while (node.left != null) node = node.left;
        return node;
    }

    private Node<E> maxNode(Node<E> node) {
        while (node.right != null) node = node.right;
        return node;
    }

    @Override
    public void clear() {
        root = null;
        size = 0;
    }

    // -------------------------------------------------------------------------
    // Iterator (in-order)
    // -------------------------------------------------------------------------

    @Override
    public Iterator<E> iterator() {
        return new InOrderIterator();
    }

    /**
     * Iteratore in-order iterativo tramite stack esplicito.
     */
    private class InOrderIterator implements Iterator<E> {

        private final Deque<Node<E>> stack = new ArrayDeque<>();

        InOrderIterator() {
            pushLeft(root);
        }

        private void pushLeft(Node<E> node) {
            while (node != null) {
                stack.push(node);
                node = node.left;
            }
        }

        @Override
        public boolean hasNext() {
            return !stack.isEmpty();
        }

        @Override
        public E next() {
            if (!hasNext()) throw new NoSuchElementException();
            Node<E> node = stack.pop();
            pushLeft(node.right);
            return node.key;
        }
    }

    // -------------------------------------------------------------------------
    // SortedSet
    // -------------------------------------------------------------------------

    @Override
    public Comparator<? super E> comparator() {
        return E::compareTo;
    }

    @Override
    public E first() {
        if (isEmpty()) throw new NoSuchElementException();
        return minNode(root).key;
    }

    @Override
    public E last() {
        if (isEmpty()) throw new NoSuchElementException();
        return maxNode(root).key;
    }

    @Override
    public SortedSet<E> subSet(E fromElement, E toElement) {
        SortedSet<E> result = new TreeSet<>();
        for (E e : this) {
            if (e.compareTo(fromElement) >= 0 && e.compareTo(toElement) < 0)
                result.add(e);
        }
        return result;
    }

    @Override
    public SortedSet<E> headSet(E toElement) {
        SortedSet<E> result = new TreeSet<>();
        for (E e : this) {
            if (e.compareTo(toElement) < 0) result.add(e);
        }
        return result;
    }

    @Override
    public SortedSet<E> tailSet(E fromElement) {
        SortedSet<E> result = new TreeSet<>();
        for (E e : this) {
            if (e.compareTo(fromElement) >= 0) result.add(e);
        }
        return result;
    }

    // -------------------------------------------------------------------------
    // Bulk operations
    // -------------------------------------------------------------------------

    @Override
    public boolean containsAll(Collection<?> c) {
        for (Object o : c) if (!contains(o)) return false;
        return true;
    }

    @Override
    public boolean addAll(Collection<? extends E> c) {
        boolean changed = false;
        for (E e : c) changed |= add(e);
        return changed;
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        boolean changed = false;
        for (Object o : c) changed |= remove(o);
        return changed;
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        boolean changed = false;
        Iterator<E> it = iterator();
        List<E> toRemove = new ArrayList<>();
        while (it.hasNext()) {
            E e = it.next();
            if (!c.contains(e)) toRemove.add(e);
        }
        for (E e : toRemove) changed |= remove(e);
        return changed;
    }


    // -------------------------------------------------------------------------
    // equals / hashCode  (contratto java.util.Set)
    // -------------------------------------------------------------------------

    /**
     * Due Set sono uguali se e solo se hanno la stessa dimensione e ogni
     * elemento del primo è contenuto nel secondo (contratto java.util.AbstractSet).
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Set)) return false;
        Set<?> other = (Set<?>) obj;
        if (size != other.size()) return false;
        for (E e : this) {
            if (!other.contains(e)) return false;
        }
        return true;
    }

    /**
     * L'hashCode di un Set è la somma degli hashCode dei suoi elementi
     * (contratto java.util.AbstractSet).
     */
    @Override
    public int hashCode() {
        int h = 0;
        for (E e : this) {
            h += e.hashCode();
        }
        return h;
    }

    // -------------------------------------------------------------------------
    // Unsupported
    // -------------------------------------------------------------------------

    @Override
    public Object[] toArray() { throw new UnsupportedOperationException(); }

    @Override
    public <T> T[] toArray(T[] a) { throw new UnsupportedOperationException(); }
}
