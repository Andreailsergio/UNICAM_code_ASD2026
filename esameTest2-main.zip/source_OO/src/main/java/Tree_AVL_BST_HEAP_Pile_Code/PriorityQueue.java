//package it.unicam.cs.asdl2526.provaesame3;
package Tree_AVL_BST_HEAP_Pile_Code;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementazione di una coda di priorità basata su un heap binario.
 * L'heap è un max-heap, quindi l'elemento con la massima priorità è sempre
 * alla radice dell'heap.
 * @param <E> il tipo degli elementi nella coda di priorità
 *
 * I TEST DI VERIFICA DEVONO VALIDARE:
 * a.	testAddValidElement [aggiungere un elemento va a buon fine (si incrementa la dimensione e IsEmplty è falso)];
 * b.	testAddNullValueThrowsException [aggiungere un valore null da errore “NullPointerException”];
 * c.	testAddNegativePriorityThrowsException [aggiungere una priorità negativa da errore “IllegalArgumentException”];
 * d.	testGetMaxReturnsHighestPriorityElement [get_max cattura l’elemento con valore high se nza rimuoverlo – size rimane invariata];
 * e.	testPeakRemovesAndReturnsHighestPriorityElement [dopo il peak l’elemento immediatamente inferiore diventa il più alto];
 * f.	testGetMaxOnEmptyQueueThrowsException [prendere l’elemento massimo su una coda vuota da errore “IllegalStateException”];
 * g.	testPeakOnEmptyQueueThrowsException [fare un peak su una coda vuota da errore “IllegalStateException”];
 * h.	testGetMaxPriority [corretta procedura di estrazione del massimo];
 * i.	testGetMaxPriorityOnEmptyQueueThrowsException [prendere l’elemento con massima priorità su una coda vuota da errore “IllegalStateException”];
 * j.	testIsEmptyInitiallyTrue [Se è vuoto ha zero elementi di size];
 * k.	testIsEmptyAfterAdd [dopo l’aggiunta di un elemento IsEmpty è falso];
 * l.	testSizeAfterMultipleAdds [verifica la dimensione dopo l’aggiunta multipla di 3 elementi];
 * m.	testSizeAfterPeak [dopo il peak – operazione che estrae il massimo e risistema la lista delle priorità – la dimensione è -1];
 * n.	testClearEmptiesQueue [dopo il clear – che ricrea la struttura da zero con DEFAULT_CAPACITY - la lista è vuota e la dimensione 0];
 * o.	testClearThenOperationsFail [dopo il clear cercare il massimo da errore “IllegalStateException”];
 * p.	testSort [verifica correttezza ordinamento A B C - verifica: A(3) → C(2) → B(1)];
 * q.	testSortOnEmptyQueueReturnsEmptyList [ordinare una coda vuota restituisce una lista vuota];
 * r.	stressTestSorted [ordina una lista con n = 1000 elementi];
 */
public class PriorityQueue<E> {
    private static final int DEFAULT_CAPACITY = 17;

    private static int leftChildIndex(int index) {
        return 2 * index;
    }

    private static int rightChildIndex(int index) {
        return 2 * index + 1;
    }

    private static int parentIndex(int index) {
        return index / 2;
    }

    private static class Node<E> implements Comparable<Node<E>> {
        E value;
        int priority;

        Node(E value, int priority) {
            this.value = value;
            this.priority = priority;
        }

        @Override
        public int compareTo(Node<E> o) {
            return Integer.compare(this.priority, o.priority);
        }
    }

    java.util.PriorityQueue<Node<E>> q = new java.util.PriorityQueue<>();

    private Node<E>[] heap;

    private int size;

    public PriorityQueue() {
        this.heap = new Node[DEFAULT_CAPACITY];
        this.size = 0;
        this.heap[0] = new Node<>(null, Integer.MIN_VALUE);
    }

    /**
     * Aggiunge un elemento alla coda di priorità con la priorità specificata.
     * @param value l'elemento da aggiungere
     * @param priority la priorità dell'elemento
     * @throws IllegalArgumentException se la priorità è negativa
     * @throws NullPointerException se il valore è null
     */
    public void add(E value, int priority) {
        //TODO: implementato
        if (value == null)
            throw new NullPointerException("Il valore non può essere null");
        if (priority < 0)
            throw new IllegalArgumentException("La priorità non può essere negativa");

        // Espandi l'array se necessario
        if (this.size + 1 >= this.heap.length)
            resize();

        // Inserisci come ultima foglia (1-based: posizione size+1)
        // inserisce in fondo all'array e fa bubble-up
        // scambiando il nodo con il padre
        // finché la priorità del padre non è ≥ a quella del figlio.
        this.size++;
        this.heap[this.size] = new Node<>(value, priority);

        // Bubble-up: ripristina la proprietà del max-heap
        int i = this.size;
        while (i > 1 && heap[parentIndex(i)].compareTo(heap[i]) < 0) {
            Node<E> tmp = heap[i];
            heap[i] = heap[parentIndex(i)];
            heap[parentIndex(i)] = tmp;
            i = parentIndex(i);
        }
    }

    /**
     * Rimuove e restituisce l'elemento con la massima priorità dalla coda.
     * @return l'elemento con la massima priorità
     * @throws IllegalStateException se la coda è vuota
     */
    public E peak() {
        //TODO: implementato
        if (isEmpty())
            throw new IllegalStateException("La coda è vuota");

        E maxValue = heap[1].value;

        // Sostituisce la radice (il massimo per la definizione di max-heap)
        // con l'ultima foglia e decrementa size
        heap[1] = heap[this.size];
        heap[this.size] = null;
        this.size--;

        // chiama Heapify-down dalla radice per ripristinare le proprietà
        if (this.size > 0)
            heapifyDown(1);

        return maxValue;
    }

    /**
     * Restituisce l'elemento con la massima priorità senza rimuoverlo dalla coda.
     * @return l'elemento con la massima priorità
     * @throws IllegalStateException se la coda è vuota
     */
    public E getMax() {
        //TODO: implementato
        if (isEmpty())
            throw new IllegalStateException("La coda è vuota");
        // semplice lettura del valore (es. high, low)
        return heap[1].value;
    }

    /**
     * Restituisce la massima priorità presente nella coda di priorità.
     * @return la massima priorità
     * @throws IllegalStateException se la coda è vuota
     */
    public int getMaxPriority() {
        //TODO: implementato
        if (isEmpty())
            throw new IllegalStateException("La coda è vuota");
        // semplice lettura della priorità (numerico)
        return heap[1].priority;
    }

    /**
     * Rimuove tutti gli elementi dalla coda di priorità.
     * L'array che rappresenta l'heap deve essere reimpostato alla capacità iniziale.
     */
    @SuppressWarnings("unchecked")
    public void clear() {
        //TODO: implementato
        this.heap = new Node[DEFAULT_CAPACITY];
        this.heap[0] = new Node<>(null, Integer.MIN_VALUE);
        this.size = 0;
    }

    /**
     * Restituisce una lista contenente gli elementi della coda di priorità
     * @return una lista contenente gli elementi della coda di priorità
     */
    public List<E> sort() {
        //TODO: implementato
        List<E> result = new ArrayList<>();
        if (isEmpty())
            return result;
        // Copia dello stato corrente per non distruggere la coda
        Node<E>[] savedHeap = java.util.Arrays.copyOf(this.heap, this.heap.length);
        int savedSize = this.size;

        // Estrae tutti gli elementi in ordine decrescente di priorità (la massima è la prima)
        while (!isEmpty()) {
            result.add(peak());
        }

        // Ripristina lo stato originale
        this.heap = savedHeap;
        this.size = savedSize;

        return result;
    }

    public int size() {
        return this.size;
    }

    public boolean isEmpty() {
        return this.size == 0;
    }

    /**
     * Raddoppia la capacità dell'array che rappresenta l'heap.
     */
    @SuppressWarnings("unchecked")
    private void resize() {
        int newCapacity = this.heap.length * 2;
        Node<E>[] newHeap = new Node[newCapacity];
        System.arraycopy(this.heap, 0, newHeap, 0, this.heap.length);
        this.heap = newHeap;
    }

    /**
     * Heapify-down: ripristina la proprietà max-heap scendendo dall'indice i.
     */
    private void heapifyDown(int i) {
        int largest = i;
        int left = leftChildIndex(i);
        int right = rightChildIndex(i);

        if (left <= this.size && heap[left].compareTo(heap[largest]) > 0)
            largest = left;
        if (right <= this.size && heap[right].compareTo(heap[largest]) > 0)
            largest = right;

        if (largest != i) {
            Node<E> tmp = heap[i];
            heap[i] = heap[largest];
            heap[largest] = tmp;
            heapifyDown(largest);
        }
    }
}
