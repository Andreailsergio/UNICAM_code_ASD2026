package Hash_LinkedList_Map;

/**
 * Tabella hash con indirizzamento aperto e double hashing. La capacità della
 * tabella è fissata al momento della creazione e non può essere modificata
 * successivamente.
 * <p>
 * La tabella memorizza oggetti non nulli e non accetta duplicati secondo
 * il metodo {@link Object#equals(Object)}. La posizione iniziale e il passo
 * della sequenza di scansione sono calcolati a partire da
 * {@link Object#hashCode()}.
 * </p>
 * <p>
 * La cancellazione è gestita mediante una sentinella interna che rappresenta
 * una cella cancellata.
 * </p>
 */
public class MyDoubleHashTable {

    // sentinella
    private static final Object DELETED = new Object();
    // tabella hash
    private final Object[] table;
    // funzione hash primaria
    private final PrimaryHashFunction h1;
    // funzione hash usata per calcolare il passo nell'indirizzamento aperto
    private final SecondaryHashFunction h2;
    // numero di elementi correnti nella tabella
    private int size;

    /**
     * Crea una nuova tabella hash con la dimensione indicata.
     *
     * @param initialSize la dimensione iniziale della tabella
     * @throws IllegalArgumentException se {@code initialSize <= 0}
     */
    public MyDoubleHashTable(int initialSize) {
        if (initialSize <= 0)
            throw new IllegalArgumentException("Initial size must be positive");

        this.table = new Object[initialSize];
        this.h1 = new PrimaryHashFunction();
        this.h2 = new SecondaryHashFunction();
        this.size = 0;
    }

    /**
     * Restituisce il numero di elementi attualmente presenti nella tabella.
     *
     * @return il numero di elementi presenti
     */
    public int size() {
        return size;
    }

    /**
     * Restituisce la capacità della tabella.
     *
     * @return la lunghezza dell'array interno
     */
    public int capacity() {
        return table.length;
    }

    /**
     * Verifica se un elemento è presente nella tabella.
     *
     * @param element l'elemento da cercare
     * @return {@code true} se l'elemento è presente, {@code false} altrimenti
     * @throws NullPointerException se {@code element} è {@code null}
     */
    public boolean contains(Object element) {
        // TODO implementare
        // throw new UnsupportedOperationException("Not Implemented");
        if (element == null) throw new NullPointerException("Elemento passato come parametro nullo");


        // int index = hashcode(element);
        // usare h1 per individuare il posizionamento e h2 per il passo nel caso sia occupato

        // CODICE CORRETTO PER GESTIRE HASHING DOPPIO:
        int key   = element.hashCode();
        int start = h1.hash(key, table.length);
        int step  = h2.hash(key, table.length);


        for (int i = 0; i < table.length; i++) {
            // int probe = (index + i) % table.length; // ERRATA GESTIONE DI 1 SOLO HASH
            // USARE questo codice per double hashing:
            int probe = (start + i * step) % table.length;

            // Object<Object> node = table[probe];
            Object cell = table[probe];

            // if (node == null) return false;        // elem non c'è
            // f (!node.isDeleted && node.equals(element)) return true;
            if (cell == null) return false;         // slot vuoto: fine catena
            if (cell == DELETED) continue;          // tombstone
            if (cell.equals(element)) return true;  // confronto elemento
                        // table[probe] = DELETED;    // cancellazione
        }
        return false;
    }

    //    QUESTA CLASSE NON ERA RICHIESTA -> ELIMINATA (è sufficiente usare la sentinella DELETED presente nel template
    //    private static class Node<Object> {
    //    Object value;
    //    boolean isDeleted;
    //
    //    Node(Object value) {
    //        this.value = value;
    //        this.isDeleted = false;
    //    }
    //
    //    public Object getValue() {
    //        return value;
    //    }
    //
    //    public void markDeleted() {
    //        this.isDeleted = true;
    //    }
    //   }

    /**
     * Inserisce un elemento nella tabella.
     * <p>
     * Se l'elemento è già presente secondo {@link Object#equals(Object)},
     * l'inserimento non viene effettuato.
     * </p>
     *
     * @param element l'elemento da inserire
     * @return {@code true} se l'elemento è stato inserito, {@code false}
     *         se era già presente
     * @throws NullPointerException se {@code element} è {@code null}
     * @throws FullHashTableException se la tabella è piena
     */
    public boolean insert(Object element) {
        // TODO implementare
        // throw new UnsupportedOperationException("Not Implemented");
        if (element == null) throw new NullPointerException("Elemento passato come parametro = nullo");
        // if (this.size > this.capacity()) throw new FullHashTableException("Tabella piena");
        // CONTROLLO ANTICIPATO RIMOSSO:
        // FullHashTableException va lanciato solo se il ciclo completo non trova nessuno slot
        // (né null e né DELETED)
        // inoltre FullHashTableException NON ACCETTA ARGOMENTI (è un costruttore senza parametri)

        // int index = hashCode(element);
        int key = element.hashCode();
        int start = h1.hash(key, table.length);
        int step = h2.hash(key, table.length);
        // int index = hashcode(element);

        int firstDeleted = -1; // prima slot DELETED trovata durante il probing

        for (int i = 0; i < table.length; i++) {

            // int probe = (index + i) % table.length;
            // Node<Object> node = table[probe];
            int probe = (start + i * step) % table.length;
            Object cell = table[probe];

            if (cell == null) {
                // slot libero: inserisci (riusa DELETED se trovato prima)
                int insertAt = (firstDeleted != -1) ? firstDeleted : probe;
                table[insertAt] = element;
                size++;
                return true;
            }
            if (cell == DELETED) {
                if (firstDeleted == -1) firstDeleted = probe;
                // continua: il duplicato potrebbe essere più avanti
            } else if (cell.equals(element)) {
                return false; // duplicato
            }


        }
        if (firstDeleted != -1) {
            table[firstDeleted] = element;
            size++;
            return true;
        }
        throw new FullHashTableException();
    }

    //    Object<Object> node = table[probe];
    //    if (node == null) {
    //        // Slot libero: inserisci (riusa uno slot DELETED se trovato)
    //        int insertAt = (firstDeleted != -1) ? firstDeleted : probe;
    //        table[insertAt] = new Node<>(element);
    //        size++;
    //        modCount++;
    //        return true;
    //    }
    //
    //    if (node.isDeleted) {
    //        // Teniamo nota del primo slot DELETED per riutilizzarlo
    //        if (firstDeleted == -1) firstDeleted = probe;
    //           // Continuiamo a cercare: potrebbe esserci il duplicato più avanti
    //    } else {
    //        // Slot occupato: controlla duplicato
    //        if (node.value.equals(element)) return false;
    //    }

    /**
     * Cancella un elemento dalla tabella, se presente.
     *
     * @param element l'elemento da cancellare
     * @return {@code true} se l'elemento è stato cancellato, {@code false}
     *         se non era presente
     * @throws NullPointerException se {@code element} è {@code null}
     */
    public boolean delete(Object element) {
        // TODO implementare
        // throw new UnsupportedOperationException("Not Implemented");
        if (element == null) throw new NullPointerException("Elemento passato come parametro = nullo");

        // gestire il DELETED

        // int index = hashcode(element);
        int key = element.hashCode();
        int start = h1.hash(key, table.length);
        int step  = h2.hash(key, table.length);

            for (int i = 0; i < table.length; i++) {
                // int probe = (index + i) % table.length;
                int probe = (start + i * step) % table.length;
                // Node<Object> node = table[probe];
                Object cell = table[probe];


                // if (node == null) return false;          // non trovato
                // if (!node.isDeleted && node.value.equals(element)) {
                //    node.markDeleted();
                //    size--;
                //    // modCount++;
                //    return true;
                //}


                if (cell == null)    return false;
                if (cell == DELETED) continue;
                if (cell.equals(element)) {
                    table[probe] = DELETED; // poni tombstone
                    size--;
                    return true;
                }
            }
            return false;
    }

    // TODO è possibile aggiungere metodi privati per fini di implementazione

    //
    //    @Override
    //    public int hashCode() {
    //        int h = 0;
    //        for (Node<Object> node : table) {
    //            if (node != null && !node.isDeleted) {
    //                h += node.value.hashCode();
    //            }
    //        }
    //        return h;
    //    }
    //

    // ATTENZIONE: Non modificare il codice qui sotto

    /**
     * Funzione hash primaria classica:
     *
     * <pre>
     * h1(k) = k mod m
     * </pre>
     */
    private static class PrimaryHashFunction {

        /**
         * Calcola la posizione iniziale per una chiave.
         *
         * @param key la chiave
         * @param m la dimensione della tabella
         * @return un valore tra {@code 0} e {@code m - 1}
         */
        public int hash(int key, int m) {
            return Math.floorMod(key, m);
        }
    }

    /**
     * Funzione hash secondaria classica:
     *
     * <pre>
     * h2(k) = 1 + (k mod (m - 1))
     * </pre>
     */
    private static class SecondaryHashFunction {

        /**
         * Calcola il passo della sequenza di scansione.
         *
         * @param key la chiave
         * @param m la dimensione della tabella
         * @return un valore tra {@code 1} e {@code m - 1}
         */
        public int hash(int key, int m) {
            if (m == 1)
                return 1;
            return 1 + Math.floorMod(key, m - 1);
        }
    }
}