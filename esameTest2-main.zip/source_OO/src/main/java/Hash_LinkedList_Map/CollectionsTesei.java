package Hash_LinkedList_Map;
import java.util.*;

// =============================================================================
//  UNICAM ASDL 2025/26 — Prof. Luca Tesei
//  Esempio completo: List, Set, SortedSet, Map
//  Struttura del file:
//    1. Studente  — classe dominio con equals/hashCode/compareTo/Comparator
//    2. EsempiList       — tutti i metodi di List<E>
//    3. EsempiSet        — HashSet, equals+hashCode
//    4. EsempiSortedSet  — TreeSet, Comparable, Comparator
//    5. EsempiMap        — HashMap, TreeMap, iterazione
//    6. Main             — esegue tutti gli esempi in sequenza
// =============================================================================


// ─────────────────────────────────────────────────────────────────────────────
// 1. CLASSE DOMINIO
//    Implementa Comparable<Studente> (ordinamento naturale per matricola).
//    Ridefinisce equals e hashCode coerentemente (basati su matricola).
//    Espone Comparator statici alternativi (per nome, per media decrescente).
// ─────────────────────────────────────────────────────────────────────────────
class Studente implements Comparable<Studente> {

    private final String matricola;
    private final String nome;
    private final double media;

    public Studente(String matricola, String nome, double media) {
        this.matricola = matricola;
        this.nome      = nome;
        this.media     = media;
    }

    // ── getter ────────────────────────────────────────────────────────────────
    public String getMatricola() { return matricola; }
    public String getNome()      { return nome; }
    public double getMedia()     { return media; }

    // ── equals + hashCode (basati su matricola) ───────────────────────────────
    // REGOLA Tesei: se ridefinisci equals, ridefinisci SEMPRE hashCode.
    // Due studenti sono "lo stesso" se hanno la stessa matricola.
    @Override
    public boolean equals(Object obj) {
        // se l'oggetto obj passato per riferimento è identico all'oggetto in memoria
        // velocizzo la risposta True perché so già per certo che sono uguali
        if (this == obj) return true;
        // se obj è di tipo diverso da studente o è null non può essere uguale
        if (!(obj instanceof Studente)) return false;
        // faccio il downcast assegnando ad altro per poter usare i metodi specifici ( es. getMatricola() )
        Studente altro = (Studente) obj;
        // ritorno True se i due oggetti studente hanno la stessa matricola
        // nome e media non servono per l'uguaglianza
        return this.matricola.equals(altro.matricola);
    }

    @Override
    public int hashCode() {
        // delega alla stringa matricola di calcolare il suo hashcode e lo restituisce
        // garantendo che sia equals e sia hashCode si riferiscano alla stessa matricola
        // si devono ridefinire con @Override i metodi equals e hashCode
        // (e anche compareTo per usare Comparable o Comparator)
        // per far rispettare la regola: se a.equals(b) è true  →  a.hashCode() == b.hashCode()
        // con qualunque degli oggetti su cui si baserà l'implementazione
        // (List, HashSet, TreeSet, HashMap, TreeMap) -> in realtà per List basta ridefinire solo equals
        return matricola.hashCode();
    }

    // ── ordinamento naturale (Comparable) ────────────────────────────────────
    // REGOLA Tesei: compareTo restituisce 0 se e solo se equals è true.
    @Override
    public int compareTo(Studente altro) {
        return this.matricola.compareTo(altro.matricola);
        // la classe Studente implementa l'interfaccia Comparable<Studente>
        // per poter usare l'ordinamento naturale lessicografico della matricola: "S001" < "S002" < "S003"...
    }

    // ── comparatori alternativi (Comparator) ─────────────────────────────────
    // creo al volo classi anonime con new Comparator<Studente> e le gestisco con delle COSTANTI
    // servono per poter avere altri criteri di ordinamento (x nome e x media) oltre al naturale (x matricola)
    // uso il metodo compare() (che, a differenza di compareTo(), riceve in input 2 parametri e non 1 solo)

    // Ordinamento per nome (crescente)
    public static final Comparator<Studente> ORDINA_PER_NOME =
        new Comparator<Studente>() {
            @Override
            public int compare(Studente s1, Studente s2) {
                return s1.getNome().compareTo(s2.getNome());
            }
        };

    // Ordinamento per media (decrescente)
    public static final Comparator<Studente> ORDINA_PER_MEDIA_DESC =
        new Comparator<Studente>() {
            @Override
            public int compare(Studente s1, Studente s2) {
                // s2 e s1 sono invertiti per avere ordine decrescente sulla media: i più alti prima
                return Double.compare(s2.getMedia(), s1.getMedia());
            }
        };

    @Override
    // Ridefinire toString() serve per la rappresentazione testuale personalizzata es. [S001 | Anna       | 30.0]
    // %s       → inserisce la stringa matricola
    // %-10s    → inserisce nome in un campo largo 10 caratteri, allineato a sinistra (il -)
    // %.1f     → inserisce media con 1 decimale
    public String toString() {
        return String.format("[%s | %-10s | %.1f]", matricola, nome, media);
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// 2. LIST<E>
//    Sequenza ordinata per posizione, ammette duplicati.
//    Implementazione principale: ArrayList<E>.
// I metodi principali:
// lista.add(new Studente("S003", "Mario", 27.5));    // aggiunge in coda
// lista.add(0, new Studente("S005", "Zara", 22.0));  // inserisce in posizione 0
// lista.get(0)            // legge l'elemento in posizione 0 — O(1)
// lista.set(0, elemento)  // sovrascrive la posizione 0
// lista.indexOf(elemento) // cerca con equals, restituisce l'indice (-1 se non trovato)
// lista.remove(0)         // rimuove per indice
// lista.remove(oggetto)   // rimuove per equals
// lista.contains(oggetto) // cerca con equals → true/false
// lista.size()            // numero di elementi
// ─────────────────────────────────────────────────────────────────────────────
class EsempiList {

    public static void esegui() {
        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║            LIST<E>                   ║");
        System.out.println("╚══════════════════════════════════════╝");

        // ── costruzione ───────────────────────────────────────────────────────
        List<Studente> lista = new ArrayList<>();
        lista.add(new Studente("S003", "Mario",  27.5));
        lista.add(new Studente("S001", "Anna",   30.0));
        lista.add(new Studente("S002", "Luigi",  25.0));
        lista.add(new Studente("S004", "Giulia", 28.5));
        lista.add(0, new Studente("S005", "Zara", 22.0)); // inserimento in pos 0

        System.out.println("\n── Lista iniziale ──");
        stampaLista(lista);

        // ── accesso per indice ────────────────────────────────────────────────
        System.out.println("\n── Accesso per indice ──");
        Studente primo = lista.get(0);
        System.out.println("Elemento in pos 0: " + primo);
        System.out.println("Indice di Anna: " + lista.indexOf(new Studente("S001","Anna",0)));

        // ── modifica ──────────────────────────────────────────────────────────
        System.out.println("\n── Modifica ──");
        lista.set(0, new Studente("S006", "Beatrice", 29.0)); // sostituisce pos 0
        System.out.println("Dopo set(0, Beatrice):");
        stampaLista(lista);

        // ── rimozione ─────────────────────────────────────────────────────────
        System.out.println("\n── Rimozione ──");
        lista.remove(0);                                      // rimuove per indice
        lista.remove(new Studente("S002", "Luigi", 0));       // rimuove per equals
        System.out.println("Dopo remove(0) e remove(Luigi):");
        stampaLista(lista);

        // ── ricerca ───────────────────────────────────────────────────────────
        System.out.println("\n── Ricerca ──");
        boolean presente = lista.contains(new Studente("S001", "Anna", 0)); // usa equals
        System.out.println("Anna presente? " + presente);
        System.out.println("Dimensione: " + lista.size());

        // TRE MODI PER SCORRERE UNA LISTA:
        // A ── FOR-EACH: solo lettura ────────────────────────────────────────────
        System.out.println("\n── Scorrimento con for-each (solo lettura) ──");
        for (Studente s : lista) {
            System.out.println("  " + s);
        }

        // B ── CICLO CON INDICE: quando serve la posizione ───────────────────────
        System.out.println("\n── Scorrimento con indice ──");
        for (int i = 0; i < lista.size(); i++) {
            System.out.println("  [" + i + "] " + lista.get(i));
        }

        // C ── ITERATORE: unico modo sicuro per rimuovere durante lo scorrimento ─
        System.out.println("\n── Rimozione con Iterator (studenti con media < 27) ──");
        Iterator<Studente> it = lista.iterator();
        while (it.hasNext()) {
            Studente s = it.next();
            if (s.getMedia() < 27.0) {
                it.remove();  // it.remove(), NON lista.remove() → evita ConcurrentModificationException
            }
        }
        System.out.println("Lista dopo rimozione studenti con media < 27:");
        stampaLista(lista);

        // ── AGGIUNTA DURANTE SCORRIMENTO: raccolta + addAll ───────────────────
        // la soluzione è raccogliere gli elementi in una lista separata e poi fare lista.addAll dopo il ciclo
        System.out.println("\n── Aggiunta sicura durante scorrimento (raccogliere + addAll) ──");
        List<Studente> daAggiungere = new ArrayList<>();
        Iterator<Studente> it2 = lista.iterator();
        while (it2.hasNext()) {
            Studente s = it2.next();
            if (s.getMedia() >= 30.0) {
                it2.remove();
                // creiamo uno "studente promosso" con matricola modificata
                daAggiungere.add(new Studente(s.getMatricola() + "L", s.getNome() + "-Lode", 30.0));
            }
        }
        lista.addAll(daAggiungere); // si aggiunge DOPO il ciclo
        System.out.println("Lista con lode:");
        stampaLista(lista);

        // ── ORDINAMENTO ───────────────────────────────────────────────────────
        // Riportiamo la lista a uno stato utile
        lista.clear();
        lista.add(new Studente("S003", "Mario",  27.5));
        lista.add(new Studente("S001", "Anna",   30.0));
        lista.add(new Studente("S002", "Luigi",  25.0));
        lista.add(new Studente("S004", "Giulia", 28.5));

        System.out.println("\n── Ordinamento naturale (per matricola, Comparable) ──");
        Collections.sort(lista);
        stampaLista(lista);

        System.out.println("\n── Ordinamento per nome (Comparator) ──");
        Collections.sort(lista, Studente.ORDINA_PER_NOME);
        stampaLista(lista);

        System.out.println("\n── Ordinamento per media decrescente (Comparator) ──");
        Collections.sort(lista, Studente.ORDINA_PER_MEDIA_DESC);
        stampaLista(lista);

        // ── SUBLIST ───────────────────────────────────────────────────────────
        System.out.println("\n── subList(0, 2) — vista live ──");
        List<Studente> top2 = lista.subList(0, 2);
        System.out.println("Top 2 per media:");
        stampaLista(top2);
    }

    private static void stampaLista(List<Studente> l) {
        l.forEach(s -> System.out.println("  " + s));
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// 3. SET<E>
//    Insieme senza duplicati, nessun ordine garantito.
//    Implementazione principale: HashSet<E>.
//    REQUISITO: la classe E DEVE ridefinire equals() + hashCode().
// ─────────────────────────────────────────────────────────────────────────────
class EsempiSet {

    public static void esegui() {
        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║            SET<E>                    ║");
        System.out.println("╚══════════════════════════════════════╝");

        Set<Studente> insieme = new HashSet<>();

        // ── aggiunta ──────────────────────────────────────────────────────────
        boolean aggiunto;
        aggiunto = insieme.add(new Studente("S001", "Anna",  30.0)); // true
        System.out.println("Aggiunta Anna (S001):  " + aggiunto);
        aggiunto = insieme.add(new Studente("S002", "Mario", 27.5)); // true
        System.out.println("Aggiunta Mario (S002): " + aggiunto);
        aggiunto = insieme.add(new Studente("S001", "Anna",  28.0)); // FALSE: stessa matricola => equals true
        System.out.println("Aggiunta Anna (S001) di nuovo: " + aggiunto + "  ← duplicato ignorato");

        System.out.println("\nDimensione insieme: " + insieme.size()); // 2

        // ── ricerca ───────────────────────────────────────────────────────────
        System.out.println("\n── Ricerca ──");
        boolean presente = insieme.contains(new Studente("S001", "Chiunque", 0));
        System.out.println("S001 presente? " + presente + "  (equals controlla solo matricola)");

        // ── iterazione ────────────────────────────────────────────────────────
        System.out.println("\n── Iterazione (ordine NON garantito) ──");
        for (Studente s : insieme) {
            System.out.println("  " + s);
        }

        // ── rimozione ─────────────────────────────────────────────────────────
        System.out.println("\n── Rimozione ──");
        boolean rimosso = insieme.remove(new Studente("S002", "Mario", 0));
        System.out.println("Rimosso Mario (S002): " + rimosso);
        System.out.println("Dimensione dopo rimozione: " + insieme.size());

        // ── operazioni insiemistiche ───────────────────────────────────────────
        System.out.println("\n── Operazioni insiemistiche ──");
        Set<Studente> a = new HashSet<>(Arrays.asList(
            new Studente("S001","Anna",30), new Studente("S002","Mario",27),
            new Studente("S003","Luigi",25)));
        Set<Studente> b = new HashSet<>(Arrays.asList(
            new Studente("S002","Mario",27), new Studente("S004","Giulia",28)));

        System.out.print(" --- RIEMPIO a CON 3 STUDENTI, b con 2 STUDENTI, di cui 1 duplicato su a  --- \n");
        System.out.print(" --- creo 3 copie con new HashSet, per non modificare la collezione originale  --- \n");
        System.out.print(" ---  a = S001, S002, S003 // b = S002, S004 --- \n");

        // unione
        Set<Studente> unione = new HashSet<>(a);
        unione.addAll(b); // aggiunge tutti gli elementi di b, ignorando i duplicati
        System.out.print("\nUnione (matricole): ");
        unione.forEach(s -> System.out.print(s.getMatricola() + " "));
        System.out.println("\n   -> addAll ha aggiunto elementi di b in a - ignorando i duplicati\n");
        System.out.println();

        // intersezione
        Set<Studente> intersezione = new HashSet<>(a);
        intersezione.retainAll(b); // mantiene in a solo gli elementi presenti anche in b
        System.out.print("Intersezione (matricole): ");
        intersezione.forEach(s -> System.out.print(s.getMatricola() + " "));
        System.out.println("\n   -> retainAll ha mantenuto in a solo elementi presenti in b - rimuovendo il resto\n");
        System.out.println();

        // differenza
        Set<Studente> differenza = new HashSet<>(a);
        differenza.removeAll(b); // rimuove da a tutti gli elementi presenti in b
        System.out.print("Differenza A\\B (matricole): ");
        differenza.forEach(s -> System.out.print(s.getMatricola() + " "));
        System.out.println("\n   -> removeAll ha rimosso da a tutti gli elementi presenti in b\n");
        System.out.println();
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// 4. SORTEDSET<E>
//    Insieme senza duplicati, elementi ORDINATI.
//    Implementazione: TreeSet<E>.
//    REQUISITO: E implementa Comparable, oppure si passa un Comparator:
//    cioé anziché creare new TreeSet<>() creo new TreeSet<>(Studente.ORDINA_PER_NOME)
//
// Metodi extra rispetto a Set:
// ordinato.first()    // elemento minimo (S001)
// ordinato.last()     // elemento massimo (S004)
// ordinato.headSet(x) // tutti gli elementi STRETTAMENTE minori di x
// ordinato.tailSet(x) // tutti gli elementi >= x
// ordinato.subSet(from, to) // elementi in [from, to) — from incluso, to escluso
// ─────────────────────────────────────────────────────────────────────────────
class EsempiSortedSet {

    public static void esegui() {
        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║         SORTEDSET<E>                 ║");
        System.out.println("╚══════════════════════════════════════╝");

        // ── TreeSet con ordinamento naturale (per matricola, Comparable) ───────
        System.out.println("\n── TreeSet con ordinamento naturale (matricola) ──");
        SortedSet<Studente> ordinato = new TreeSet<>();
        ordinato.add(new Studente("S003", "Mario",  27.5));
        ordinato.add(new Studente("S001", "Anna",   30.0));
        ordinato.add(new Studente("S004", "Giulia", 28.5));
        ordinato.add(new Studente("S002", "Luigi",  25.0));
        ordinato.add(new Studente("S001", "Anna",   30.0)); // duplicato: ignorato

        System.out.println("Elementi in ordine (l'iteratore scorre dal min al max):");
        for (Studente s : ordinato) {
            System.out.println("  " + s);
        }

        // ── metodi extra di SortedSet ─────────────────────────────────────────
        System.out.println("\n── Metodi extra di SortedSet ──");
        System.out.println("first() = " + ordinato.first());
        System.out.println("il minimo");
        System.out.println("last()  = " + ordinato.last());
        System.out.println("il massimo");

        // headSet: elementi STRETTAMENTE minori del valore dato
        SortedSet<Studente> head = ordinato.headSet(new Studente("S003","",0));
        System.out.print("headSet(S003) = ");
        head.forEach(s -> System.out.print(s.getMatricola() + " "));
        System.out.println("i minori di quello dato");
        System.out.println();

        // tailSet: elementi >= valore dato
        SortedSet<Studente> tail = ordinato.tailSet(new Studente("S003","",0));
        System.out.print("tailSet(S003) = ");
        tail.forEach(s -> System.out.print(s.getMatricola() + " "));
        System.out.println("i maggiori uguali di quello dato");
        System.out.println();

        // subSet: elementi in [from, to)
        SortedSet<Studente> sub = ordinato.subSet(
            new Studente("S002","",0), new Studente("S004","",0));
        System.out.print("subSet(S002,S004) = ");
        sub.forEach(s -> System.out.print(s.getMatricola() + " "));
        System.out.println("quelli compresi tra S002 e S004 escluso");
        System.out.println();

        // ── TreeSet con Comparator (per nome) ────────────────────────────────
        System.out.println("\n── TreeSet con Comparator (per nome) ──");
        SortedSet<Studente> perNome = new TreeSet<>(Studente.ORDINA_PER_NOME);
        perNome.add(new Studente("S003", "Mario",  27.5));
        perNome.add(new Studente("S001", "Anna",   30.0));
        perNome.add(new Studente("S004", "Giulia", 28.5));
        perNome.add(new Studente("S002", "Luigi",  25.0));
        perNome.forEach(s -> System.out.println("  " + s));

        // ── ricerca efficiente su SortedSet ───────────────────────────────────
        // Vantaggio: ci si può fermare appena si supera il punto di ricerca.
        System.out.println("\n── Ricerca efficiente su SortedSet ──");
        String cercaMatricola = "S003";
        boolean trovato = false;
        for (Studente s : ordinato) {
            int cmp = s.getMatricola().compareTo(cercaMatricola);
            if (cmp == 0) { trovato = true; break; }
            if (cmp > 0) { break; } // superato il punto → non c'è
        }
        System.out.println("Ricerca " + cercaMatricola + " su SortedSet: " + (trovato ? "trovato" : "non trovato"));

        // ── rimozione ─────────────────────────────────────────────────────────
        System.out.println("\n── Rimozione ──");
        ordinato.remove(new Studente("S002", "Luigi", 0)); // usa compareTo
        System.out.println("Dopo remove(S002):");
        ordinato.forEach(s -> System.out.println("  " + s));
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// 5. MAP<K,V>
//    Associa chiavi uniche a valori. Ogni chiave compare al massimo una volta.
//    HashMap: nessun ordine — TreeMap: ordine per chiave.
//    REQUISITO HashMap: K deve ridefinire equals + hashCode.
//    REQUISITO TreeMap: K deve essere Comparable (o fornire Comparator).
//
// I metodi principali:
// rubrica.put("S001", new Studente("S001", "Anna", 30.0));
// rubrica.put("S001", new Studente("S001", "Anna", 29.0)); // sovrascrive il precedente
// rubrica.get("S001");                          // restituisce Anna con media 29.0
// rubrica.get("S999");                          // null: chiave non presente
// rubrica.getOrDefault("S999", new Studente()); // restituisce il default se assente
//          in Studente defaultVal ho definito un nuovo oggetto con matricola "???", nome "N/A" e media 0
// rubrica.containsKey("S002");                  // true/false
// rubrica.remove("S003");                       // rimuove la coppia con chiave S003
//
// Map<String, Studente> ordinata = new TreeMap<>(rubrica); // per restituzione di copia ordinata per chiave
// Map<String, Studente> inversa = new TreeMap<>(Comparator.reverseOrder()); // per restituzione in ordine inverso
// ─────────────────────────────────────────────────────────────────────────────
class EsempiMap {

    public static void esegui() {
        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║            MAP<K,V>                  ║");
        System.out.println("╚══════════════════════════════════════╝");

        // ── HashMap: chiave=matricola, valore=Studente ─────────────────────────
        System.out.println("\n── HashMap<String, Studente> ──");
        Map<String, Studente> rubrica = new HashMap<>();

        // inserimento / aggiornamento
        rubrica.put("S001", new Studente("S001", "Anna",   30.0));
        rubrica.put("S002", new Studente("S002", "Mario",  27.5));
        rubrica.put("S003", new Studente("S003", "Luigi",  25.0));
        rubrica.put("S004", new Studente("S004", "Giulia", 28.5));
        rubrica.put("S001", new Studente("S001", "Anna",   29.0)); // sovrascrive Anna
        System.out.println("inserisco 5 elementi, ma l'ultimo sovrascrive quello già presente con chiave identica");
        System.out.println("S001 Anna 30.0, S002 Mario 27.5, S003 Luigi 25.0, S004 Giulia 28.5, S001 Anna 29.0");

        System.out.println("Dimensione: " + rubrica.size());

        // recupero
        Studente anna = rubrica.get("S001");
        System.out.println("get(S001) = " + anna);

        Studente assente = rubrica.get("S999");
        System.out.println("get(S999) = " + assente);           // null

        // cerco S999 che non esiste nella Mappa,
        // quindi getOrDefault restituisce il valore di default passato come secondo argomento,
        // cioè un nuovo oggetto Studente con matricola "???", nome "N/A" e media 0.
        // Questo oggetto viene assegnato alla variabile defaultVal
        Studente defaultVal = rubrica.getOrDefault("S999", new Studente("???","N/A",0));
        System.out.println("\ngetOrDefault(S999) = " + defaultVal); // default
        System.out.println("con getOrDefault un nuovo oggetto Studente");
        System.out.println("con matricola ???, nome N/A, media 0");
        System.out.println("è stato assegnato alla variabile defaultVal\n");

        // appartenenza
        System.out.println("containsKey(S002)? " + rubrica.containsKey("S002"));
        System.out.println("containsValue(voto 30)?");
        // non esiste con Map un modo diretto ed efficiente per cercare per valore
        // containsValue(30) esiste come metodo, ma internamente scorre tutti i valori uno per uno
        // fino a trovarne uno uguale — è quindi lento su mappe grandi,
        // e soprattutto non ti dice quale chiave ha quel valore, dice solo si o no, c'è o non c'è.
        System.out.println("non diretto: iteriamo! Esistono 3 modi differenti");

        // ── tre modi di iterazione ─────────────────────────────────────────────
        // 1. entrySet() — chiave e valore insieme (il più usato)
        System.out.println("\n── Iterazione: entrySet (chiave + valore) ──");
        for (Map.Entry<String, Studente> entry : rubrica.entrySet()) {
            System.out.println("  " + entry.getKey() + " → " + entry.getValue());
        }

        // 2. keySet() — solo le chiavi
        System.out.println("\n── Iterazione: keySet (sole chiavi) ──");
        for (String chiave : rubrica.keySet()) {
            System.out.print("  " + chiave);
        }
        System.out.println();

        // 3. values() — solo i valori
        System.out.println("\n── Iterazione: values (soli valori) ──");
        for (Studente s : rubrica.values()) {
            System.out.print("  " + s.getNome());
        }
        System.out.println();

        // ── ricerca per valore (iterazione su entrySet) ───────────────────────
        System.out.println("\n── Ricerca per valore: studenti con media >= 28 ──");
        for (Map.Entry<String, Studente> entry : rubrica.entrySet()) {
            if (entry.getValue().getMedia() >= 28.0) {
                System.out.println("  " + entry.getKey() + " → " + entry.getValue());
            }
        }

        // ── rimozione ─────────────────────────────────────────────────────────
        System.out.println("\n── Rimozione ──");
        rubrica.remove("S003");
        System.out.println("Dopo remove(S003), size = " + rubrica.size());

        // ── manipolazione: voto = media arrotondata all'intero ────────────────
        System.out.println("\n── Costruzione Map<String,Integer> matricola→voto ──");
        Map<String, Integer> voti = new HashMap<>();
        for (Map.Entry<String, Studente> e : rubrica.entrySet()) {
            voti.put(e.getKey(), (int) Math.round(e.getValue().getMedia()));
        }
        voti.forEach((k, v) -> System.out.println("  " + k + " → " + v));

        // ── TreeMap: ordine per chiave ─────────────────────────────────────────
        System.out.println("\n── TreeMap<String, Studente> — ordine per matricola ──");
        Map<String, Studente> ordinata = new TreeMap<>(rubrica); // copia ordinata
        for (Map.Entry<String, Studente> entry : ordinata.entrySet()) {
            System.out.println("  " + entry.getKey() + " → " + entry.getValue());
        }

        // ── TreeMap con Comparator personalizzato (ordine inverso) ────────────
        System.out.println("\n── TreeMap con Comparator (ordine matricola inverso) ──");
        Map<String, Studente> inversa = new TreeMap<>(Comparator.reverseOrder());
        inversa.putAll(rubrica);
        inversa.forEach((k, v) -> System.out.println("  " + k + " → " + v));

        // ── Map come frequenza: conta quante volte appare ogni voto ───────────
        // Il risultato è una mappa dove la chiave è il voto e il valore è quante volte compare.
        System.out.println("\n── Conteggio frequenze voti ──");
        List<Integer> votiList = Arrays.asList(28, 30, 27, 28, 30, 30, 25, 28);
        System.out.println("nuova lista con voti: 28, 30, 27, 28, 30, 30, 25, 28");
        Map<Integer, Integer> frequenza = new TreeMap<>(); // TreeMap → ordine per voto
        for (int voto : votiList) {
            // Pattern "conteggio frequenze":
            // getOrDefault(voto, 0) restituisce 0 se il voto non è ancora nella mappa (prima occorrenza),
            // altrimenti restituisce il conteggio attuale. Poi si incrementa di 1 e si reinserisce
            // grazie a frequenza.put(voto, ...)
            frequenza.put(voto, frequenza.getOrDefault(voto, 0) + 1);
        }
        frequenza.forEach((voto, freq) -> System.out.println("  voto " + voto + " → " + freq + " volte"));
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// 6. MAIN — esegue tutte le sezioni
// ─────────────────────────────────────────────────────────────────────────────
public class CollectionsTesei {

    public static void main(String[] args) {

        System.out.println("╔══════════════════════════════════════════════════════════╗");
        System.out.println("║   UNICAM ASDL 2025/26 — Collections — Prof. Luca Tesei   ║");
        System.out.println("╚══════════════════════════════════════════════════════════╝");

        EsempiList.esegui();
        EsempiSet.esegui();
        EsempiSortedSet.esegui();
        EsempiMap.esegui();

        System.out.println("\n\n╔═══════════════════════════════════════════════════════════╗");
        System.out.println("║  SCHEMA RIASSUNTIVO — quando usare cosa (da Tesei)        ║");
        System.out.println("╠═══════════════════════════════════════════════════════════╣");
        System.out.println("║  List<E>      ArrayList   sequenza+posizione+duplicati    ║");
        System.out.println("║               requisito E: equals (per contains/remove)   ║");
        System.out.println("║  Set<E>       HashSet     insieme non ordinato            ║");
        System.out.println("║               requisito E: equals + hashCode              ║");
        System.out.println("║  SortedSet<E> TreeSet     insieme ordinato                ║");
        System.out.println("║               requisito E: Comparable (o Comparator)      ║");
        System.out.println("║  Map<K,V>     HashMap     chiave→valore, nessun ordine    ║");
        System.out.println("║               requisito K: equals + hashCode              ║");
        System.out.println("║               TreeMap     chiave→valore, ordine per K     ║");
        System.out.println("║               requisito K: Comparable (o Comparator)      ║");
        System.out.println("╠═══════════════════════════════════════════════════════════╣");
        System.out.println("║  REGOLE D'ORO Tesei:                                      ║");
        System.out.println("║  • equals ridefinito → ridefinire SEMPRE hashCode         ║");
        System.out.println("║  • compareTo == 0  ⟺  equals == true                     ║");
        System.out.println("║  • rimozione durante iterazione → usare Iterator.remove() ║");
        System.out.println("║  • aggiunta durante iterazione → raccogliere + addAll()   ║");
        System.out.println("╚═══════════════════════════════════════════════════════════╝");
    }
}
