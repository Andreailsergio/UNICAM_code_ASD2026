package Tree_AVL_BST_HEAP_Pile_Code;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class AVLTest {

    @Test
    void addIncreasesTreeSize() {
        Tree_AVL_BST_HEAP_Pile_Code.AVL tree = new Tree_AVL_BST_HEAP_Pile_Code.AVL();
        assertTrue(tree.add(10));
        assertTrue(tree.add(20));
        assertFalse(tree.add(10));
    }

    @Test
    void containsFindsExistingValues() {
        Tree_AVL_BST_HEAP_Pile_Code.AVL tree = new Tree_AVL_BST_HEAP_Pile_Code.AVL();
        tree.add(15);
        tree.add(10);
        tree.add(20);
        assertTrue(tree.contains(15));
        assertTrue(tree.contains(10));
        assertTrue(tree.contains(20));
        assertFalse(tree.contains(25));
    }

    @Test
    void inOrderVisitReturnsCorrectOrder() {
        Tree_AVL_BST_HEAP_Pile_Code.AVL tree = new Tree_AVL_BST_HEAP_Pile_Code.AVL();
        tree.add(15);
        tree.add(10);
        tree.add(20);
        tree.add(5);
        tree.add(12);
        assertEquals(Arrays.asList(5, 10, 12, 15, 20), tree.InOrderVisit());
    }

    @Test
    void postOrderVisitReturnsCorrectOrder() {
        Tree_AVL_BST_HEAP_Pile_Code.AVL tree = new Tree_AVL_BST_HEAP_Pile_Code.AVL();
        tree.add(15);
        tree.add(10);
        tree.add(20);
        tree.add(5);
        tree.add(12);
        assertEquals(Arrays.asList(5, 12, 10, 20, 15), tree.postOrder());
    }

    @Test
    void leftRotationUpdatesRootCorrectly() {
        Tree_AVL_BST_HEAP_Pile_Code.AVL tree = new Tree_AVL_BST_HEAP_Pile_Code.AVL();
        tree.add(10);
        tree.add(20);
        tree.add(30);
        assertEquals(20, tree.root.value);
        assertEquals(10, tree.root.left.value);
        assertEquals(30, tree.root.right.value);
    }

    @Test
    void rightRotationUpdatesRootCorrectly() {
        Tree_AVL_BST_HEAP_Pile_Code.AVL tree = new Tree_AVL_BST_HEAP_Pile_Code.AVL();
        tree.add(30);
        tree.add(20);
        tree.add(10); // Causes right rotation
        assertEquals(20, tree.root.value);
        assertEquals(10, tree.root.left.value);
        assertEquals(30, tree.root.right.value);
    }

    @Test
    void leftRightRotationUpdatesRootCorrectly() {
        Tree_AVL_BST_HEAP_Pile_Code.AVL tree = new Tree_AVL_BST_HEAP_Pile_Code.AVL();
        tree.add(30);
        tree.add(10);
        tree.add(20);
        assertEquals(20, tree.root.value);
        assertEquals(10, tree.root.left.value);
        assertEquals(30, tree.root.right.value);
    }

    @Test
    void rightLeftRotationUpdatesRootCorrectly() {
        Tree_AVL_BST_HEAP_Pile_Code.AVL tree = new Tree_AVL_BST_HEAP_Pile_Code.AVL();
        tree.add(10);
        tree.add(30);
        tree.add(20);
        assertEquals(20, tree.root.value);
        assertEquals(10, tree.root.left.value);
        assertEquals(30, tree.root.right.value);
    }
}
