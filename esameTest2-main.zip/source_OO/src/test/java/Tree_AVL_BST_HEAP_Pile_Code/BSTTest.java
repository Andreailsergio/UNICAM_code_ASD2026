package Tree_AVL_BST_HEAP_Pile_Code;

import Tree_AVL_BST_HEAP_Pile_Code.SetTest;

import java.util.Set;

import org.junit.jupiter.api.Test;

public class BSTTest extends SetTest {

    // CORREZIONE: era new HashSet<>() — il test deve usare BST, non HashSet.
    // Con HashSet, add(null) non lancia NullPointerException e il test
    // addNullElement() (ereditato da CollectionTest via SetTest) falliva.
    @Override
    public <E extends Comparable<E>> Set<E> createSet() {
        return new Tree_AVL_BST_HEAP_Pile_Code.BST<>();
    }

}
