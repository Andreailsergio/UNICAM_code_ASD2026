package Tree_AVL_BST_HEAP_Pile_Code;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class HeapTest {

    @Test
    void newHeapIsEmpty() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        assertTrue(heap.isEmpty());
    }

    @Test
    void heapWithCustomSizeIsEmpty() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap(32);
        assertTrue(heap.isEmpty());
    }

    @Test
    void addSingleElementMakesHeapNotEmpty() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        assertTrue(heap.add(10));
        assertFalse(heap.isEmpty());
    }

    @Test
    void addMultipleElementsInOrder() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        assertTrue(heap.add(5));
        assertTrue(heap.add(10));
        assertTrue(heap.add(15));
        assertFalse(heap.isEmpty());
    }

    @Test
    void addMultipleElementsReverseOrder() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        assertTrue(heap.add(15));
        assertTrue(heap.add(10));
        assertTrue(heap.add(5));
        assertEquals(5, heap.getMin());
    }

    @Test
    void addDuplicateElementReturnsFalse() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        assertTrue(heap.add(10));
        assertFalse(heap.add(10));
    }

    @Test
    void addManyElementsExceedsInitialCapacity() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        for (int i = 0; i < 20; i++) {
            assertTrue(heap.add(i));
        }
        assertEquals(0, heap.getMin());
    }

    @Test
    void getMinReturnsSmallestElement() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        heap.add(20);
        heap.add(10);
        heap.add(30);
        assertEquals(10, heap.getMin());
    }

    @Test
    void getMinDoesNotRemoveElement() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        heap.add(5);
        assertEquals(5, heap.getMin());
        assertEquals(5, heap.getMin());
        assertFalse(heap.isEmpty());
    }

    @Test
    void getMinOnEmptyHeapThrowsException() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        assertThrows(Exception.class, () -> heap.getMin());
    }

    @Test
    void removeMinReturnsAndRemovesSmallestElement() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        heap.add(10);
        heap.add(5);
        heap.add(15);
        assertEquals(5, heap.removeMin());
        assertEquals(10, heap.getMin());
    }

    @Test
    void removeMinUntilEmpty() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        heap.add(30);
        heap.add(10);
        heap.add(20);
        assertEquals(10, heap.removeMin());
        assertEquals(20, heap.removeMin());
        assertEquals(30, heap.removeMin());
        assertTrue(heap.isEmpty());
    }

    @Test
    void removeMinOnEmptyHeapThrowsException() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        assertThrows(Exception.class, () -> heap.removeMin());
    }

    @Test
    void removeMinMaintainsHeapProperty() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        heap.add(5);
        heap.add(10);
        heap.add(3);
        heap.add(20);
        heap.add(15);
        
        assertEquals(3, heap.removeMin());
        assertEquals(5, heap.getMin());
    }

    @Test
    void heapifyUpMaintainsMinHeapProperty() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        heap.add(50);
        heap.add(30);
        heap.add(20);
        heap.add(10);
        assertEquals(10, heap.getMin());
    }

    @Test
    void addAndRemoveInSequence() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        for (int i = 10; i >= 1; i--) {
            heap.add(i);
        }
        for (int i = 1; i <= 10; i++) {
            assertEquals(i, heap.removeMin());
        }
        assertTrue(heap.isEmpty());
    }

    @Test
    void stressTestWithManyElements() {
        Tree_AVL_BST_HEAP_Pile_Code.Heap heap = new Tree_AVL_BST_HEAP_Pile_Code.Heap();
        for (int i = 100; i > 0; i--) {
            assertTrue(heap.add(i));
        }
        assertEquals(1, heap.getMin());
        
        for (int i = 1; i <= 100; i++) {
            assertEquals(i, heap.removeMin());
        }
        assertTrue(heap.isEmpty());
    }
}