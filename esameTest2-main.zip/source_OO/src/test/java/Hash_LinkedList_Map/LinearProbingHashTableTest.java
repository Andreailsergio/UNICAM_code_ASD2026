package Hash_LinkedList_Map;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LinearProbingHashTableTest {
    
    private LinearProbingHashTable<Integer> table;
    
    @BeforeEach
    void setUp() {
        table = new LinearProbingHashTable<>();
    }
    
    @Test
    void testConstructor() {
        assertNotNull(table);
        assertEquals(0, table.size());
        assertTrue(table.isEmpty());
    }
    
    @Test
    void testInsertSingleElement() {
        assertTrue(table.insert(42));
        assertEquals(1, table.size());
        assertFalse(table.isEmpty());
        assertTrue(table.contains(42));
    }
    
    @Test
    void testInsertDuplicate() {
        assertTrue(table.insert(10));
        assertFalse(table.insert(10)); // Duplicato
        assertEquals(1, table.size());
    }
    
    @Test
    void testInsertNull() {
        assertThrows(NullPointerException.class, () -> table.insert(null));
    }
    
    @Test
    void testInsertMultipleElements() {
        for (int i = 1; i <= 5; i++) {
            assertTrue(table.insert(i));
        }
        assertEquals(5, table.size());
        for (int i = 1; i <= 5; i++) {
            assertTrue(table.contains(i));
        }
    }
    
    @Test
    void testInsertWithCollisions() {
        assertTrue(table.insert(0));
        assertTrue(table.insert(11));
        assertTrue(table.insert(22));
        
        assertEquals(3, table.size());
        assertTrue(table.contains(0));
        assertTrue(table.contains(11));
        assertTrue(table.contains(22));
    }
    
    @Test
    void testContainsEmptyTable() {
        assertFalse(table.contains(42));
    }
    
    @Test
    void testContainsExistingElement() {
        table.insert(100);
        assertTrue(table.contains(100));
    }
    
    @Test
    void testContainsNonExistingElement() {
        table.insert(100);
        assertFalse(table.contains(200));
    }
    
    @Test
    void testContainsNull() {
        assertThrows(NullPointerException.class, () -> table.contains(null));
    }
    
    @Test
    void testContainsAfterCollision() {
        table.insert(0);
        table.insert(11); // Collide con 0
        
        assertTrue(table.contains(0));
        assertTrue(table.contains(11));
        assertFalse(table.contains(22)); // Stesso hash ma non presente
    }
    
    @Test
    void testSizeEmptyTable() {
        assertEquals(0, table.size());
    }
    
    @Test
    void testSizeAfterInsertions() {
        table.insert(1);
        assertEquals(1, table.size());
        table.insert(2);
        assertEquals(2, table.size());
        table.insert(1); // Duplicato
        assertEquals(2, table.size());
    }
    
    @Test
    void testIsEmptyInitially() {
        assertTrue(table.isEmpty());
    }
    
    @Test
    void testIsEmptyAfterInsertion() {
        table.insert(42);
        assertFalse(table.isEmpty());
    }
    
    @Test
    void testClearEmptyTable() {
        table.clear();
        assertEquals(0, table.size());
        assertTrue(table.isEmpty());
    }
    
    @Test
    void testClearNonEmptyTable() {
        table.insert(1);
        table.insert(2);
        table.insert(3);
        
        table.clear();
        
        assertEquals(0, table.size());
        assertTrue(table.isEmpty());
        assertFalse(table.contains(1));
        assertFalse(table.contains(2));
        assertFalse(table.contains(3));
    }
    
    @Test
    void testInsertAfterClear() {
        table.insert(10);
        table.clear();
        assertTrue(table.insert(20));
        assertEquals(1, table.size());
        assertTrue(table.contains(20));
    }
    
    @Test
    void testLoadFactorEmpty() {
        assertEquals(0.0, table.loadFactor(), 0.001);
    }
    
    @Test
    void testLoadFactorAfterInsertions() {
        // Capacità iniziale = 11
        table.insert(1);
        assertEquals(1.0 / 11.0, table.loadFactor(), 0.001);
        
        table.insert(2);
        assertEquals(2.0 / 11.0, table.loadFactor(), 0.001);
    }
    
    @Test
    void testResizeTriggered() {
        for (int i = 1; i <= 8; i++) {
            table.insert(i);
        }
        
        assertEquals(8, table.size());
        for (int i = 1; i <= 8; i++) {
            assertTrue(table.contains(i), "Elemento " + i + " dovrebbe essere presente dopo resize");
        }
        
        assertTrue(table.loadFactor() < 0.7, "Load factor dovrebbe essere < 0.7 dopo resize");
    }
    
    @Test
    void testResizePreservesAllElements() {
        for (int i = 0; i < 20; i++) {
            assertTrue(table.insert(i));
        }
        
        assertEquals(20, table.size());
        
        for (int i = 0; i < 20; i++) {
            assertTrue(table.contains(i), "Elemento " + i + " mancante dopo resize");
        }
    }
    
    @Test
    void testResizeWithCollisions() {
        int[] collidingElements = {0, 11, 22, 33, 44, 55, 66, 77};
        
        for (int elem : collidingElements) {
            table.insert(elem);
        }
        
        for (int elem : collidingElements) {
            assertTrue(table.contains(elem), "Elemento " + elem + " mancante");
        }
    }

    @Test
    void testLargeNumberOfInsertions() {
        int n = 1000;
        for (int i = 0; i < n; i++) {
            assertTrue(table.insert(i));
        }
        
        assertEquals(n, table.size());
        
        for (int i = 0; i < n; i++) {
            assertTrue(table.contains(i));
        }
    }
    
    @Test
    void testAlternatingInsertAndContains() {
        for (int i = 0; i < 50; i++) {
            table.insert(i);
            assertTrue(table.contains(i));
            assertEquals(i + 1, table.size());
        }
    }
    
    @Test
    void testWithStrings() {
        LinearProbingHashTable<String> stringTable = new LinearProbingHashTable<>();
        
        assertTrue(stringTable.insert("hello"));
        assertTrue(stringTable.insert("world"));
        assertFalse(stringTable.insert("hello")); // Duplicato
        
        assertEquals(2, stringTable.size());
        assertTrue(stringTable.contains("hello"));
        assertTrue(stringTable.contains("world"));
        assertFalse(stringTable.contains("foo"));
    }
    
}