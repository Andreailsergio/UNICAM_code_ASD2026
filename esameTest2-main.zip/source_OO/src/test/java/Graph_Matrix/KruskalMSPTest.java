package Graph_Matrix;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.Set;

/**
 * Classe di test per la classe KruskalMSP.
 *
 * @author Luca Tesei, Federico Di Petta (template)
 */
class KruskalMSPTest {

    // =========================================================
    //  TEST ECCEZIONI
    // =========================================================

    @Test
    final void testExceptions() {
        KruskalMSP<String> alg = new KruskalMSP<String>();

        // grafo null → NullPointerException
        assertThrows(NullPointerException.class,
                () -> alg.computeMSP(null));

        // grafo orientato → IllegalArgumentException
        // (MatrixGraph è non orientato, usiamo un grafo orientato fittizio
        //  costruendo un Graph che riporta isDirected() = true)
        // Nota: MatrixGraph è sempre non orientato, quindi testiamo
        // direttamente con un grafo non pesato e con peso negativo.

        Graph1<String> gr = new MatrixGraph<String>();
        gr.addNode("a");
        gr.addNode("b");
        gr.addNode("c");

        // arco senza peso → IllegalArgumentException
        gr.addEdge("a", "b");
        gr.addWeightedEdge("b", "c", 3.0);
        assertThrows(IllegalArgumentException.class,
                () -> alg.computeMSP(gr));

        // grafo con peso negativo → IllegalArgumentException
        gr.clear();
        gr.addNode("a");
        gr.addNode("b");
        gr.addNode("c");
        gr.addWeightedEdge("a", "b", 4.0);
        gr.addWeightedEdge("b", "c", -1.0);
        assertThrows(IllegalArgumentException.class,
                () -> alg.computeMSP(gr));
    }

    // =========================================================
    //  TEST getMstEdges prima di computeMSP
    // =========================================================

    @Test
    final void testGetMstEdgesBeforeCompute() {
        KruskalMSP<String> alg = new KruskalMSP<String>();
        // prima di qualsiasi chiamata deve restituire null
        assertNull(alg.getMstEdges());
    }

    // =========================================================
    //  TEST grafo con un solo nodo (nessun arco)
    // =========================================================

    @Test
    final void testSingleNode() {
        Graph1<String> gr = new MatrixGraph<String>();
        gr.addNode("a");
        KruskalMSP<String> alg = new KruskalMSP<String>();
        alg.computeMSP(gr);
        // MST di un grafo con un solo nodo: insieme vuoto
        assertNotNull(alg.getMstEdges());
        assertTrue(alg.getMstEdges().isEmpty());
    }

    // =========================================================
    //  TEST grafo con due nodi connessi
    // =========================================================

    @Test
    final void testTwoNodes() {
        Graph1<String> gr = new MatrixGraph<String>();
        gr.addNode("a");
        gr.addNode("b");
        gr.addWeightedEdge("a", "b", 5.0);
        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");

        KruskalMSP<String> alg = new KruskalMSP<String>();
        alg.computeMSP(gr);

        // Set<GraphEdge<L>> mst = alg.getMstEdges();
        Set<GraphEdge<String>> mst = alg.getMstEdges();
        assertNotNull(mst);
        assertEquals(1, mst.size());
        // L'unico arco dell'MST deve collegare a e b con peso 5
        GraphEdge<String> e = mst.iterator().next();
        assertTrue(
            (e.getNode1().equals(a) && e.getNode2().equals(b)) ||
            (e.getNode1().equals(b) && e.getNode2().equals(a))
        );
        assertEquals(5.0, e.getWeight());
    }

    // =========================================================
    //  TEST grafo con due nodi NON connessi
    // =========================================================

    @Test
    final void testTwoNodesDisconnected() {
        Graph1<String> gr = new MatrixGraph<String>();
        gr.addNode("a");
        gr.addNode("b");
        // nessun arco → grafo non connesso
        KruskalMSP<String> alg = new KruskalMSP<String>();
        alg.computeMSP(gr);
        // Kruskal produce una foresta: 0 archi
        assertNotNull(alg.getMstEdges());
        assertTrue(alg.getMstEdges().isEmpty());
    }

    // =========================================================
    //  TEST grafo classico del corso (9 nodi, 14 archi)
    //  Grafo identico a testFindMSP1 di PrimMSPTest
    //  MST atteso: 8 archi, peso totale = 37
    // =========================================================

    @Test
    final void testKruskal1() {
        Graph1<String> gr = new MatrixGraph<String>();
        gr.addNode("a"); gr.addNode("b"); gr.addNode("c");
        gr.addNode("d"); gr.addNode("e"); gr.addNode("f");
        gr.addNode("g"); gr.addNode("h"); gr.addNode("i");
        gr.addWeightedEdge("a", "b", 4);
        gr.addWeightedEdge("a", "h", 8.5);
        gr.addWeightedEdge("b", "h", 11);
        gr.addWeightedEdge("b", "c", 8);
        gr.addWeightedEdge("c", "i", 2);
        gr.addWeightedEdge("c", "d", 7);
        gr.addWeightedEdge("c", "f", 4);
        gr.addWeightedEdge("d", "f", 14);
        gr.addWeightedEdge("d", "e", 9);
        gr.addWeightedEdge("e", "f", 10);
        gr.addWeightedEdge("f", "g", 2);
        gr.addWeightedEdge("g", "i", 6);
        gr.addWeightedEdge("g", "h", 1);
        gr.addWeightedEdge("h", "i", 7);

        KruskalMSP<String> alg = new KruskalMSP<String>();
        alg.computeMSP(gr);

        Set<GraphEdge<String>> mst = alg.getMstEdges();
        assertNotNull(mst);
        // MST di 9 nodi ha esattamente 8 archi
        assertEquals(8, mst.size());

        // Verifica peso totale dell'MST
        // Archi attesi: g-h(1), c-i(2), f-g(2), a-b(4), c-f(4), c-d(7), a-h(8.5), d-e(9)
        double totalWeight = 0;
        for (GraphEdge<String> e : mst)
            totalWeight += e.getWeight();
        //assertEquals(37.5, totalWeight, 0.001);
        assertEquals(37, totalWeight, 0.001);

        // Verifica che archi specifici siano presenti nell'MST
        GraphNode<String> g = gr.getNode("g");
        GraphNode<String> h = gr.getNode("h");
        assertTrue(mstContainsEdge(mst, g, h, 1.0),
                "MST deve contenere g-h (peso 1)");

        GraphNode<String> c = gr.getNode("c");
        GraphNode<String> i = gr.getNode("i");
        assertTrue(mstContainsEdge(mst, c, i, 2.0),
                "MST deve contenere c-i (peso 2)");

        GraphNode<String> f = gr.getNode("f");
        assertTrue(mstContainsEdge(mst, f, g, 2.0),
                "MST deve contenere f-g (peso 2)");

        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");
        assertTrue(mstContainsEdge(mst, a, b, 4.0),
                "MST deve contenere a-b (peso 4)");

        assertTrue(mstContainsEdge(mst, c, f, 4.0),
                "MST deve contenere c-f (peso 4)");

        GraphNode<String> d = gr.getNode("d");
        assertTrue(mstContainsEdge(mst, c, d, 7.0),
                "MST deve contenere c-d (peso 7)");

        // assertTrue(mstContainsEdge(mst, a, h, 8.5),
        //        "MST deve contenere a-h (peso 8.5)");
        assertFalse(mstContainsEdge(mst, a, h, 8.5),
                        "MST non deve contenere a-h (peso 8.5): h è già raggiunto da g-h(1)");

        GraphNode<String> e = gr.getNode("e");
        // assertTrue(mstContainsEdge(mst, d, e, 9.0),
           //     "MST deve contenere d-e (peso 9)");

        assertTrue(mstContainsEdge(mst, b, c, 8.0),
                "MST deve contenere b-c (peso 8)");
        assertTrue(mstContainsEdge(mst, d, e, 9.0),
                "MST deve contenere d-e (peso 9)");

        // Verifica che archi esclusi NON siano nell'MST
        assertFalse(mstContainsEdge(mst, b, h, 11.0),
                "MST non deve contenere b-h (peso 11, creerebbe ciclo)");
        assertFalse(mstContainsEdge(mst, d, f, 14.0),
                "MST non deve contenere d-f (peso 14, creerebbe ciclo)");
    }

    // =========================================================
    //  TEST grafo piccolo (4 nodi) — stesso di testFindMSP2 Prim
    //  MST atteso: a-b(1), b-d(2), b-c(3) — peso totale 6
    // =========================================================

    @Test
    final void testKruskal2() {
        Graph1<String> gr = new MatrixGraph<String>();
        gr.addNode("a"); gr.addNode("b");
        gr.addNode("c"); gr.addNode("d");
        gr.addWeightedEdge("a", "b", 1);
        gr.addWeightedEdge("a", "c", 5);
        gr.addWeightedEdge("b", "d", 2);
        gr.addWeightedEdge("b", "c", 3);
        gr.addWeightedEdge("c", "d", 4);

        KruskalMSP<String> alg = new KruskalMSP<String>();
        alg.computeMSP(gr);

        Set<GraphEdge<String>> mst = alg.getMstEdges();
        assertNotNull(mst);
        assertEquals(3, mst.size());

        double totalWeight = 0;
        for (GraphEdge<String> e : mst)
            totalWeight += e.getWeight();
        assertEquals(6.0, totalWeight, 0.001);

        GraphNode<String> a = gr.getNode("a");
        GraphNode<String> b = gr.getNode("b");
        GraphNode<String> c = gr.getNode("c");
        GraphNode<String> d = gr.getNode("d");

        assertTrue(mstContainsEdge(mst, a, b, 1.0), "MST deve contenere a-b(1)");
        assertTrue(mstContainsEdge(mst, b, d, 2.0), "MST deve contenere b-d(2)");
        assertTrue(mstContainsEdge(mst, b, c, 3.0), "MST deve contenere b-c(3)");
        assertFalse(mstContainsEdge(mst, a, c, 5.0), "MST non deve contenere a-c(5)");
        assertFalse(mstContainsEdge(mst, c, d, 4.0), "MST non deve contenere c-d(4)");
    }

    // =========================================================
    //  TEST grafo con archi di peso uguale
    //  (Kruskal può scegliere tra più MST validi)
    // =========================================================

    @Test
    final void testKruskalEqualWeights() {
        Graph1<String> gr = new MatrixGraph<String>();
        gr.addNode("a"); gr.addNode("b");
        gr.addNode("c"); gr.addNode("d");
        gr.addWeightedEdge("a", "b", 1);
        gr.addWeightedEdge("b", "c", 1);
        gr.addWeightedEdge("c", "d", 1);
        gr.addWeightedEdge("a", "d", 1); // creerebbe ciclo

        KruskalMSP<String> alg = new KruskalMSP<String>();
        alg.computeMSP(gr);

        Set<GraphEdge<String>> mst = alg.getMstEdges();
        assertNotNull(mst);
        // MST di 4 nodi = 3 archi
        assertEquals(3, mst.size());
        // Peso totale deve essere 3 (3 archi da peso 1 ciascuno)
        double totalWeight = 0;
        for (GraphEdge<String> e : mst)
            totalWeight += e.getWeight();
        assertEquals(3.0, totalWeight, 0.001);
    }

    // =========================================================
    //  TEST grafo triangolo (3 nodi, 3 archi)
    // =========================================================

    @Test
    final void testKruskalTriangle() {
        Graph1<String> gr = new MatrixGraph<String>();
        gr.addNode("x"); gr.addNode("y"); gr.addNode("z");
        gr.addWeightedEdge("x", "y", 10);
        gr.addWeightedEdge("y", "z", 3);
        gr.addWeightedEdge("x", "z", 7);

        KruskalMSP<String> alg = new KruskalMSP<String>();
        alg.computeMSP(gr);

        Set<GraphEdge<String>> mst = alg.getMstEdges();
        assertNotNull(mst);
        assertEquals(2, mst.size());

        double totalWeight = 0;
        for (GraphEdge<String> e : mst)
            totalWeight += e.getWeight();
        // MST atteso: y-z(3) + x-z(7) = 10
        assertEquals(10.0, totalWeight, 0.001);

        GraphNode<String> x = gr.getNode("x");
        GraphNode<String> y = gr.getNode("y");
        GraphNode<String> z = gr.getNode("z");

        assertTrue(mstContainsEdge(mst, y, z, 3.0), "MST deve contenere y-z(3)");
        assertTrue(mstContainsEdge(mst, x, z, 7.0), "MST deve contenere x-z(7)");
        assertFalse(mstContainsEdge(mst, x, y, 10.0), "MST non deve contenere x-y(10)");
    }

    // =========================================================
    //  TEST chiamate successive: computeMSP sovrascrive il risultato
    // =========================================================

    @Test
    final void testComputeOverwrite() {
        Graph1<String> gr = new MatrixGraph<String>();
        gr.addNode("a"); gr.addNode("b");
        gr.addWeightedEdge("a", "b", 5);

        KruskalMSP<String> alg = new KruskalMSP<String>();
        alg.computeMSP(gr);
        Set<GraphEdge<String>> first = alg.getMstEdges();
        assertEquals(1, first.size());

        // Seconda chiamata con grafo diverso
        Graph1<String> gr2 = new MatrixGraph<String>();
        gr2.addNode("x"); gr2.addNode("y"); gr2.addNode("z");
        gr2.addWeightedEdge("x", "y", 2);
        gr2.addWeightedEdge("y", "z", 3);
        alg.computeMSP(gr2);
        Set<GraphEdge<String>> second = alg.getMstEdges();
        assertEquals(2, second.size());
        // Il primo risultato non deve interferire col secondo
        assertNotSame(first, second);
    }

    // =========================================================
    //  METODO HELPER
    // =========================================================

    /**
     * Verifica se l'MST contiene un arco tra i nodi u e v con il peso dato.
     * Poiché il grafo è non orientato, controlla entrambe le direzioni.
     */
    private boolean mstContainsEdge(Set<GraphEdge<String>> mst,
                                    GraphNode<String> u,
                                    GraphNode<String> v,
                                    double weight) {
        for (GraphEdge<String> e : mst) {
            if (e.getWeight() == weight) {
                if ((e.getNode1().equals(u) && e.getNode2().equals(v)) ||
                    (e.getNode1().equals(v) && e.getNode2().equals(u))) {
                    return true;
                }
            }
        }
        return false;
    }
}
