package it.unicam.cs.asdl2526.es2;

/**
 * Uno scassinatore è un oggetto che prende una certa cassaforte e trova la
 * combinazione utilizzando la "forza bruta".
 * 
 * @author Luca Tesei
 *
 */
public class Burglar {

    // TODO inserire le variabili istanza che servono
    private final CombinationLock cassaforte;

    private int tentativi;

    /**
     * Costruisce uno scassinatore per una certa cassaforte.
     * 
     * @param aCombinationLock la cassaforte da scassinare
     * @throws NullPointerException se la cassaforte passata è nulla
     */
    public Burglar(CombinationLock aCombinationLock) {
        // TODO implementare
        if (aCombinationLock == null)
            throw new NullPointerException("La cassaforte passata non può essere null");
        this.cassaforte = aCombinationLock;
        tentativi = -1;
    }

    /**
     * Forza la cassaforte e restituisce la combinazione.
     * 
     * @return la combinazione della cassaforte forzata.
     */
    public String findCombination() {
        // TODO implementare
        this.cassaforte.lock();
        tentativi = 0;
        char c1, c2, c3;
        // 26^3 = 17576 possibilità
        // vengono ciclate - per le 3 posizioni nella combinazione di 3 caratteri - tutte le alternative in ordine lessicografico da A a Z con incremento di 1
        for (c1 = 'A'; c1 <= 'Z'; c1++)
            for (c2 = 'A'; c2 <= 'Z'; c2++)
                for (c3 = 'A'; c3 <= 'Z'; c3++) {
                    // incremento il numero di tentativi
                    tentativi++;
                    cassaforte.setPosition(c1);
                    cassaforte.setPosition(c2);
                    cassaforte.setPosition(c3);
                    // provo ad aprire con le 3 lettere del tentativo
                    cassaforte.open();
                    if (cassaforte.isOpen()) {
                        // se apro ritorno la combinazione corretta
                        // StringBuffer è un oggetto Stringa in cui vengono appese le 3 lettere - s.toString() restituisce questa stringa
                        StringBuffer s = new StringBuffer();
                        s.append(c1);
                        s.append(c2);
                        s.append(c3);
                        return s.toString();
                    }
                }
        return null;
        // return null;
    }

    /**
     * Restituisce il numero di tentativi che ci sono voluti per trovare la
     * combinazione. Se la cassaforte non è stata ancora forzata restituisce -1.
     * 
     * @return il numero di tentativi che ci sono voluti per trovare la
     *         combinazione, oppure -1 se la cassaforte non è stata ancora
     *         forzata.
     */
    public long getAttempts() {
        // TODO implementare
        return tentativi;
        // return -1;
    }
}
