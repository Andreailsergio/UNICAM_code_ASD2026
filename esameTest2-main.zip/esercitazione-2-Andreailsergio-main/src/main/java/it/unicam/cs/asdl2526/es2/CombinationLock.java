package it.unicam.cs.asdl2526.es2;

/**
 * Un oggetto cassaforte con combinazione ha una manopola che può essere
 * impostata su certe posizioni contrassegnate da lettere maiuscole. La
 * serratura si apre solo se le ultime tre lettere impostate sono uguali alla
 * combinazione segreta.
 * 
 * @author Luca Tesei
 */
public class CombinationLock {

    // TODO inserire le variabili istanza che servono
    private String combinazioneAttuale;

    private boolean chiusa;

    private char letteraPos1; // terz'ultima

    private char letteraPos2; // penultima

    private char letteraPos3; // ultima

    // private String combinazioneTentata;

    /**
     * Costruisce una cassaforte <b>aperta</b> con una data combinazione
     * 
     * @param aCombination
     *                         la combinazione che deve essere una stringa di 3
     *                         lettere maiuscole dell'alfabeto inglese es. AAA
     * @throws IllegalArgumentException se la combinazione fornita non è una
     *        stringa di 3 lettere maiuscole dell'alfabeto inglese
     * @throws NullPointerException se la combinazione fornita è nulla
     */
    public CombinationLock(String aCombination) {
        // TODO implementare
        if (aCombination.length() != 3)
            throw new IllegalArgumentException("Lunghezza della combinazione non valida (3 caratteri con lettere maiuscole)");
        if (!Character.isLetter(aCombination.charAt(0)) || !Character.isUpperCase(aCombination.charAt(0)))
            throw new IllegalArgumentException("Primo carattere della combinazione minuscolo o non lettera");
        if (!Character.isLetter(aCombination.charAt(1)) || !Character.isUpperCase(aCombination.charAt(1)))
            throw new IllegalArgumentException("Secondo carattere della combinazione minuscolo o non lettera");
        if (!Character.isLetter(aCombination.charAt(2)) || !Character.isUpperCase(aCombination.charAt(2)))
            throw new IllegalArgumentException("Terzo carattere della combinazione minuscolo o non lettera");
        // espressione regolare "[A-Z]+": tutte le lettere dalla A alla Z
        if (!aCombination.matches("[A-Z]+"))
            throw new IllegalArgumentException("I caratteri utilizzati non sono compatibili con lettere maiuscole dell'alfabeto inglese");
        if (aCombination == null)
            throw new NullPointerException("Combinazione nulla");
        // this.letteraPos3=aCombination.charAt(0);
        // this.letteraPos2=aCombination.charAt(1);
        // this.letteraPos1=aCombination.charAt(2);
        this.combinazioneAttuale=aCombination;
        this.chiusa=false;
    }

    /**
     * Imposta la manopola su una certa posizione.
     * 
     * @param aPosition
     *                      un carattere lettera maiuscola su cui viene
     *                      impostata la manopola
     * @throws IllegalArgumentException
     *                                      se il carattere fornito non è una
     *                                      lettera maiuscola dell'alfabeto
     *                                      inglese
     */
    public void setPosition(char aPosition) {
        // TODO implementare
        // if (aPosition>='A' && aPosition<='Z')
        if (!(Character.isLetter(aPosition) && Character.isUpperCase(aPosition)))
            throw new IllegalArgumentException("Posizionamento non consentito per carattere: "+aPosition);
        // Scorrimento posizioni (l'ultima inserita scalza l'ultima lettera della combinazione - le altre due scorrono)
        this.letteraPos1=this.letteraPos2;
        this.letteraPos2=this.letteraPos3;
        this.letteraPos3=aPosition;
    }

    /**
     * Tenta di aprire la serratura considerando come combinazione fornita le
     * ultime tre posizioni impostate. Se l'apertura non va a buon fine le
     * lettere impostate precedentemente non devono essere considerate per i
     * prossimi tentativi di apertura.
     */
    public void open() {
        // TODO implementare
        // se il tentativo con quelle stesse lettere è già stato fatto non riprovo ad aprire
        // if (String.valueOf(this.letteraPos1 + this.letteraPos2 + this.letteraPos3).equals(this.combinazioneTentata)==0) return;
        // se l'apertura va a buon fine
        if (this.combinazioneAttuale
                .charAt(0) == this.letteraPos1
                && this.combinazioneAttuale
                .charAt(1) == this.letteraPos2
                && this.combinazioneAttuale
                .charAt(2) == this.letteraPos3)
            this.chiusa = false;
        else
        // metto da parte la combinazione tentata ma sbagliata
        // resetto la combinazioneAttuale impostata fino ad ora
        {
            // this.combinazioneTentata = String.valueOf(this.letteraPos3 + this.letteraPos2 + this.letteraPos1);
            // this.letteraPos1 = 0;
            // this.letteraPos2 = 0;
            this.letteraPos3 = 0;
        }

    }

    /**
     * Determina se la cassaforte è aperta.
     * 
     * @return true se la cassaforte è attualmente aperta, false altrimenti
     */
    public boolean isOpen() {
        // TODO implementare
        if (this.chiusa)
            return false;
        else
            return true;
    }

    /**
     * Chiude la cassaforte senza modificare la combinazione attuale. Fa in modo
     * che se si prova a riaprire subito senza impostare nessuna nuova posizione
     * della manopola la cassaforte non si apre. Si noti che se la cassaforte
     * era stata aperta con la combinazione giusta le ultime posizioni impostate
     * sono proprio la combinazione attuale.
     */
    public void lock() {
        // TODO implementare
        this.chiusa = true;
        // evito la riapertura se si tenta automaticamente con la combinazione in memoria (resettandola)
        // this.letteraPos1 = 0;
        // this.letteraPos2 = 0;
        this.letteraPos3 = 0;
    }

    /**
     * Chiude la cassaforte e modifica la combinazione. Funziona solo se la
     * cassaforte è attualmente aperta. Se la cassaforte è attualmente chiusa
     * rimane chiusa e la combinazione non viene cambiata, ma in questo caso le
     * le lettere impostate precedentemente non devono essere considerate per i
     * prossimi tentativi di apertura.
     * 
     * @param aCombination
     *                         la nuova combinazione che deve essere una stringa
     *                         di 3 lettere maiuscole dell'alfabeto inglese
     * @throws IllegalArgumentException se la combinazione fornita non è una
     *        stringa di 3 lettere maiuscole dell'alfabeto inglese
     * @throws NullPointerException se la combinazione fornita è nulla
     */
    public void lockAndChangeCombination(String aCombination) {
        // TODO implementare
        if (aCombination.length() != 3)
            throw new IllegalArgumentException("Lunghezza della combinazione non valida (3 caratteri con lettere maiuscole)");
        if (!Character.isLetter(aCombination.charAt(0)) || !Character.isUpperCase(aCombination.charAt(0)))
            throw new IllegalArgumentException("Primo carattere della combinazione minuscolo o non lettera");
        if (!Character.isLetter(aCombination.charAt(1)) || !Character.isUpperCase(aCombination.charAt(1)))
            throw new IllegalArgumentException("Secondo carattere della combinazione minuscolo o non lettera");
        if (!Character.isLetter(aCombination.charAt(2)) || !Character.isUpperCase(aCombination.charAt(2)))
            throw new IllegalArgumentException("Terzo carattere della combinazione minuscolo o non lettera");
        if (aCombination == null)
            throw new NullPointerException("Combinazione nulla");

        if (this.isOpen()) {
            combinazioneAttuale = aCombination;
            this.chiusa = true;
            // this.letteraPos1 = 0;
            // this.letteraPos2 = 0;
            this.letteraPos3 = 0;
        }
        else
        // metto da parte la combinazione tentata ma sbagliata
        // resetto la combinazioneAttuale impostata fino ad ora
        {
            // this.combinazioneTentata = String.valueOf(this.letteraPos3 + this.letteraPos2 + this.letteraPos1);
            // this.letteraPos1 = 0;
            // this.letteraPos2 = 0;
            this.letteraPos3 = 0;
        }
    }
}