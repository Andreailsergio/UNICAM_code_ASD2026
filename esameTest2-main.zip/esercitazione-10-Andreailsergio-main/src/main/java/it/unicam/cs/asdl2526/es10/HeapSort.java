/**
 * 
 */
package it.unicam.cs.asdl2526.es10;

import java.util.List;

// TODO completare import 

/**
 * Classe che implementa un algoritmo di ordinamento basato su heap.
 * 
 * @author Template: Luca Tesei, Implementation: collettiva
 *
 */
public class HeapSort<E extends Comparable<E>> implements SortingAlgorithm<E> {

    // finestra dell'heap logico sull'array
    private int heapSize;
    // contatore dei confronti
    private int numCompare;

    @Override
    public SortingAlgorithmResult<E> sort(List<E> l) {
        // TODO implementare - Nota: usare una variante dei metodi della classe
        // MaxHeap in modo da implementare l'algoritmo utilizzando solo un array
        // (arraylist) e alcune variabili locali di appoggio (implementazione
        // cosiddetta "in loco" o "in place", si veda
        // https://it.wikipedia.org/wiki/Algoritmo_in_loco)

        // usa una variante dei metodi della classe
        // MaxHeap in modo da implementare l'algoritmo utilizzando solo un array
        // (arraylist) e alcune variabili locali di appoggio (implementazione
        // cosiddetta "in loco" o "in place", si veda
        // https://it.wikipedia.org/wiki/Algoritmo_in_loco)
        if (l == null)
            throw new NullPointerException(
                    "Tentativo di ordinare una lista null");
        if (l.size() <= 1)
            // per ordinare la lista vuota o con un solo elemento non faccio niente
            return new SortingAlgorithmResult<E>(l, 0);
        // inizializzo heapSize
        this.heapSize = l.size();
        // inizializzo numCompare
        this.numCompare = 0;
        // FASE 1 - BUILD-HEAP BOTTOM-UP (tecnica x trasformare qualsiasi array non ordinato in un heap valido partendo dal basso)
        // il CICLO parte dal primo nodo che ha almeno un figlio - che si trova in posizione (l.size() / 2) - 1 dove / è la divisione intera
        // (tutti gli indici successivi sono foglie)
        // e procede per indici decrescenti fino alla radice (0)
        for (int i = (l.size() / 2) - 1; i >= 0; i--) {
            heapify(l, i); // heapify fa riferimento alla lunghezza heapSize, non alla lunghezza effettiva di l
        }
        // Ora l è uno heap (la radice è il massimo e ogni genitore è >= dei suoi figli)
        // FASE 2 - ESTRAZIONE DEL MASSIMO
        for (int i = l.size() - 1; i > 0; i--) {
            // il max è sempre in testa a l
            // scambio la testa con l'elemento i
            E app = l.get(i);
            l.set(i, l.get(0));
            l.set(0, app);
            // decremento la heapSize (ad ogni iterazione il massimo attuale va in fondo ed esce dal radar dello heap logico)
            this.heapSize--;
            // chiamo heapify per ripristinare la proprietà heap sulla radice
            heapify(l, 0);

            // INVARIANTE: dopo k iterazioni le ultime k posizioni contengono i k elementi più grandi in ordine crescente
            // mentre la parte [0, n-k-1] è un heap valido
        }
        // ora l è ordinata
        return new SortingAlgorithmResult<E>(l, this.numCompare);
    }

    // analoga a procedura MaxHeap ma lavora su List anziché su ArrayList, usa this.heapSize invece di heap.size()
    // usa this.numCompare++ per contare i confronti
    // [serve non all'algoritmo in sé, ma a scopo didattico e di analisi sperimentale, per misurare empiricamente la complessità computazionale]
    private void heapify(List<E> l, int i) {
        // caso base: se non c'è figlio sinistro non c'è nemmeno il destro
        if (!hasLeft(i))
            return;
        int max = i;
        // cerco il largest tra padre e figli
        if (l.get(max).compareTo(l.get(leftIndex(i))) < 0)
            max = leftIndex(i);
        this.numCompare++;
        if (hasRight(i)) {
            this.numCompare++;
            if (l.get(max).compareTo(l.get(rightIndex(i))) < 0) {
                max = rightIndex(i);
            }
        }
        if (max == i)
            return; // ho finito (il nodo è già a posto, senza scambi)
        // del nodo figlio uguale a max
        // altrimenti scambio i con max (appoggio = i / i = max / max = appoggio)
        E app = l.get(i);
        l.set(i, l.get(max));
        l.set(max, app);
        // richiamo la funzione ricorsivamente sull'indice del nodo figlio uguale a max (che è quello con il valore spostato)
        heapify(l, max);

        // return null;
    }

    @Override
    public String getName() {
        return "HeapSort";
    }


    // ALTRI METODI PRIVATE DI UTILITA' INTERNA PER LA CLASSE

    /*
     * Funzione di comodo per calcolare l'indice del figlio sinistro del nodo in
     * posizione i. Si noti che la posizione 0 è significativa e contiene sempre
     * la radice dello heap.
     */
    private int leftIndex(int i) {
        return 2 * i + 1;
    }

    /*
     * Funzione di comodo per calcolare l'indice del figlio destro del nodo in
     * posizione i. Si noti che la posizione 0 è significativa e contiene sempre
     * la radice dello heap.
     */
    private int rightIndex(int i) {
        return 2 * i + 2;
    }

    // Dato il nodo con indice i, ha un figlio destro?
    private boolean hasRight(int i) {
        // rightIndex(i) calcola l'indice teorico in cui dovrebbe trovarsi il figlio dx
        // e controlla che rientri nei limiti effettivi dell'array logico attuale per evitare un CRASH
        // CRASH: un errore IndexOutOfBoundsException a RunTime
        return rightIndex(i) < this.heapSize;
    }

    // Dato il nodo con indice i, ha un figlio sinistro?
    private boolean hasLeft(int i) {
        // leftIndex(i) calcola l'indice teorico in cui dovrebbe trovarsi il figlio sx
        // ma controlla che quel figlio non cada fuori dal range: che esista davvero nell'array, il nodo non sia una foglia, etc.
        // se provassi a fare in heapify heap.get(leftIndex(i)) senza prima controllare hasLeft
        return leftIndex(i) < this.heapSize;
    }

}
