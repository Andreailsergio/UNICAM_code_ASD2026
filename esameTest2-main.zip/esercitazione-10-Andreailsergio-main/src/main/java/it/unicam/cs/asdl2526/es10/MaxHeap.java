package it.unicam.cs.asdl2526.es10;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Classe che implementa uno heap binario che può contenere elementi non nulli
 * possibilmente ripetuti.
 * 
 * @author Template: Luca Tesei, Implementation: collettiva
 *
 * @param <E>
 *                il tipo degli elementi dello heap, che devono avere un
 *                ordinamento naturale.
 */
public class MaxHeap<E extends Comparable<E>> {

    /*
     * L'array che serve come base per lo heap
     */
    private ArrayList<E> heap;

    /**
     * Costruisce uno heap vuoto.
     */
    public MaxHeap() {
        this.heap = new ArrayList<E>();
    }

    /**
     * Restituisce il numero di elementi nello heap.
     * 
     * @return il numero di elementi nello heap
     */
    public int size() {
        return this.heap.size();
    }

    /**
     * Determina se lo heap è vuoto.
     * 
     * @return true se lo heap è vuoto.
     */
    public boolean isEmpty() {
        return this.heap.isEmpty();
    }

    /**
     * Costruisce uno heap a partire da una lista di elementi.
     * 
     * @param list
     *                 lista di elementi
     * @throws NullPointerException
     *                                  se la lista è nulla
     */
    public MaxHeap(List<E> list) {
        // TODO implementare
        if (list == null)
            throw new NullPointerException(
                    "Creazione di uno heap da una lista nulla");
        this.heap = new ArrayList<E>();
        for (E el : list)
            this.insert(el);
    }

    /**
     * Inserisce un elemento nello heap
     * 
     * @param el
     *               l'elemento da inserire
     * @throws NullPointerException
     *                                  se l'elemento è null
     * 
     */
    public void insert(E el) {
        // TODO implementare
        if (el == null)
            throw new NullPointerException(
                    "Tentativo di inserire un elemento null");
        if (this.heap.isEmpty())
            // inserisco nella posizione 0
            this.heap.add(el);
        else {
            // inserisco nella prima posizione libera e riadatto
            this.heap.add(el);
            moveUp(this.heap.size() - 1);
        }
    }

    private void moveUp(int indice) {
        // ciclo di scambio col padre
        // fino a quando la proprietà dello heap non è soddisfatta [finché elemento corrente è > del parent]
        // o fino a quando non arrivo alla radice
        while (indice > 0 && this.heap.get(parentIndex(indice))
                .compareTo(this.heap.get(indice)) < 0) {
            // scambio SWAP
            // valore corrente nell'oggetto di appoggio
            E appoggio = this.heap.get(indice);
            // valore del padre nell'elemento corrente
            this.heap.set(indice, this.heap.get(parentIndex(indice)));
            // valore dell'oggetto di appoggio (ex corrente) nel padre
            this.heap.set(parentIndex(indice), appoggio);
            // vado avanti salendo verso la radice
            indice = parentIndex(indice);
        }
    }

    /*
     * Funzione di comodo per calcolare l'indice del figlio sinistro del nodo in
     * posizione i. Si noti che la posizione 0 è significativa e contiene sempre
     * la radice dello heap.
     */
    private int leftIndex(int i) {
        // TODO implementare
        return 2 * i + 1;
        // return -1;
    }

    /*
     * Funzione di comodo per calcolare l'indice del figlio destro del nodo in
     * posizione i. Si noti che la posizione 0 è significativa e contiene sempre
     * la radice dello heap.
     */
    private int rightIndex(int i) {
        // TODO implementare
        return 2 * i + 2;
        // return -1;
    }

    /*
     * Funzione di comodo per calcolare l'indice del genitore del nodo in
     * posizione i. Si noti che la posizione 0 è significativa e contiene sempre
     * la radice dello heap.
     */
    private int parentIndex(int i) {
        // TODO implementare
        // sfruttiamo il fatto che la divisione intera ha sempre come risultato
        // la parte intera della divisione floating point
        return (i - 1) / 2;
        // return -1;
    }

    /**
     * Ritorna l'elemento massimo senza toglierlo.
     * 
     * @return l'elemento massimo dello heap oppure null se lo heap è vuoto
     */
    public E getMax() {
        // TODO implementare
        if (this.isEmpty())
            return null;
        return this.heap.get(0);
        // return null;
    }

    /**
     * Estrae l'elemento massimo dallo heap (ovvero la radice con indice 0). Dopo la chiamata tale elemento non
     * è più presente nello heap.
     * 
     * @return l'elemento massimo di questo heap oppure null se lo heap è vuoto
     */
    public E extractMax() {
        // TODO implementare
        if (this.isEmpty())
            return null;
        // salvo il valore da restituire (uso il metodo standard di ArrayList<E>)
        E ret = this.heap.get(0);
        // nel caso particolare ci sia un solo elemento evito di fare il riadattamento - estraggo il massimo e svuoto la lista
        if (this.heap.size() == 1)
            this.heap.clear();
        // se c'è più di un elemento
        else {
            // copio l'ultima foglia nella radice, e contemporaneamente riduco di 1 la lunghezza
            this.heap.set(0, this.heap.get(this.heap.size() - 1));
            // rimuovo l'elemento duplicato
            this.heap.remove(this.heap.size() - 1);
            // faccio il riadattamento (l'elemento spostato può far violare la proprietà del Max-Heap se è più piccolo di uno dei figli)
            this.heapify(0);
        }
        return ret;
        // return null;
    }

    /*
     * Ricostituisce uno heap a partire dal nodo in posizione i assumendo che i
     * suoi sottoalberi sinistro e destro (se esistono) siano heap validi.
     * È il pattern standard del sift-down: complessità O(log n) perché ad ogni chiamata ricorsiva si scende di un livello nell'albero,
     * e l'altezza di uno heap con n elementi è log₂(n).
     */
    private void heapify(int i) {
        // TODO implementare
        // caso base: se non c'è figlio sinistro non c'è nemmeno il destro
        if (!hasLeft(i))
            return;
        int max = i;
        // cerco l'indice dell'elemento con valore massimo (largest) tra nodo, figlio sx e figlio dx
        if (this.heap.get(max).compareTo(this.heap.get(leftIndex(i))) < 0)
            max = leftIndex(i);
        if (hasRight(i) && this.heap.get(max) // solo se figlio dx esiste controllo se il max aggiornato è < di quanto c'è nel figlio dx
                .compareTo(this.heap.get(rightIndex(i))) < 0)
            max = rightIndex(i);
        if (max == i)
            return; // ho finito (il nodo era già a posto)
        // altrimenti scambio i con max (appoggio = i / i = max / max = appoggio)
        E app = this.heap.get(i);
        this.heap.set(i, this.heap.get(max));
        this.heap.set(max, app);
        // richiamo la funzione ricorsivamente sull'indice del nodo figlio uguale a max (che è quello con il valore spostato)
        heapify(max);
    }

    private boolean hasRight(int i) {
        return rightIndex(i) < this.heap.size();
    }

    private boolean hasLeft(int i) {
        return leftIndex(i) < this.heap.size();
    }

    /**
     * Only for JUnit testing purposes.
     * 
     * @return the arraylist representing this max heap
     */
    protected ArrayList<E> getHeap() {
        return this.heap;
    }
}
