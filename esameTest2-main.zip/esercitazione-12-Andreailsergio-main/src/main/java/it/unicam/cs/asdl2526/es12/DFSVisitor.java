package it.unicam.cs.asdl2526.es12;

// aggiunti per hook visitNode (Template Method) grazie a polimorfismo
import java.util.ArrayList;
import java.util.List;

/**
 * Classe singoletto che fornisce lo schema generico di visita Depth-First di
 * un grafo rappresentato da un oggetto di tipo Graph<L>.
 * 
 * @author Template: Luca Tesei, Implementazione: collettiva
 *
 * @param <L> le etichette dei nodi del grafo
 */
public class DFSVisitor<L> {

    // Variabile "globale" per far andare avanti il tempo durante la DFS e
    // assegnare i relativi tempi di scoperta e di uscita dei nodi
    // E' protected per permettere il test JUnit
    protected int time;

    /**
     * Esegue la visita in profondità di un certo grafo. Setta i valori seguenti
     * valori associati ai nodi: tempo di scoperta, tempo di fine visita,
     * predecessore. Ogni volta che un nodo viene visitato viene eseguito il
     * metodo visitNode sul nodo. In questa classe il metodo non fa niente,
     * basta creare una sottoclasse e ridefinire il metodo per eseguire azioni
     * particolari.
     * 
     * @param g
     *              il grafo da visitare.
     * @throws NullPointerException
     *                                  se il grafo passato è null
     */
    public void DFSVisit(Graph<L> g) {
        // TODO implementare
        // NOTA: inizializza il grafo e chiama la recDFS sui nodi in un ordine
        // qualsiasi per calcolare la "foresta" DFS
        if (g == null)
            throw new NullPointerException("DFS ERROR: Grafo nullo");
        // inizializziamo i nodi del grafo
        for (GraphNode<L> n : g.getNodes()) {
            n.setColor(GraphNode.COLOR_WHITE);
            n.setPrevious(null);
            n.setEnteringTime(-1);
            n.setExitingTime(-1);
        }
        // inizializziamo il tempo globale
        this.time = 0;
        // ciclo esterno
        for (GraphNode<L> n : g.getNodes()) {
            if (n.getColor() == GraphNode.COLOR_WHITE)
                // chiamo la DFS ricorsiva su n
                recDFS(g, n);
        }
        // Fine della visita DFS "esterna"

    }

    /*
     * Esegue la DFS ricorsivamente sul nodo passato.
     * 
     * @param g il grafo
     * 
     * @param u il nodo su cui parte la DFS
     */
    protected void recDFS(Graph<L> g, GraphNode<L> u) {
        // TODO implementare ricorsivamente
        // NOTA: chiamare il metodo visitNode alla "scoperta" di un nuovo nodo
        // Scopro il nodo u
        u.setColor(GraphNode.COLOR_GREY);
        // Incremento il tempo globale
        this.time++;
        // Assegno ad n il tempo di scoperta
        u.setEnteringTime(this.time);
        for (GraphNode<L> v : g.getAdjacentNodesOf(u)) {
            if (v.getColor() == GraphNode.COLOR_WHITE) {
                // assegno il puntatore per l'albero di copertura
                v.setPrevious(u);
                // vado in profondità
                recDFS(g, v);
            }
        }
        // tutti i nodi adiacenti a u sono diventati neri
        // u diventa nero e assegno a u il tempo di uscita
        u.setColor(GraphNode.COLOR_BLACK);
        this.time++;
        u.setExitingTime(this.time);
        visitNode(u);
    }

    /**
     * Questo metodo, che di default non fa niente, viene chiamato su tutti i
     * nodi visitati durante la DFS nel momento in cui il colore passa da grigio
     * a nero. Ridefinire il metodo in una sottoclasse per effettuare azioni
     * specifiche.
     * 
     * @param n
     *              il nodo visitato
     */
    public void visitNode(GraphNode<L> n) {
        /*
         * In questa classe questo metodo non fa niente. Esso può essere
         * ridefinito in una sottoclasse per fare azioni particolari.
         */
    }


// =============================================================================
// Esempio 1 — stampa i nodi nell'ordine di chiusura (exitingTime crescente)
//             con i loro tempi di scoperta e chiusura
// =============================================================================

    /**
     * Sottoclasse di DFSVisitor che stampa ogni nodo quando viene chiuso,
     * mostrando i suoi tempi di ingresso e uscita.
     */
    class DFSStampaTempi<L> extends DFSVisitor<L> {

        @Override
        public void visitNode(GraphNode<L> n) {
            // visitNode viene chiamato quando il nodo diventa NERO (si chiude)
            // a questo punto enteringTime e exitingTime sono già stati assegnati
            System.out.println("Chiuso: " + n.getLabel()
                    + "  d=" + n.getEnteringTime()
                    + "  f=" + n.getExitingTime());
        }
    }

// Uso:
//   DFSStampaTempi<String> dfs = new DFSStampaTempi<String>();
//   dfs.DFSVisit(g);
//
// Output esempio su grafo {u,v,w,x,y,z}:
//   Chiuso: x  d=4  f=5
//   Chiuso: v  d=3  f=6
//   Chiuso: y  d=8  f=9
//   Chiuso: w  d=7  f=10
//   Chiuso: z  d=11 f=12
//   Chiuso: u  d=1  f=2   ← notare: u chiude PRIMA di tutti nel suo albero


// =============================================================================
// Esempio 2 — raccoglie i nodi in ordine topologico inverso
//             (ordine di chiusura = ordine topologico rovesciato)
// =============================================================================

    /**
     * Sottoclasse di DFSVisitor che raccoglie i nodi nell'ordine in cui
     * vengono chiusi. Invertendo questa lista si ottiene l'ordinamento
     * topologico del grafo (se è un DAG).
     *
     * Nota: ogni chiamata a DFSVisit ACCUMULA i nodi nella lista.
     * Chiamare reset() prima di una nuova visita se si vuole ripartire da zero.
     */
    class DFSCollector<L> extends DFSVisitor<L> {

        // lista che accumula i nodi nell'ordine di chiusura
        private final List<GraphNode<L>> chiusi;

        public DFSCollector() {
            this.chiusi = new ArrayList<GraphNode<L>>();
        }

        @Override
        public void visitNode(GraphNode<L> n) {
            chiusi.add(n);   // aggiunge il nodo quando viene chiuso (diventa nero)
        }

        /**
         * Restituisce i nodi nell'ordine di chiusura (exitingTime crescente).
         * Copia difensiva: l'esterno non può modificare la lista interna.
         */
        public List<GraphNode<L>> getChiusi() {
            return new ArrayList<GraphNode<L>>(chiusi);
        }

        /**
         * Inverte la lista dei chiusi e la restituisce.
         * Se il grafo è un DAG, questa è una lista in ordine topologico.
         */
        public List<GraphNode<L>> getOrdineTopologico() {
            List<GraphNode<L>> topologico = new ArrayList<GraphNode<L>>(chiusi);
            // Collections.reverse inverte la lista in-place
            java.util.Collections.reverse(topologico);
            return topologico;
        }

        /** Resetta la lista per riusare lo stesso oggetto su grafi diversi. */
        public void reset() {
            chiusi.clear();
        }
    }

// Uso:
//   DFSCollector<String> dfs = new DFSCollector<String>();
//   dfs.DFSVisit(g);
//   List<GraphNode<String>> topologico = dfs.getOrdineTopologico();


// =============================================================================
// Esempio 3 — classifica gli archi del grafo durante la DFS
//             (tree, back, forward, cross)
// =============================================================================

    /**
     * Sottoclasse di DFSVisitor che, al momento della chiusura di ogni nodo u,
     * classifica tutti gli archi uscenti da u in base ai colori e ai tempi
     * dei nodi collegati.
     *
     * Classificazione (per grafi orientati):
     *   TREE/FORWARD : v è nero e d[u] < d[v]  → u scoperto prima di v
     *   BACK         : v è grigio               → v è antenato di u nello stack
     *   CROSS        : v è nero e d[u] > d[v]  → u scoperto dopo v
     *
     * Per grafi NON orientati esistono solo archi TREE e BACK.
     */
    class DFSEdgeClassifier<L> extends DFSVisitor<L> {

        private Graph<L> graph;   // serve per accedere agli archi uscenti da u

        /**
         * Bisogna passare il grafo al costruttore perché visitNode
         * riceve solo il nodo, non il grafo.
         */
        public DFSEdgeClassifier(Graph<L> graph) {
            if (graph == null)
                throw new NullPointerException("Grafo null");
            this.graph = graph;
        }

        @Override
        public void visitNode(GraphNode<L> u) {
            // al momento della chiusura di u, esamino tutti i suoi archi uscenti
            for (GraphEdge<L> edge : graph.getEdgesOf(u)) {

                // in un grafo non orientato getEdgesOf restituisce tutti gli archi
                // connessi: devo trovare il nodo "dall'altra parte" dell'arco
                GraphNode<L> v;
                if (edge.getNode1().equals(u))
                    v = edge.getNode2();
                else
                    v = edge.getNode1();

                // classificazione in base al colore di v al momento della chiusura di u
                String tipo;
                if (v.getColor() == GraphNode.COLOR_GREY) {
                    // v è ancora grigio → u è discendente di v → arco all'indietro
                    tipo = "BACK";
                } else if (v.getColor() == GraphNode.COLOR_BLACK) {
                    if (u.getEnteringTime() < v.getEnteringTime())
                        // u scoperto prima di v → arco in avanti (solo in grafi orientati)
                        tipo = "FORWARD";
                    else
                        // u scoperto dopo v → arco trasversale
                        tipo = "CROSS";
                } else {
                    // v è bianco al momento della chiusura di u:
                    // non dovrebbe succedere (v sarebbe stato scoperto prima)
                    tipo = "TREE (già processato)";
                }

                System.out.println("  Arco " + u.getLabel()
                        + " → " + v.getLabel()
                        + "  tipo: " + tipo);
            }
        }
    }

// Uso:
//   Graph<String> g = new MapAdjacentListUndirectedGraph<String>();
//   // ... aggiunta nodi e archi ...
//   DFSEdgeClassifier<String> dfs = new DFSEdgeClassifier<String>(g);
//   dfs.DFSVisit(g);

}
