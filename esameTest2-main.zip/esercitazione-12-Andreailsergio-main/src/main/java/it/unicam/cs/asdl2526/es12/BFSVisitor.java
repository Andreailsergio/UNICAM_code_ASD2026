package it.unicam.cs.asdl2526.es12;

import java.util.LinkedList;
// aggiunti per hook visitNode (Template Method) grazie a polimorfismo
import java.util.ArrayList;
import java.util.List;

/**
 * Classe singoletto che fornisce lo schema generico di visita Breadth-First di
 * un grafo rappresentato da un oggetto di tipo Graph<L>.
 * 
 * @author Template: Luca Tesei, Implementazione: collettiva
 *
 * @param <L> le etichette dei nodi del grafo
 */
public class BFSVisitor<L> {

    /**
     * Esegue la visita in ampiezza di un certo grafo a partire da un nodo
     * sorgente. Setta i valori seguenti valori associati ai nodi: distanza
     * intera, predecessore. La distanza indica il numero minimo di archi che si
     * devono percorrere dal nodo sorgente per raggiungere il nodo e il
     * predecessore rappresenta il padre del nodo in un albero di copertura del
     * grafo. Ogni volta che un nodo viene visitato viene eseguito il metodo
     * visitNode sul nodo. In questa classe il metodo non fa niente, basta
     * creare una sottoclasse e ridefinire il metodo per eseguire azioni
     * particolari.
     * 
     * @param g
     *                   il grafo da visitare.
     * @param source
     *                   il nodo sorgente.
     * @throws NullPointerException
     *                                      se almeno un valore passato è null
     * @throws IllegalArgumentException
     *                                      se il nodo sorgente non appartiene
     *                                      al grafo dato
     */
    public void BFSVisit(Graph<L> g, GraphNode<L> source) {
        // TODO implementare
        // NOTA: chiamare il metodo visitNode quando un nodo passa da grigio a nero
        if (g == null)
            throw new NullPointerException("BFS ERROR: Grafo nullo");
        if (source == null)
            throw new NullPointerException("BFS ERROR: Sorgente nulla");
        if (!g.getNodes().contains(source))
            throw new IllegalArgumentException(
                    "BFS ERROR: La sorgente non è un nodo del grafo");

        // Inizializziamo il grafo
        for (GraphNode<L> n : g.getNodes()) {
            n.setColor(GraphNode.COLOR_WHITE);
            n.setIntegerDistance(-1);
            n.setPrevious(null);
        }
        // Scopro la sorgente
        source.setColor(GraphNode.COLOR_GREY);
        source.setIntegerDistance(0);
        source.setPrevious(null);
        // Come coda utilizzo una LinkedList: uso addLast per inserire in coda e
        // removeFirst per estrarre il primo elemento
        LinkedList<GraphNode<L>> queue = new LinkedList<GraphNode<L>>();
        // Inserisco in coda la sorgente
        queue.addLast(source);
        // Ciclo Principale
        while (!queue.isEmpty()) {
            GraphNode<L> nodoCorrente = queue.removeFirst();
            for (GraphNode<L> n : g.getAdjacentNodesOf(nodoCorrente)) {
                // Scopro tutti i nodi bianchi adiacenti al nodo corrente
                if (n.getColor() == GraphNode.COLOR_WHITE) {
                    // Faccio tutte le operazioni relative alla scoperta
                    n.setColor(GraphNode.COLOR_GREY);
                    n.setIntegerDistance(nodoCorrente.getIntegerDistance() + 1);
                    n.setPrevious(nodoCorrente);
                    queue.addLast(n);
                }
            }
            // Il nodo corrente diventa nero
            nodoCorrente.setColor(GraphNode.COLOR_BLACK);
            this.visitNode(nodoCorrente);
        }
        // la visita è finita
    }

    /**
     * Questo metodo, che di default non fa niente, viene chiamato su tutti i
     * nodi visitati durante la BFS quando i nodi passano da grigio a nero.
     * Ridefinire il metodo in una sottoclasse per effettuare azioni specifiche.
     * 
     * @param n
     *              il nodo visitato
     */
    public void visitNode(GraphNode<L> n) {
        /*
         * In questa classe questo metodo non fa niente. Esso può essere
         * ridefinito in una sottoclasse per fare azioni particolari.
         */
    }

    // SOTTOCLASSI DI BFSVisitor per azioni particolari:
    // 1. stampa i nodi nell'ordine in cui vengono visitati
    // ESEMPIO DI USO
    // Graph<String> g = new MapAdjacentListUndirectedGraph<String>();
    // ... aggiunta nodi e archi ...
    //
    // BFSStampaOrdine<String> bfs = new BFSStampaOrdine<String>();
    // bfs.BFSVisit(g, g.getNodeOf("s"));
    //
    //  output:
    //  Visitato: s (distanza dalla sorgente: 0 hop)
    //  Visitato: u (distanza dalla sorgente: 1 hop)
    //  Visitato: x (distanza dalla sorgente: 1 hop)
    //  Visitato: v (distanza dalla sorgente: 2 hop)
    //  ...
    class BFSStampaOrdine<L> extends BFSVisitor<L> {

        @Override
        public void visitNode(GraphNode<L> n) {
            System.out.println("Visitato: " + n.getLabel()
                    + " (distanza dalla sorgente: "
                    + n.getIntegerDistance() + " hop)");
        }
    }
    // 2. raccoglie i nodi visitati in una lista ordinata per distanza
    // ESEMPIO DI USO
    // BFSCollector<String> bfs = new BFSCollector<String>();
    // bfs.BFSVisit(g, g.getNodeOf("s"));
    //
    // List<GraphNode<String>> ordine = bfs.getVisitati(); //ordine contiene i nodi dal più vicino al più lontano dalla sorgente
    class BFSCollector<L> extends BFSVisitor<L> {

        // lista che accumula i nodi nell'ordine di visita
        private final List<GraphNode<L>> visitati;

        public BFSCollector() {
            this.visitati = new ArrayList<GraphNode<L>>();
        }

        @Override
        public void visitNode(GraphNode<L> n) {
            visitati.add(n);   // aggiunge il nodo alla lista ogni volta che diventa nero
        }

        /** Restituisce i nodi nell'ordine in cui sono stati visitati */
        public List<GraphNode<L>> getVisitati() {
            return new ArrayList<GraphNode<L>>(visitati);  // copia difensiva
        }

        /** Resetta la lista (per poter riusare lo stesso oggetto su grafi diversi) */
        public void reset() {
            visitati.clear();
        }
    }
    // 3. verifica se un nodo target è raggiungibile dalla sorgente
    // ESEMPIO DI USO
    // BFSReachability<String> bfs = new BFSReachability<String>("v");
    // bfs.BFSVisit(g, g.getNodeOf("s"));
    //
    // if (bfs.isRaggiungibile())
    //     System.out.println("v è raggiungibile da s");
    // else
    //     System.out.println("v NON è raggiungibile da s");
    class BFSReachability<L> extends BFSVisitor<L> {

        private final L targetLabel;   // etichetta del nodo che stiamo cercando
        private boolean trovato;

        public BFSReachability(L targetLabel) {
            if (targetLabel == null)
                throw new NullPointerException("Target label null");
            this.targetLabel = targetLabel;
            this.trovato = false;
        }

        @Override
        public void visitNode(GraphNode<L> n) {
            if (n.getLabel().equals(targetLabel))
                trovato = true;   // trovato! lo segna ma la BFS continua comunque
        }

        /** Da chiamare DOPO BFSVisit */
        public boolean isRaggiungibile() {
            return trovato;
        }

        public void reset() {
            trovato = false;
        }
    }

}
