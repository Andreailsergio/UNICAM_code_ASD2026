package it.unicam.cs.asdl2526.es12;

import java.util.ArrayList;

/**
 * Classe singoletto che implementa l'algoritmo di Prim per trovare un Minimum
 * Spanning Tree di un grafo non orientato, pesato e con pesi non negativi.
 * 
 * L'algoritmo richiede l'uso di una coda di min priorità tra i nodi che può
 * essere realizzata con una semplice ArrayList (non c'è bisogno di ottimizzare
 * le operazioni di inserimento, di estrazione del minimo, o di decremento della
 * priorità).
 * 
 * Si possono usare i colori dei nodi per registrare la scoperta e la visita
 * effettuata dei nodi.
 * 
 * @author Luca Tesei
 * 
 * @param <L>
 *                tipo delle etichette dei nodi del grafo
 *
 */
public class PrimMST<L> {

    /*
     * Coda di priorità che va usata dall'algoritmo. La variabile istanza è
     * protected solo per scopi di testing JUnit.
     */
    protected ArrayList<GraphNode<L>> queue;

    /**
     * Crea un nuovo algoritmo e inizializza la coda di priorità con una coda
     * vuota.
     */
    public PrimMST() {
        this.queue = new ArrayList<GraphNode<L>>();
    }

    /**
     * Utilizza l'algoritmo goloso di Prim per trovare un albero di copertura
     * minimo in un grafo non orientato e pesato, con pesi degli archi non
     * negativi. Dopo l'esecuzione del metodo nei nodi del grafo il campo
     * previous deve contenere un puntatore a un nodo in accordo all'albero di
     * copertura minimo calcolato, la cui radice è il nodo sorgente passato.
     * 
     * @param g
     *              un grafo non orientato, pesato, con pesi non negativi
     * @param s
     *              il nodo del grafo g sorgente, cioè da cui parte il calcolo
     *              dell'albero di copertura minimo. Tale nodo sarà la radice
     *              dell'albero di copertura trovato
     * 
     * @throw NullPointerException se il grafo g o il nodo sorgente s sono nulli
     * @throw IllegalArgumentException se il nodo sorgente s non esiste in g
     * @throw IllegalArgumentException se il grafo g è orientato, non pesato o
     *        con pesi negativi
     */
    public void computeMSP(Graph<L> g, GraphNode<L> s) {
        // TODO implementare
        if (g == null)
            throw new NullPointerException("Grafo nullo");
        if (s == null)
            throw new NullPointerException("Sorgente nulla");
        if (g.getNodeOf(s.getLabel()) == null)
            throw new IllegalArgumentException(
                    "Nodo sorgente non presente nel grafo");
        if (g.isDirected())
            throw new IllegalArgumentException(
                    "Il grafo passato è orientato, l'algoritmo opera su "
                            + "grafi non orientati");
        initGraph(g, s);
        // Inizializzo la coda
        this.queue.clear();
        // Inserisco tutti i nodi nella coda
        for (GraphNode<L> n : g.getNodes())
            this.queue.add(n);
        while (this.queue.size() != 0) {
            GraphNode<L> u = extractMinimum();
            // Cambio il colore del nodo estratto per indicare che non fa più
            // parte della coda
            u.setColor(GraphNode.COLOR_BLACK);
            for (GraphEdge<L> e : g.getEdgesOf(u)) {
                checkConstraints(e);
                GraphNode<L> v = otherNode(e, u);
                if (!v.equals(u) // evito i cappi
                        && v.getColor() == GraphNode.COLOR_WHITE
                        // v è ancora in gioco
                        && e.getWeight() < v.getFloatingPointDistance()
                    // il peso dell'arco migliora la distanza corrente
                ) {
                    // aggiorno il predecessore di v
                    v.setPrevious(u);
                    // aggiorno la distanza di v
                    v.setFloatingPointDistance(e.getWeight());
                }
            }
        }
    }

    // Metodi aggiunti per l'implementazione
    private GraphNode<L> extractMinimum() {
        GraphNode<L> min = this.queue.get(0);
        int minIndex = 0;
        for (int i = 1; i < this.queue.size(); i++)
            if (this.queue.get(i).getFloatingPointDistance() < min
                    .getFloatingPointDistance()) {
                min = this.queue.get(i);
                minIndex = i;
            }
        return this.queue.remove(minIndex);
    }

    private void initGraph(Graph<L> g, GraphNode<L> s) {
        /*
         * Per ogni nodo setto il colore a bianco, previous a null e priorità
         * uguale a più infinito, tranne che per la sorgente, che ha priorità
         * zero.
         */
        for (GraphNode<L> n : g.getNodes()) {
            n.setPrevious(null);
            if (n.equals(s))
                n.setFloatingPointDistance(0);
            else
                n.setFloatingPointDistance(Double.POSITIVE_INFINITY);
            n.setColor(GraphNode.COLOR_WHITE);
        }
    }

    /*
     * Controlla i vincoli su un arco, che deve essere pesato e con peso non
     * negativo.
     */
    private void checkConstraints(GraphEdge<L> e) {
        Double p1 = e.getWeight();
        if (p1.isNaN())
            throw new IllegalArgumentException(
                    "Arco " + e.toString() + " non pesato nel grafo");
        if (p1.doubleValue() < 0)
            throw new IllegalArgumentException(
                    "Arco " + e.toString() + " con peso negativo nel grafo");
    }

    /*
     * Da un arco estrae il nodo che non corrisponde al nodo passato.
     */
    private GraphNode<L> otherNode(GraphEdge<L> e, GraphNode<L> u) {
        if (e.getNode1().equals(u))
            return e.getNode2();
        else
            return e.getNode1();
    }

}
