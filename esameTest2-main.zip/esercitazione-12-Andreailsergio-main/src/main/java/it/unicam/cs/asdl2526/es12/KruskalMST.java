package it.unicam.cs.asdl2526.es12;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Classe singoletto che implementa l'algoritmo di Kruskal per trovare un
 * Minimum Spanning Tree (MST) di un grafo non orientato, pesato e con pesi
 * non negativi.
 *
 * L'algoritmo ordina tutti gli archi per peso crescente e li aggiunge
 * all'MST uno alla volta, scartando quelli che creerebbero un ciclo.
 * Il controllo dei cicli è realizzato con la struttura Union-Find
 * (insiemi disgiunti) implementata tramite una HashMap di rappresentanti
 * (senza ottimizzazioni avanzate, per semplicità).
 *
 * Dopo l'esecuzione, il risultato è disponibile tramite {@code getMST()}
 * come insieme di archi che costituiscono l'MST.
 *
 * @author Template stile: Luca Tesei
 *
 * @param <L>
 *                tipo delle etichette dei nodi del grafo
 */
public class KruskalMST<L> {

    /*
     * Insieme degli archi dell'MST trovato dall'ultima chiamata a
     * computeMST(). Variabile protected per scopi di testing JUnit.
     */
    protected Set<GraphEdge<L>> mst;

    /**
     * Crea un nuovo algoritmo con MST inizialmente vuoto.
     */
    public KruskalMST() {
        this.mst = new HashSet<GraphEdge<L>>();
    }

    /**
     * Utilizza l'algoritmo di Kruskal per trovare un albero di copertura
     * minimo in un grafo non orientato e pesato, con pesi degli archi non
     * negativi. Dopo l'esecuzione il risultato è disponibile tramite
     * {@code getMST()}.
     *
     * @param g
     *              un grafo non orientato, pesato, con pesi non negativi
     *
     * @throws NullPointerException
     *                                  se il grafo g è nullo
     * @throws IllegalArgumentException
     *                                  se il grafo g è orientato
     * @throws IllegalArgumentException
     *                                  se il grafo g contiene almeno un arco
     *                                  non pesato (peso Double.NaN)
     * @throws IllegalArgumentException
     *                                  se il grafo g contiene almeno un arco
     *                                  con peso negativo
     */
    public void computeMST(Graph<L> g) {
        if (g == null)
            throw new NullPointerException("Grafo nullo");
        if (g.isDirected())
            throw new IllegalArgumentException(
                    "Il grafo passato è orientato, Kruskal opera su "
                            + "grafi non orientati");
        // Controllo tutti gli archi prima di iniziare
        for (GraphEdge<L> e : g.getEdges())
            checkConstraints(e);

        // Svuoto il risultato precedente
        this.mst.clear();

        // ── Passo 1: ordina tutti gli archi per peso crescente ────────────────
        List<GraphEdge<L>> archiOrdinati =
                new ArrayList<GraphEdge<L>>(g.getEdges());
        Collections.sort(archiOrdinati, new Comparator<GraphEdge<L>>() {
            @Override
            public int compare(GraphEdge<L> e1, GraphEdge<L> e2) {
                return Double.compare(e1.getWeight(), e2.getWeight());
            }
        });

        // ── Passo 2: inizializza Union-Find ───────────────────────────────────
        // Ogni nodo parte nella propria componente (è il rappresentante di se stesso)
        Map<GraphNode<L>, GraphNode<L>> parent =
                new HashMap<GraphNode<L>, GraphNode<L>>();
        for (GraphNode<L> node : g.getNodes())
            parent.put(node, node);

        // ── Passo 3: elabora gli archi in ordine crescente ────────────────────
        for (GraphEdge<L> e : archiOrdinati) {
            GraphNode<L> u = e.getNode1();
            GraphNode<L> v = e.getNode2();

            // Salta i cappi (un cappio creerebbe sempre un ciclo)
            if (u.equals(v))
                continue;

            GraphNode<L> repU = find(parent, u);
            GraphNode<L> repV = find(parent, v);

            if (!repU.equals(repV)) {
                // u e v sono in componenti diverse: aggiungi l'arco all'MST
                this.mst.add(e);
                // Unisci le due componenti
                union(parent, repU, repV);
            }
            // altrimenti: u e v sono già nella stessa componente
            //             → aggiungere l'arco creerebbe un ciclo → scarta

            // Ottimizzazione: se abbiamo già V-1 archi possiamo fermarci
            if (this.mst.size() == g.nodeCount() - 1)
                break;
        }
    }

    /**
     * Restituisce l'insieme degli archi che costituiscono l'MST trovato
     * dall'ultima chiamata a {@code computeMST()}.
     *
     * @return l'insieme degli archi dell'MST, vuoto se il grafo era vuoto
     *         o non ancora computato
     */
    public Set<GraphEdge<L>> getMST() {
        return this.mst;
    }

    /**
     * Calcola il peso totale dell'MST trovato dall'ultima chiamata a
     * {@code computeMST()}.
     *
     * @return la somma dei pesi degli archi dell'MST
     */
    public double getMSTWeight() {
        double totale = 0;
        for (GraphEdge<L> e : this.mst)
            totale += e.getWeight();
        return totale;
    }

    // ── Metodi Union-Find ─────────────────────────────────────────────────────

    /**
     * Trova il rappresentante della componente che contiene il nodo dato.
     * Implementazione base senza path compression.
     *
     * @param parent la mappa nodo → rappresentante
     * @param node   il nodo di cui trovare il rappresentante
     * @return il rappresentante della componente di node
     */
    private GraphNode<L> find(Map<GraphNode<L>, GraphNode<L>> parent,
            GraphNode<L> node) {
        // Risali la catena dei rappresentanti fino al nodo che è rappresentante
        // di se stesso (parent[x] == x)
        GraphNode<L> current = node;
        while (!current.equals(parent.get(current)))
            current = parent.get(current);
        return current;
    }

    /**
     * Unisce le componenti dei due rappresentanti passati.
     * Il secondo rappresentante viene "assorbito" nel primo.
     *
     * @param parent la mappa nodo → rappresentante
     * @param repU   rappresentante della prima componente
     * @param repV   rappresentante della seconda componente
     */
    private void union(Map<GraphNode<L>, GraphNode<L>> parent,
            GraphNode<L> repU, GraphNode<L> repV) {
        // Fa puntare il rappresentante di V al rappresentante di U
        parent.put(repV, repU);
    }

    // ── Metodi di validazione ─────────────────────────────────────────────────

    /*
     * Controlla che l'arco sia pesato e con peso non negativo.
     */
    private void checkConstraints(GraphEdge<L> e) {
        double peso = e.getWeight();
        if (Double.isNaN(peso))
            throw new IllegalArgumentException(
                    "Arco " + e.toString() + " non pesato nel grafo");
        if (peso < 0)
            throw new IllegalArgumentException(
                    "Arco " + e.toString() + " con peso negativo nel grafo");
    }
}
