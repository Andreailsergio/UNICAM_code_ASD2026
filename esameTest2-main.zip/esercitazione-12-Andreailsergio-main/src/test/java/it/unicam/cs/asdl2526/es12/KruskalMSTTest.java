package it.unicam.cs.asdl2526.es12;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Classe di test per la classe KruskalMST.
 * Stile e casi di test analoghi a PrimMSTTest.
 *
 * Casi coperti:
 *  - eccezioni (grafo null, orientato, arco non pesato, peso negativo)
 *  - grafo con un solo nodo
 *  - grafo sconnesso (due componenti separate)
 *  - cappi (devono essere ignorati)
 *  - grafo connesso semplice (MST unico)
 *  - peso totale MST
 *  - più sorgenti / MST stesso indipendentemente dall'ordine di inserimento
 *  - grafo del Cormen (9 archi, risultato noto)
 *
 * @author Test: stile Luca Tesei
 */
class KruskalMSTTest {

    // ── Helper: costruisce il grafo del Cormen (figura MST) ───────────────────
    // Nodi: a b c d e f g h i   Archi (14 in totale, non orientati, pesati)
    // MST atteso (peso 37): a-b(4) a-h(8) h-g(1) g-f(2) f-c(4) c-i(2)
    //                       c-d(7) d-e(9) i-g(6)  ← no, vedi nota
    //
    // MST Cormen figura 23.2 (peso 37):
    //   a-b(4), b-c(8), c-i(2), i-g(6)... NO
    //
    // MST corretto (Cormen, pesi come nel PrimMSTTest):
    //   peso totale = 37.0
    //   archi: g-h(1) c-i(2) f-g(2) a-b(4) c-f(4) c-d(7) b-c(8) d-e(9)
    private Graph<String> buildCormenGraph() {
        Graph<String> gr = new MapAdjacentListUndirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        GraphNode<String> c = new GraphNode<String>("c");
        GraphNode<String> d = new GraphNode<String>("d");
        GraphNode<String> e = new GraphNode<String>("e");
        GraphNode<String> f = new GraphNode<String>("f");
        GraphNode<String> g = new GraphNode<String>("g");
        GraphNode<String> h = new GraphNode<String>("h");
        GraphNode<String> i = new GraphNode<String>("i");
        gr.addNode(a); gr.addNode(b); gr.addNode(c); gr.addNode(d);
        gr.addNode(e); gr.addNode(f); gr.addNode(g); gr.addNode(h);
        gr.addNode(i);
        gr.addEdge(new GraphEdge<String>(a, b, false, 4));
        gr.addEdge(new GraphEdge<String>(a, h, false, 8.5));
        gr.addEdge(new GraphEdge<String>(b, h, false, 11));
        gr.addEdge(new GraphEdge<String>(b, c, false, 8));
        gr.addEdge(new GraphEdge<String>(c, i, false, 2));
        gr.addEdge(new GraphEdge<String>(c, d, false, 7));
        gr.addEdge(new GraphEdge<String>(c, f, false, 4));
        gr.addEdge(new GraphEdge<String>(d, f, false, 14));
        gr.addEdge(new GraphEdge<String>(d, e, false, 9));
        gr.addEdge(new GraphEdge<String>(e, f, false, 10));
        gr.addEdge(new GraphEdge<String>(f, g, false, 2));
        gr.addEdge(new GraphEdge<String>(g, i, false, 6));
        gr.addEdge(new GraphEdge<String>(g, h, false, 1));
        gr.addEdge(new GraphEdge<String>(h, i, false, 7));
        return gr;
    }

    // ── Test eccezioni ────────────────────────────────────────────────────────

    @Test
    final void testExceptionGrafoNull() {
        KruskalMST<String> alg = new KruskalMST<String>();
        assertThrows(NullPointerException.class,
                () -> alg.computeMST(null));
    }

    @Test
    final void testExceptionGrafoOrientato() {
        KruskalMST<String> alg = new KruskalMST<String>();
        // AdjacencyMatrixDirectedGraph è orientato
        Graph<String> gr = new MapAdjacentListUndirectedGraph<String>() {
            @Override
            public boolean isDirected() { return true; }
        };
        assertThrows(IllegalArgumentException.class,
                () -> alg.computeMST(gr));
    }

    @Test
    final void testExceptionArcoNonPesato() {
        KruskalMST<String> alg = new KruskalMST<String>();
        Graph<String> gr = new MapAdjacentListUndirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        gr.addNode(a);
        gr.addNode(b);
        // costruttore senza peso → Double.NaN
        gr.addEdge(new GraphEdge<String>(a, b, false));
        assertThrows(IllegalArgumentException.class,
                () -> alg.computeMST(gr));
    }

    @Test
    final void testExceptionPesoNegativo() {
        KruskalMST<String> alg = new KruskalMST<String>();
        Graph<String> gr = new MapAdjacentListUndirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        gr.addNode(a);
        gr.addNode(b);
        gr.addEdge(new GraphEdge<String>(a, b, false, -3.0));
        assertThrows(IllegalArgumentException.class,
                () -> alg.computeMST(gr));
    }

    // ── Test grafo minimo: un solo nodo ───────────────────────────────────────

    @Test
    final void testGrafoUnNodo() {
        Graph<String> gr = new MapAdjacentListUndirectedGraph<String>();
        gr.addNode(new GraphNode<String>("a"));
        KruskalMST<String> alg = new KruskalMST<String>();
        alg.computeMST(gr);
        // MST di un solo nodo: nessun arco
        assertTrue(alg.getMST().isEmpty());
        assertEquals(0.0, alg.getMSTWeight(), 1e-9);
    }

    // ── Test grafo sconnesso ──────────────────────────────────────────────────

    @Test
    final void testGrafoSconnesso() {
        // Due componenti separate: {a,b} e {c,d}
        Graph<String> gr = new MapAdjacentListUndirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        GraphNode<String> c = new GraphNode<String>("c");
        GraphNode<String> d = new GraphNode<String>("d");
        gr.addNode(a); gr.addNode(b);
        gr.addNode(c); gr.addNode(d);
        gr.addEdge(new GraphEdge<String>(a, b, false, 1.0));
        gr.addEdge(new GraphEdge<String>(c, d, false, 2.0));
        // nessun arco tra {a,b} e {c,d}

        KruskalMST<String> alg = new KruskalMST<String>();
        alg.computeMST(gr);

        // Kruskal produce una "spanning forest": 2 archi (uno per componente)
        assertEquals(2, alg.getMST().size());
        assertEquals(3.0, alg.getMSTWeight(), 1e-9);
    }

    // ── Test cappi (devono essere ignorati) ───────────────────────────────────

    @Test
    final void testCappi() {
        Graph<String> gr = new MapAdjacentListUndirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        GraphNode<String> c = new GraphNode<String>("c");
        gr.addNode(a); gr.addNode(b); gr.addNode(c);
        gr.addEdge(new GraphEdge<String>(a, b, false, 3.0));
        gr.addEdge(new GraphEdge<String>(b, c, false, 2.0));
        gr.addEdge(new GraphEdge<String>(a, a, false, 0.0)); // cappio su a
        gr.addEdge(new GraphEdge<String>(b, b, false, 1.0)); // cappio su b

        KruskalMST<String> alg = new KruskalMST<String>();
        alg.computeMST(gr);

        // MST: 2 archi (a-b e b-c), i cappi devono essere ignorati
        assertEquals(2, alg.getMST().size());
        assertEquals(5.0, alg.getMSTWeight(), 1e-9);

        // Verifica che nessun cappio sia nell'MST
        for (GraphEdge<String> e : alg.getMST())
            assertFalse(e.getNode1().equals(e.getNode2()),
                    "L'MST non deve contenere cappi");
    }

    // ── Test grafo semplice 4 nodi (stesso di PrimMSTTest) ────────────────────

    @Test
    final void testGrafo4Nodi() {
        // a-b(1), a-c(5), b-d(2), b-c(3), c-d(4)
        // MST: a-b(1), b-d(2), b-c(3)  peso = 6
        Graph<String> gr = new MapAdjacentListUndirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        GraphNode<String> c = new GraphNode<String>("c");
        GraphNode<String> d = new GraphNode<String>("d");
        gr.addNode(a); gr.addNode(b);
        gr.addNode(c); gr.addNode(d);
        gr.addEdge(new GraphEdge<String>(a, b, false, 1));
        gr.addEdge(new GraphEdge<String>(a, c, false, 5));
        gr.addEdge(new GraphEdge<String>(b, d, false, 2));
        gr.addEdge(new GraphEdge<String>(b, c, false, 3));
        gr.addEdge(new GraphEdge<String>(c, d, false, 4));

        KruskalMST<String> alg = new KruskalMST<String>();
        alg.computeMST(gr);

        // MST deve avere esattamente V-1 = 3 archi
        assertEquals(3, alg.getMST().size());
        // peso totale: 1 + 2 + 3 = 6
        assertEquals(6.0, alg.getMSTWeight(), 1e-9);

        // gli archi a-c(5) e c-d(4) NON devono essere nell'MST
        // (li esclude perché creerebbero cicli)
        for (GraphEdge<String> e : alg.getMST()) {
            assertFalse(e.getWeight() == 5.0 &&
                    ((e.getNode1().equals(a) && e.getNode2().equals(c)) ||
                     (e.getNode1().equals(c) && e.getNode2().equals(a))),
                    "a-c(5) non deve essere nell'MST");
            assertFalse(e.getWeight() == 4.0 &&
                    ((e.getNode1().equals(c) && e.getNode2().equals(d)) ||
                     (e.getNode1().equals(d) && e.getNode2().equals(c))),
                    "c-d(4) non deve essere nell'MST");
        }
    }

    // ── Test peso totale MST (stesso grafo Cormen di PrimMSTTest) ─────────────

    @Test
    final void testCormenPesoTotale() {
        Graph<String> gr = buildCormenGraph();
        KruskalMST<String> alg = new KruskalMST<String>();
        alg.computeMST(gr);

        // MST di 9 nodi deve avere esattamente 8 archi
        assertEquals(8, alg.getMST().size());

        // Peso totale MST Cormen (con a-h = 8.5):
        // g-h(1) + f-g(2) + c-i(2) + a-b(4) + c-f(4) + c-d(7) + a-h(8.5) + d-e(9)
        // = 37.5
        assertEquals(37.0, alg.getMSTWeight(), 1e-9);
    }

    // ── Test archi specifici nell'MST Cormen ──────────────────────────────────

    @Test
    final void testCormenArchiMST() {
        Graph<String> gr = buildCormenGraph();
        KruskalMST<String> alg = new KruskalMST<String>();
        alg.computeMST(gr);
        Set<GraphEdge<String>> mst = alg.getMST();

        // g-h(1) deve essere nell'MST (è il più leggero)
        assertTrue(contieneArco(mst, "g", "h", 1.0),
                "MST deve contenere g-h(1)");

        // f-g(2) deve essere nell'MST
        assertTrue(contieneArco(mst, "f", "g", 2.0),
                "MST deve contenere f-g(2)");

        // c-i(2) deve essere nell'MST
        assertTrue(contieneArco(mst, "c", "i", 2.0),
                "MST deve contenere c-i(2)");

        // a-b(4) deve essere nell'MST
        assertTrue(contieneArco(mst, "a", "b", 4.0),
                "MST deve contenere a-b(4)");

        // b-h(11) NON deve essere nell'MST (troppo pesante, creerebbe ciclo)
        assertFalse(contieneArco(mst, "b", "h", 11.0),
                "MST non deve contenere b-h(11)");

        // d-f(14) NON deve essere nell'MST
        assertFalse(contieneArco(mst, "d", "f", 14.0),
                "MST non deve contenere d-f(14)");
    }

    // ── Test: Kruskal e Prim producono lo stesso peso totale ──────────────────

    @Test
    final void testKruskalVsPrimStessoPeso() {
        Graph<String> gr = buildCormenGraph();

        KruskalMST<String> kruskal = new KruskalMST<String>();
        kruskal.computeMST(gr);

        PrimMST<String> prim = new PrimMST<String>();
        prim.computeMSP(gr, gr.getNodeOf("a"));

        // Calcola il peso dell'MST di Prim sommando i floatingPointDistance
        double pesoPrim = 0;
        for (GraphNode<String> n : gr.getNodes())
            if (n.getPrevious() != null)
                pesoPrim += n.getFloatingPointDistance();

        assertEquals(kruskal.getMSTWeight(), pesoPrim, 1e-9,
                "Kruskal e Prim devono produrre lo stesso peso totale MST");
    }

    // ── Test: chiamate multiple resettano il risultato ────────────────────────

    @Test
    final void testChiamateMultiple() {
        KruskalMST<String> alg = new KruskalMST<String>();
        Graph<String> gr = buildCormenGraph();

        alg.computeMST(gr);
        double peso1 = alg.getMSTWeight();

        // seconda chiamata sullo stesso grafo
        alg.computeMST(gr);
        double peso2 = alg.getMSTWeight();

        assertEquals(peso1, peso2, 1e-9,
                "Due chiamate sullo stesso grafo devono dare lo stesso risultato");
        assertEquals(8, alg.getMST().size());
    }

    // ── Metodo di utilità ─────────────────────────────────────────────────────

    /**
     * Verifica se nell'insieme di archi è presente un arco non orientato
     * tra due nodi con le etichette date e il peso dato.
     */
    private boolean contieneArco(Set<GraphEdge<String>> archi,
            String label1, String label2, double peso) {
        for (GraphEdge<String> e : archi) {
            if (Math.abs(e.getWeight() - peso) < 1e-9) {
                String l1 = e.getNode1().getLabel();
                String l2 = e.getNode2().getLabel();
                if ((l1.equals(label1) && l2.equals(label2)) ||
                    (l1.equals(label2) && l2.equals(label1)))
                    return true;
            }
        }
        return false;
    }
}
