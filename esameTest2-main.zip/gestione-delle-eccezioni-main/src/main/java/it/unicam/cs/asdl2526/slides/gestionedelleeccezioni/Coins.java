package it.unicam.cs.asdl2526.slides.gestionedelleeccezioni;

/**
 * Alcune costanti pubbliche per monete USA.
 * 
 * @author Luca Tesei
 *
 */
public interface Coins {

    String PENNY_NAME = "Penny"; // public static sottinteso

    public static double PENNY_VALUE = 0.01;

    public static String NICKEL_NAME = "Nickel";

    public static double NICKEL_VALUE = 0.05;

    public static String DIME_NAME = "Dime";

    public static double DIME_VALUE = 0.1;

    public static String QUARTER_NAME = "Quarter";

    public static double QUARTER_VALUE = 0.25;

}
