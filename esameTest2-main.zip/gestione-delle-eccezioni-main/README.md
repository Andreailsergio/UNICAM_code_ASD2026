## Codice associato alle slides su recall di gestione delle eccezioni in Java
