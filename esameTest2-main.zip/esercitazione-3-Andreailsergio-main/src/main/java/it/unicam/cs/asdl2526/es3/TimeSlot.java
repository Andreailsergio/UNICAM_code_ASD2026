/**
 * 
 */
package it.unicam.cs.asdl2526.es3;

// TODO completare gli import se necessario
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Un time slot è un intervallo di tempo continuo che può essere associato ad
 * una prenotazione. Gli oggetti della classe sono immutabili. Non sono ammessi
 * time slot che iniziano e finiscono nello stesso istante.
 * 
 * @author Luca Tesei
 *
 */
public class TimeSlot implements Comparable<TimeSlot> {

    /**
     * Rappresenta la soglia di tolleranza da considerare nella sovrapposizione
     * di due Time Slot. Se si sovrappongono per un numero di minuti minore o
     * uguale a questa soglia allora NON vengono considerati sovrapposti.
     */
    public static final int MINUTES_OF_TOLERANCE_FOR_OVERLAPPING = 5;

    private final GregorianCalendar start;

    private final GregorianCalendar stop;

    /**
     * Crea un time slot tra due istanti di inizio e fine
     * 
     * @param start
     *                  inizio del time slot
     * @param stop
     *                  fine del time slot
     * @throws NullPointerException
     *                                      se uno dei due istanti, start o
     *                                      stop, è null
     * @throws IllegalArgumentException
     *                                      se start è uguale o successivo a
     *                                      stop
     */
    public TimeSlot(GregorianCalendar start, GregorianCalendar stop) {
        // TODO implementare
        this.start = start;
        this.stop = stop;
        if (start.compareTo(stop) >= 0)
            throw new IllegalArgumentException(
                    "Tentativo di creare un time slot con inizio maggiore o uguale di fine");
        if (start.equals(stop)==true)
            throw new IllegalArgumentException("inizio e fine del time slot devono avvenire in momenti diversi");
        // if (stop.after(start)==true)
        //    throw new IllegalArgumentException("fine del time slot non può precedere inizio");
        if (start==null || stop==null)
            throw new NullPointerException("gli istanti di partenza o termine del TimeSlot non possono essere null");
    }

    /**
     * @return the start
     */
    public GregorianCalendar getStart() {
        if (start.compareTo(stop) >= 0)
            throw new IllegalArgumentException(
                    "Tentativo di creare un time slot con inizio maggiore o uguale di fine");
        return start;
    }

    /**
     * @return the stop
     */
    public GregorianCalendar getStop() {
        if (start.compareTo(stop) >= 0)
            throw new IllegalArgumentException(
                    "Tentativo di creare un time slot con inizio maggiore o uguale di fine");
        return stop;
    }

    /*
     * Un time slot è uguale a un altro se rappresenta esattamente lo stesso
     * intervallo di tempo, cioè se inizia nello stesso istante e termina nello
     * stesso istante.
     */
    @Override
    public boolean equals(Object obj) {
        // TODO implementare
        // se l'oggetto passato (obj) ed il suo puntatore in memoria (this) sono effettivamente la stessa cosa
        // e se obj è un'istanza di timeslot o sue sottoclassi
        // allora l'uguaglianza è confermata
        if (this == obj)
            return true;
        if (!(obj instanceof TimeSlot))
            return false;
            // se sono uguali possiamo procedere, ma per poter usare obj.start o obj.stop devo fare Casting
            // cioè convertire l'oggetto generico in un TimeSlot, al fine di accedere ai suoi campi start/stop
            TimeSlot other = (TimeSlot) obj;
            // gestisco 3 sottocasi:
            // 1. this.start e other.start entrambi nulli -> si continua: ritorno true
            // 2. this.start nullo e other.start non nullo -> sono diversi: ritorno false
            // 3. this.start non nullo e other.start con qualsiasi altro valore
            //      -> faccio confronto con equals e ritorno false se non uguali
            // SCHEMA FLUSSO:
            // equals(obj)
            //    │
            //    ├─ this == obj? ──────────────────────────→ true
            //    │
            //    ├─ obj non è TimeSlot? ───────────────────→ false
            //    │
            //    ├─ cast a TimeSlot
            //    │
            //    ├─ start diversi? ────────────────────────→ false
            //    │
            //    ├─ stop diversi? ─────────────────────────→ false
            //    │
            //    └─ tutto uguale ──────────────────────────→ true
            if (start == null) {
                if (other.start != null)
                    return false;
            } else if (!start.equals(other.start))
                return false;
            // stessa logica su stop
            if (stop == null) {
                if (other.stop != null)
                    return false;
            }  else if (!stop.equals(other.stop))
                return false;
            // se tutti i controlli precedenti sono superati restituisco TRUE
            return true;
        // return false;
        // l'utilizzo di start e stop tanto in equals così come in hashCode [in @Override]
        // garantisce il riallineamento e la congruità dei due metodi
    }

    /*
     * Il codice hash associato a un timeslot viene calcolato a partire dei due
     * istanti di inizio e fine, in accordo con i campi usati per il metodo equals.
     * Questa implementazione rispetta il contratto Java tra equals e hashCode:
     * se ts1.equals(ts2) è true (stessi start e stop), allora ts1.hashCode() == ts2.hashCode() è garantito,
     * perché si usano esattamente gli stessi campi usati in equals.
     *
     * Regola d'oro: se ridefinisci equals, ridefinisci SEMPRE anche hashCode.
     * Strutture come HashSet e HashMap usano l'hash per organizzare internamente gli oggetti in "secchi" (bucket).
     * Se due oggetti sono uguali secondo equals ma hanno hash diversi, la struttura li mette in bucket diversi
     * e non li riconosce come duplicati —> comportamento scorretto.
     * In questo caso la classe rappresenta un timeslot (un intervallo di tempo con start e stop),
     * e l'uguaglianza tra due timeslot ts1 e ts2 è definita dai loro due estremi.
     * Quindi anche l'hash deve dipendere dagli stessi due campi.
     *
     * Il viceversa (stesso hash → oggetti uguali) non è richiesto e in generale non vale:
     * possono esistere collisioni, cioè oggetti diversi con lo stesso hash
     */
    @Override
    public int hashCode() {
        // TODO implementare
        // per convenzione [anche in String.hashCode() di default] si sceglie il numero primo 31 come moltiplicatore
        // i numeri primi riducono le collisioni
        // inoltre 31 è comodo per l'ottimizzazione della JVM
        // (perché gli stack in memoria degli interi valgono 32 bit - conteggio da 0 a 31)
        final int prime = 31;
        // l'accumulatore parte da 1
        int result = 1;
        // ricorsione: con result iniziale pari a 1 ->
        // dopo start:  result = 31 * 1        + hash(start) (si mescola nel risultato il contributo di start)
        // dopo stop:   result = 31 * result   + hash(stop)  (analogamente per contributo di stop)
        // Ogni campo viene "annegato" dentro il risultato precedente prima che il successivo venga aggiunto,
        // in modo che l'ordine di start e stop e il valore di entrambi i campi influenzino il risultato finale.
        result = prime * result + start.hashCode();
        result = prime * result + stop.hashCode();
        // Si restituisce il valore finale -> un intero che rappresenta in modo compatto la "firma" dell'oggetto
        return result;
        // return -1;
    }

    /*
     * Il metodo serve a restituire il valore della comparazione tra start e stop
     * se = 0 sono uguali / se > 0 il primo elemento è maggiore / se < 0 il primo elemento è minore
     *
     * Un time slot precede un altro se inizia prima. Se due time slot iniziano
     * nello stesso momento quello che finisce prima precede l'altro. Se hanno
     * stesso inizio e stessa fine sono uguali, in compatibilità con equals.
     */
    @Override
    public int compareTo(TimeSlot o) {
        // TODO implementare
        if (o == null)
            throw new NullPointerException(
                    "Errato tentativo di comparare un time slot nullo");
        int cmp = this.start.compareTo(o.start);
        if (cmp != 0)
            // i due time slot non iniziano nello stesso momento, quindi cmp dà il valore giusto di ritorno
            return cmp;
        // altrimenti i due time slot iniziano nello stesso momento e vado a controllare la fine (stop)
        cmp = this.stop.compareTo(o.stop);
        // se zero allora sono uguali, altrimenti non sono uguali
        // in ogni caso cmp dà il valore giusto di ritorno
        return cmp;
        // return -1;
    }

    /**
     * Determina il numero di minuti di sovrapposizione tra questo timeslot e
     * quello passato.
     * 
     * @param o
     *              il time slot da confrontare con questo
     * @return il numero di minuti di sovrapposizione tra questo time slot e
     *         quello passato, oppure -1 se non c'è sovrapposizione. Se questo
     *         time slot finisce esattamente al millisecondo dove inizia il time
     *         slot <code>o</code> non c'è sovrapposizione, così come se questo
     *         time slot inizia esattamente al millisecondo in cui finisce il
     *         time slot <code>o</code>. In questi ultimi due casi il risultato
     *         deve essere -1 e non 0. Nel caso in cui la sovrapposizione non è
     *         di un numero esatto di minuti, cioè ci sono secondi e
     *         millisecondi che avanzano, il numero dei minuti di
     *         sovrapposizione da restituire deve essere arrotondato per difetto
     * @throws NullPointerException
     *                                      se il time slot passato è nullo
     * @throws IllegalArgumentException
     *                                      se i minuti di sovrapposizione
     *                                      superano Integer.MAX_VALUE
     *                                      (valori troppo grandi di intervalli temporali non sono gestiti)
     */
    public int getMinutesOfOverlappingWith(TimeSlot o) {
        // TODO implementare
        // non ha senso calcolare la sovrapposizione con un timeslot inesistente
        if (o == null)
            throw new NullPointerException(
                    "Tentativo di calcolare i minuti di sovrapposizione di "
                            + "questo time slot con un time slot nullo");
        // Controllo tutti i casi di sovrapposizione
        // compareTo su oggetti Calendar restituisce:
        // - un n° negativo se il primo è prima del secondo
        // - zero se coincidono
        // - un n° positivo se è dopo.
        // Con queste quattro variabili: this.start vs o.start & o.stop + this.stop vs o.start & o.stop
        // si ha tutto il necessario per capire la posizione relativa tra i due intervalli.
        int cmp1 = this.start.compareTo(o.start);
        int cmp2 = this.start.compareTo(o.stop);
        int cmp3 = this.stop.compareTo(o.start);
        int cmp4 = this.stop.compareTo(o.stop);
        // variabile per memorizzare la lunghezza in millisecondi della sovrapposizione
        // (tempo più distante nel futuro - tempo precedente)
        long overlappingMilliseconds;
        // CASO 1   this inizia prima e termina nel mezzo di o
        //          cmp1 <= 0 → this.start ≤ o.start    (inizia prima dell'inizio di o)
        //          cmp3 >= 0 → this.stop ≥ o.start     (c'è entrata nella zona di o)
        //          cmp4 <= 0 → this.stop ≤ o.stop      (non supera la fine di o)
        // La sovrapposizione va da o.start a this.stop.
        if (cmp1 <= 0 && cmp3 >= 0 && cmp4 <= 0) {
            // questo timeslot inizia prima di quello passato e termina dopo che quello passato è iniziato
            // this.start ... [o.start ... this.stop] ... o.stop
            overlappingMilliseconds = this.stop.getTimeInMillis()
                    - o.start.getTimeInMillis();
            return computeMinutes(overlappingMilliseconds);
        }
        // CASO 2   this contiene completamente o
        //          this inizia prima di o e finisce dopo: o è interamente dentro this.
        //          cmp1 <= 0 → this.start ≤ o.start   (inizia prima dell'inizio di o)
        //          cmp4 >= 0 → this.stop ≥ o.stop     (supera la fine di o)
        // La sovrapposizione è l'intera durata di o.
        if (cmp1 <= 0 && cmp4 >= 0) {
            // questo timeslot inizia prima di quello passato e termina dopo che quello passato è finito
            // this.start ... [o.start ... o.stop] ... this.stop
            overlappingMilliseconds = o.stop.getTimeInMillis()
                    - o.start.getTimeInMillis();
            return computeMinutes(overlappingMilliseconds);
        }
        // CASO 3   this inizia nel mezzo di o e termina dopo
        //          cmp1 >= 0 → this.start ≥ o.start    (inizia dopo dell'inizio di o)
        //          cmp2 <= 0 → this.start ≤ o.stop     (è ancora dentro o)
        //          cmp4 >= 0 → this.stop ≥ o.stop      (supera la fine di o)
        // La sovrapposizione va da this.start a o.stop.
        if (cmp1 >= 0 && cmp2 <= 0 && cmp4 >= 0) {
            // questo timeslot inizia dopo di quello passato e termina dopo che quello passato è terminato
            // o.start ... [this.start ... o.stop] ... this.stop
            overlappingMilliseconds = o.stop.getTimeInMillis()
                    - this.start.getTimeInMillis();
            return computeMinutes(overlappingMilliseconds);
        }
        // CASO 4   o contiene completamente this
        //          cmp1 >= 0 → this.start ≥ o.start    (inizia dopo dell'inizio di o)
        //          cmp4 <= 0 → this.stop ≤ o.stop      (non supera la fine di o)
        // this è interamente contenuto dentro o -> La sovrapposizione è l'intera durata di this.
        if (cmp1 >= 0 && cmp4 <= 0) {
            // questo timeslot inizia prima di quello passato e termina dopo che quello passato è finito
            // o.start ... [this.start ... this.stop] ... o.stop
            overlappingMilliseconds = this.stop.getTimeInMillis()
                    - this.start.getTimeInMillis();
            return computeMinutes(overlappingMilliseconds);
        }

        // Schema visivo dei quattro casi
        // Caso 1:  |--this--|
        //              |-----o-----|
        //
        // Caso 2:  |--------this--------|
        //              |---o---|
        //
        // Caso 3:       |-----this------|
        //          |--o--|
        //
        // Caso 4:       |--this--|
        //          |-------o-------|

        // Se nessuno dei quattro casi si verifica, i due intervalli sono disgiunti
        // (o si toccano solo in un punto, che per specifica non conta come sovrapposizione).
        // non c'è sovrapposizione
        return -1;


        // return -1;
    }


    /*
     * Calcola il numero di minuti di sovrapposizione a partire dai millisecondi facendo il troncamento.
     * Converte i millisecondi di sovrapposizione in minuti interi, gestendo i casi limite.
     * Gestisce il caso particolare in cui il numero di millisecondi passati è 0.
     * Lancia IllegalArgumentException se il numero di minuti è troppo grande per un int.
     */
    private int computeMinutes(long overlappingMilliseconds) {
        // Caso particolare di esattamente 0 millisecondi di sovrapposizione, da considerare non sovrapposizione.
        // (per specifica si tratta come assenza di sovrapposizione quando i due intervalli si toccano in un punto preciso)
        if (overlappingMilliseconds == 0)
            return -1;
        // La divisione intera tra long butta via automaticamente i decimali
        // è il "troncamento per difetto" richiesto dalla specifica.
        // 60.000 millisecondi = 1 minuto.
        long truncatedOverlappingMinutes = overlappingMilliseconds / 60000;
        // Sicurezza: il risultato deve rientrare in un int.
        // Se i timeslot fossero enormi (decine di migliaia di anni) il numero di minuti potrebbe non starci.
        if (truncatedOverlappingMinutes > Integer.MAX_VALUE)
            throw new IllegalArgumentException(
                    "Numero di minuti di sovrapposizione troppo grande per un int");
        // Ritorno con Cast finale sicuro (il controllo precedente lo garantisce).
        return (int) truncatedOverlappingMinutes;
    }

    /**
     * Determina se questo time slot si sovrappone a un altro time slot dato,
     * considerando la soglia di tolleranza.
     * 
     * @param o
     *              il time slot che viene passato per il controllo di
     *              sovrapposizione
     * @return true se questo time slot si sovrappone per più (strettamente) di
     *         MINUTES_OF_TOLERANCE_FOR_OVERLAPPING minuti a quello passato
     * @throws NullPointerException
     *                                  se il time slot passato è nullo
     *
     */
    public boolean overlapsWith(TimeSlot o) {
        // TODO implementare
        // Calcolo i minuti di sovrapposizione richiamando getMinutesOfOverlappingWith
        // Ritornando true solo se la sovrapposizione c'è ed è significativa
        int minutes = this.getMinutesOfOverlappingWith(o);
        if (minutes == -1)
            // non c'è sovrapposizione
            return false;
        if (minutes <= MINUTES_OF_TOLERANCE_FOR_OVERLAPPING)
            // la soglia di tolleranza non è superata
            return false;
        // c'è sovrapposizione
        return true;
        // return false;
    }

    /*
     * Ridefinisce il modo in cui viene reso un TimeSlot con una String.
     * 
     * Esempio 1, stringa da restituire: "[4/11/2019 11.0 - 4/11/2019 13.0]"
     * 
     * Esempio 2, stringa da restituire: "[10/11/2019 11.15 - 10/11/2019 23.45]"
     * 
     * I secondi e i millisecondi eventuali non vengono scritti.
     */
    @Override
    public String toString() {
        return "[" + start.get(Calendar.DAY_OF_MONTH) + "/"
                + (start.get(Calendar.MONTH) + 1) + "/"
                + start.get(Calendar.YEAR) + " "
                + start.get(Calendar.HOUR_OF_DAY) + "."
                + start.get(Calendar.MINUTE) + " - "
                + stop.get(Calendar.DAY_OF_MONTH) + "/"
                + (stop.get(Calendar.MONTH) + 1) + "/" + stop.get(Calendar.YEAR)
                + " " + stop.get(Calendar.HOUR_OF_DAY) + "."
                + stop.get(Calendar.MINUTE) + "]";
    }

}
