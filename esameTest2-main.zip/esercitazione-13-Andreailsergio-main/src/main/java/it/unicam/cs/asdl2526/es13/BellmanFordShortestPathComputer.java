package it.unicam.cs.asdl2526.es13;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Gli oggetti di questa classe sono calcolatori di cammini minimi con sorgente
 * singola su un certo grafo orientato e pesato dato. A differenza di Dijkstra,
 * il grafo può contenere archi con pesi negativi, purché non esistano cicli di
 * peso negativo raggiungibili dalla sorgente.
 *
 * Il calcolatore implementa l'algoritmo di Bellman-Ford che:
 *   1. inizializza le distanze (sorgente = 0, tutti gli altri = +∞)
 *   2. rilassa tutti gli archi per |V|-1 iterazioni
 *   3. effettua un'iterazione aggiuntiva per rilevare cicli negativi:
 *      se almeno una distanza migliora ancora, esiste un ciclo negativo
 *      raggiungibile dalla sorgente e viene lanciata IllegalStateException.
 *
 * Complessità: O(V * E) — più lento di Dijkstra ma corretto anche con pesi
 * negativi (in assenza di cicli negativi).
 *
 * Stile: identico a DijkstraShortestPathComputer dello stesso package.
 *
 * @author Template stile: Luca Tesei
 *
 * @param <L>
 *                il tipo delle etichette dei nodi del grafo
 */
public class BellmanFordShortestPathComputer<L>
        implements SingleSourceShortestPathComputer<L> {

    private GraphNode<L> lastSource;

    private final Graph<L> graph;

    private boolean isComputed = false;

    /**
     * Crea un calcolatore di cammini minimi a sorgente singola per un grafo
     * orientato e pesato. Il grafo può contenere archi con pesi negativi, ma
     * non deve contenere cicli di peso negativo raggiungibili dalla sorgente
     * (rilevati a runtime durante il calcolo).
     *
     * @param graph
     *                  il grafo su cui opera il calcolatore
     * @throws NullPointerException
     *                                  se il grafo passato è nullo
     * @throws IllegalArgumentException
     *                                  se il grafo passato è vuoto
     * @throws IllegalArgumentException
     *                                  se il grafo passato non è orientato
     * @throws IllegalArgumentException
     *                                  se il grafo contiene almeno un arco
     *                                  non pesato (peso Double.NaN)
     */
    public BellmanFordShortestPathComputer(Graph<L> graph) {
        if (graph == null)
            throw new NullPointerException("Il grafo passato è nullo");
        if (graph.isEmpty())
            throw new IllegalArgumentException("Il grafo passato è vuoto");
        if (!graph.isDirected())
            throw new IllegalArgumentException(
                    "Il grafo passato non è orientato");
        // Controlla che tutti gli archi siano pesati
        // (pesi negativi sono ammessi — verranno gestiti durante il calcolo)
        for (GraphEdge<L> edge : graph.getEdges())
            if (!edge.hasWeight())
                throw new IllegalArgumentException(
                        "Arco non pesato nel grafo: " + edge.toString());
        this.graph = graph;
        this.isComputed = false;
        this.lastSource = null;
    }

    /**
     * Esegue l'algoritmo di Bellman-Ford a partire dal nodo sorgente dato.
     * Dopo l'esecuzione, ogni nodo del grafo ha:
     *   - {@code floatingPointDistance}: distanza minima dalla sorgente
     *     (Double.POSITIVE_INFINITY se non raggiungibile)
     *   - {@code previous}: nodo predecessore nel cammino minimo
     *     (null se non raggiungibile o se è la sorgente)
     *
     * @param sourceNode
     *                       il nodo sorgente
     * @throws NullPointerException
     *                                  se il nodo passato è nullo
     * @throws IllegalArgumentException
     *                                  se il nodo passato non esiste nel grafo
     * @throws IllegalStateException
     *                                  se esiste un ciclo di peso negativo
     *                                  raggiungibile dalla sorgente
     */
    @Override
    public void computeShortestPathsFrom(GraphNode<L> sourceNode) {
        if (sourceNode == null)
            throw new NullPointerException("Il nodo sorgente è nullo");
        // if (this.graph.getNodeOf(sourceNode.getLabel()) == null)
        if (this.graph.getNode(sourceNode) == null)
            throw new IllegalArgumentException(
                    "Il nodo sorgente non è contenuto nel grafo");

        // ── Passo 1: inizializzazione ─────────────────────────────────────────
        // Recupero il nodo interno (potrebbe essere un oggetto diverso da
        // sourceNode ma con la stessa etichetta — stessa precauzione di Dijkstra)
        // GraphNode<L> s = this.graph.getNodeOf(sourceNode.getLabel());
        GraphNode<L> s = this.graph.getNode(sourceNode);

        for (GraphNode<L> node : this.graph.getNodes()) {
            node.setPrevious(null);
            if (node.equals(s))
                node.setFloatingPointDistance(0.0);
            else
                node.setFloatingPointDistance(Double.POSITIVE_INFINITY);
        }

        // ── Passo 2: rilassa tutti gli archi per |V|-1 iterazioni ─────────────
        // Dopo k iterazioni, le distanze calcolate sono ottime per tutti i
        // cammini con al massimo k archi. Dopo |V|-1 iterazioni, ogni cammino
        // minimo (che in assenza di cicli negativi ha al più |V|-1 archi)
        // è stato trovato.
        int numNodi = this.graph.nodeCount();
        for (int i = 1; i <= numNodi - 1; i++) {
            for (GraphEdge<L> edge : this.graph.getEdges()) {
                relax(edge);
            }
        }

        // ── Passo 3: rilevamento cicli negativi ───────────────────────────────
        // Se dopo |V|-1 iterazioni è ancora possibile migliorare una distanza,
        // significa che esiste un ciclo negativo raggiungibile dalla sorgente.
        for (GraphEdge<L> edge : this.graph.getEdges()) {
            GraphNode<L> u = edge.getNode1();
            GraphNode<L> v = edge.getNode2();
            double nuovaDistanza = u.getFloatingPointDistance() + edge.getWeight();
            if (nuovaDistanza < v.getFloatingPointDistance())
                throw new IllegalStateException(
                        "Il grafo contiene un ciclo di peso negativo "
                                + "raggiungibile dalla sorgente "
                                + sourceNode.getLabel());
        }

        this.lastSource = s;
        this.isComputed = true;
    }

    @Override
    public boolean isComputed() {
        return this.isComputed;
    }

    @Override
    public GraphNode<L> getLastSource() {
        if (this.lastSource == null)
            throw new IllegalStateException(
                    "Non è mai stato eseguito questo calcolo");
        return this.lastSource;
    }

    @Override
    public Graph<L> getGraph() {
        return this.graph;
    }

    /**
     * Restituisce la lista di archi corrispondente al cammino minimo dalla
     * sorgente dell'ultimo calcolo al nodo target passato.
     * La lista è vuota se il target è la sorgente stessa.
     * Restituisce null se il target non è raggiungibile dalla sorgente.
     *
     * @param targetNode
     *                       il nodo destinazione
     * @return lista di archi del cammino minimo, lista vuota se target è la
     *         sorgente, null se non raggiungibile
     * @throws NullPointerException
     *                                  se il nodo passato è nullo
     * @throws IllegalArgumentException
     *                                  se il nodo passato non esiste nel grafo
     * @throws IllegalStateException
     *                                  se il calcolo non è ancora stato eseguito
     */
    @Override
    public List<GraphEdge<L>> getShortestPathTo(GraphNode<L> targetNode) {
        if (targetNode == null)
            throw new NullPointerException("Il nodo target è nullo");
        // if (this.graph.getNodeOf(targetNode.getLabel()) == null)
        if (this.graph.getNode(targetNode) == null)
            throw new IllegalArgumentException(
                    "Il nodo target non esiste nel grafo");
        if (!isComputed())
            throw new IllegalStateException(
                    "Il calcolo non è ancora stato eseguito");

        // Recupero il nodo interno corrispondente al target
        // GraphNode<L> target = this.graph.getNodeOf(targetNode.getLabel());
        GraphNode<L> target = this.graph.getNode(targetNode);

        // Nodo non raggiungibile dalla sorgente
        if (target.getFloatingPointDistance() == Double.POSITIVE_INFINITY)
            return null;

        // Ricostruzione del cammino risalendo la catena dei predecessori
        List<GraphEdge<L>> cammino = new ArrayList<GraphEdge<L>>();
        GraphNode<L> corrente = target;
        while (corrente.getPrevious() != null) {
            // Recupero l'arco che va dal predecessore al nodo corrente
            GraphEdge<L> arco = this.graph.getEdge(
                    corrente.getPrevious(), corrente);
            cammino.add(arco);
            corrente = corrente.getPrevious();
        }

        // Il cammino è stato costruito al contrario (da target a sorgente)
        Collections.reverse(cammino);
        return cammino;
    }

    // ── Metodi privati ────────────────────────────────────────────────────────

    /**
     * Esegue il rilassamento di un arco orientato u→v.
     * Se la distanza da sorgente a v passando per u è minore della distanza
     * attuale di v, aggiorna la distanza e il predecessore di v.
     *
     * @param edge l'arco da rilassare
     */
    private void relax(GraphEdge<L> edge) {
        GraphNode<L> u = edge.getNode1();
        GraphNode<L> v = edge.getNode2();

        // Se u non è raggiungibile, non ha senso rilassare l'arco u→v
        // (distanza infinita + qualsiasi peso = infinito o overflow)
        if (u.getFloatingPointDistance() == Double.POSITIVE_INFINITY)
            return;

        double nuovaDistanza = u.getFloatingPointDistance() + edge.getWeight();
        if (nuovaDistanza < v.getFloatingPointDistance()) {
            v.setFloatingPointDistance(nuovaDistanza);
            v.setPrevious(u);
        }
    }
}
