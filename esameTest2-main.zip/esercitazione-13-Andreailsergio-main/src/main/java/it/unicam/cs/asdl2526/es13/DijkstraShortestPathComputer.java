package it.unicam.cs.asdl2526.es13;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

/**
 * Gli oggetti di questa classe sono calcolatori di cammini minimi con sorgente
 * singola su un certo graph orientato e pesato dato. Il graph su cui lavorare
 * deve essere passato quando l'oggetto calcolatore viene costruito e non può
 * contenere archi con pesi negativi. Il calcolatore implementa il classico
 * algoritmo di Dijkstra per i cammini minimi con sorgente singola utilizzando
 * una coda con priorità implementata con una semplice List (non è la soluzione
 * più efficiente, si potrebbe utilizzare uno heap e ottenere prestazioni logaritmiche
 * invece che lineari).
 * 
 * @author Luca Tesei (template)
 *
 * @param <L>
 *                il tipo delle etichette dei nodi del graph
 */
public class DijkstraShortestPathComputer<L>
        implements SingleSourceShortestPathComputer<L> {

    private GraphNode<L> lastSource;

    private final Graph<L> graph;

    private boolean isComputed = false;

    // Coda con priorità usata dall'algoritmo
    private List<GraphNode<L>> queue;

    /**
     * Crea un calcolatore di cammini minimi a sorgente singola per un graph
     * diretto e pesato privo di pesi negativi.
     * 
     * @param graph
     *                  il graph su cui opera il calcolatore di cammini minimi
     * @throws NullPointerException
     *                                      se il graph passato è nullo
     * 
     * @throws IllegalArgumentException
     *                                      se il graph passato è vuoto
     * 
     * @throws IllegalArgumentException
     *                                      se il graph passato non è orientato
     * 
     * @throws IllegalArgumentException
     *                                      se il graph passato non è pesato,
     *                                      cioè esiste almeno un arco il cui
     *                                      peso è {@code Double.NaN}
     * @throws IllegalArgumentException
     *                                      se il graph passato contiene almeno
     *                                      un peso negativo
     */
    public DijkstraShortestPathComputer(Graph<L> graph) {
        // TODO implementare
        if (graph == null) {
            throw new NullPointerException("Il grafo passato � nullo");
        }
        if (graph.isEmpty()) {
            throw new IllegalArgumentException("Il grafo passato � vuoto");
        }
        if (!graph.isDirected()) {
            throw new IllegalArgumentException("Il grafo passato non � orientato");
        }
        for (GraphEdge<L> edge : graph.getEdges()) {
            if (!edge.hasWeight() || edge.getWeight() < 0) {
                throw new IllegalArgumentException("Invalid Graph passed");
            }
        }
        this.graph = graph;
        this.isComputed = false;
        this.lastSource = null;
        this.queue = new ArrayList<GraphNode<L>>();
        // this.graph = graph;
        // this.queue = new ArrayList<GraphNode<L>>();
    }

    @Override
    public void computeShortestPathsFrom(GraphNode<L> sourceNode) {
        // TODO implementare
        if (sourceNode == null) {
            throw new NullPointerException("Il nodo passato è nullo");
        }
        if (this.graph.getNode(sourceNode) == null) {
            throw new IllegalArgumentException("Il nodo passato non è contenuto nel grafo");
        }
        //inizializzazione

        // ── FIX: svuota la coda prima di ricominciare ──────────────────────────
        this.queue.clear();
        // ──────────────────────────────────────────────────────────────────────

        for (GraphNode<L> node : this.graph.getNodes()) {
            queue.add(node);
            node.setPrevious(null);
            if (sourceNode.equals(node)) {
                node.setFloatingPointDistance(0.0);
            } else {
                //distanza iniziale sconosciuta
                //Imposto tutte le distanze dei nodi con un valore che non
                // potrà mai assumere
                node.setFloatingPointDistance(Double.POSITIVE_INFINITY);
            }
        }
        while (!queue.isEmpty()) {
            GraphNode<L> nodeCurrent = extractMinimum();
            //per ogni arco che fa parte degli archi connessi al nodo corrente
            for (GraphEdge<L> edge : graph.getEdgesOf(nodeCurrent)) {
                //pongo il valore della distanza = distanza nodo corrente + peso dell'arco
                double distance = nodeCurrent.getFloatingPointDistance() +
                        edge.getWeight();
                //relax
                if (distance < edge.getNode2().getFloatingPointDistance()) {
                    edge.getNode2().setFloatingPointDistance(distance);
                    edge.getNode2().setPrevious(nodeCurrent);
                }
            }
        }
        this.lastSource = sourceNode;
        this.isComputed = true;
    }

    @Override
    public boolean isComputed() {
        return this.isComputed;
    }

    @Override
    public GraphNode<L> getLastSource() {
        // TODO implementare
        if (this.lastSource == null) {
            throw new IllegalStateException("Non è mai stato eseguito " +
                    "questo calcolo");
        }
        return this.lastSource;
        // return this.lastSource;
    }

    @Override
    public Graph<L> getGraph() {
        return this.graph;
    }

    @Override
    public List<GraphEdge<L>> getShortestPathTo(GraphNode<L> targetNode) {
        // TODO implementare
        // In caso di parametro null
        if (targetNode == null) {
            throw new NullPointerException("Parametro null!");
        }
        // Nodo non appartenente al grafo
        if (this.graph.getNode(targetNode) == null) {
            throw new IllegalArgumentException("Il nodo non esiste!");
        }
        // Se il grafo non è stato computato
        if (!isComputed()) {
            throw new IllegalStateException("Grafo non computato!");
        }
        // Se il nodo non può essere raggiunto dalla sorgente e non è la
        // sorgente
        if (targetNode != getLastSource() &&
                targetNode.getPrevious() == null) {
            return null;
        }
        List<GraphEdge<L>> shortestPath = new ArrayList<>();
        // Se il nodo in riferimento ha un nodo precedente
        if (targetNode.getPrevious() != null) {
            // Finché ha un precedente
            while (targetNode.getPrevious() != null) {
                // Aggiungo l'arco che lo collega al precedente
                shortestPath.add(this.graph.getEdge(targetNode.getPrevious(),
                        targetNode));
                // Il targetNode diventa il suo previous e continuo finch� non ne ha pi�
                targetNode = targetNode.getPrevious();
            }
        }
        /* sono dovuto partire dal nodo di arrivo e andare a ritroso fino al
           nodo di partenza attraverso il metodo getPrevious() dei nodi, aggiungere ogni arco
           attraversato in una List e una volta arrivato al nodo di partenza fare il reverse() della
           lista in modo da avere il percorso in ordine
         */
        Collections.reverse(shortestPath);
        return shortestPath;
        // return null;
    }

    /*
     * Metodo inserito per scopi di test JUnit
     */
    //protected BinaryHeapMinPriorityQueue getQueue() {
    //    return this.queue;
    //}


    // Metodi aggiunti per l'implementazione
    private GraphNode<L> extractMinimum() {
        GraphNode<L> min = this.queue.get(0);
        int minIndex = 0;
        for (int i = 1; i < this.queue.size(); i++)
            if (this.queue.get(i).getFloatingPointDistance() < min
                    .getFloatingPointDistance()) {
                min = this.queue.get(i);
                minIndex = i;
            }
        return this.queue.remove(minIndex);
    }

}
