package it.unicam.cs.asdl2526.es13;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Classe di test per BellmanFordShortestPathComputer.
 * Stile identico a DijkstraShortestPathComputerTest.
 *
 * Tutti i grafi usano AdjacencyMatrixDirectedGraph (unica implementazione
 * disponibile nel package es13). Il metodo per cercare un nodo per etichetta
 * è graph.getNode(L label).
 *
 * Casi coperti:
 *  - eccezioni costruttore (null, vuoto, non orientato, non pesato)
 *  - pesi negativi ammessi nel costruttore (diverso da Dijkstra)
 *  - eccezioni computeShortestPathsFrom (null, nodo assente)
 *  - eccezioni getLastSource / getShortestPathTo prima del calcolo
 *  - isComputed / getLastSource
 *  - grafo Cormen Fig. 25.1 (distanze note: s=0 t=2 x=4 y=7 z=-2)
 *  - cammino minimo verso z: s→y→x→t→z
 *  - sorgente = target → cammino vuoto
 *  - nodo non raggiungibile → null
 *  - ciclo negativo → IllegalStateException
 *  - ciclo positivo → nessuna eccezione
 *  - concordanza con Dijkstra su pesi non negativi
 *  - chiamate multiple con sorgenti diverse
 *
 * @author Test stile: Luca Tesei
 */
class BellmanFordShortestPathComputerTest {

    // ── Helper: grafo Cormen Fig. 25.1 ────────────────────────────────────────
    // Nodi: s t x y z
    // Archi orientati (alcuni pesi negativi):
    //   s→t(6)  s→y(7)  t→x(5)  t→y(8)  t→z(-4)
    //   x→t(-2) y→x(-3) y→z(9)  z→s(2)  z→x(7)
    //
    // Distanze minime da s:
    //   s=0  t=2  x=4  y=7  z=-2
    // Cammino verso z: s→y→x→t→z
    private Graph<String> buildCormenGraph() {
        Graph<String> g = new AdjacencyMatrixDirectedGraph<String>();
        GraphNode<String> s = new GraphNode<String>("s");
        GraphNode<String> t = new GraphNode<String>("t");
        GraphNode<String> x = new GraphNode<String>("x");
        GraphNode<String> y = new GraphNode<String>("y");
        GraphNode<String> z = new GraphNode<String>("z");
        g.addNode(s); g.addNode(t); g.addNode(x);
        g.addNode(y); g.addNode(z);
        g.addEdge(new GraphEdge<String>(s, t, true,  6));
        g.addEdge(new GraphEdge<String>(s, y, true,  7));
        g.addEdge(new GraphEdge<String>(t, x, true,  5));
        g.addEdge(new GraphEdge<String>(t, y, true,  8));
        g.addEdge(new GraphEdge<String>(t, z, true, -4));
        g.addEdge(new GraphEdge<String>(x, t, true, -2));
        g.addEdge(new GraphEdge<String>(y, x, true, -3));
        g.addEdge(new GraphEdge<String>(y, z, true,  9));
        g.addEdge(new GraphEdge<String>(z, s, true,  2));
        g.addEdge(new GraphEdge<String>(z, x, true,  7));
        return g;
    }

    // ── Eccezioni costruttore ─────────────────────────────────────────────────

    @Test
    final void testCostruttoreGrafoNull() {
        assertThrows(NullPointerException.class,
                () -> new BellmanFordShortestPathComputer<String>(null));
    }

    @Test
    final void testCostruttoreGrafoVuoto() {
        Graph<String> g = new AdjacencyMatrixDirectedGraph<String>();
        assertThrows(IllegalArgumentException.class,
                () -> new BellmanFordShortestPathComputer<String>(g));
    }

    @Test
    final void testCostruttoreArcoNonPesato() {
        Graph<String> g = new AdjacencyMatrixDirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        g.addNode(a); g.addNode(b);
        g.addEdge(new GraphEdge<String>(a, b, true)); // peso NaN
        assertThrows(IllegalArgumentException.class,
                () -> new BellmanFordShortestPathComputer<String>(g));
    }

    // Pesi negativi AMMESSI nel costruttore (diverso da Dijkstra)
    @Test
    final void testCostruttoreAccettaPesiNegativi() {
        Graph<String> g = new AdjacencyMatrixDirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        g.addNode(a); g.addNode(b);
        g.addEdge(new GraphEdge<String>(a, b, true, -5.0));
        assertDoesNotThrow(
                () -> new BellmanFordShortestPathComputer<String>(g));
    }

    // ── Eccezioni computeShortestPathsFrom ────────────────────────────────────

    @Test
    final void testComputeNodoNull() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        assertThrows(NullPointerException.class,
                () -> bf.computeShortestPathsFrom(null));
    }

    @Test
    final void testComputeNodoAssente() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        GraphNode<String> fantasma = new GraphNode<String>("NONESISTE");
        assertThrows(IllegalArgumentException.class,
                () -> bf.computeShortestPathsFrom(fantasma));
    }

    // ── Eccezioni getLastSource / getShortestPathTo prima del calcolo ─────────

    @Test
    final void testGetLastSourcePrimaDiCompute() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        assertThrows(IllegalStateException.class, () -> bf.getLastSource());
    }

    @Test
    final void testGetShortestPathToPrimaDiCompute() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        GraphNode<String> z = new GraphNode<String>("z");
        assertThrows(IllegalStateException.class,
                () -> bf.getShortestPathTo(z));
    }

    // ── isComputed ────────────────────────────────────────────────────────────

    @Test
    final void testIsComputed() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        assertFalse(bf.isComputed());
        bf.computeShortestPathsFrom(new GraphNode<String>("s"));
        assertTrue(bf.isComputed());
    }

    // ── getLastSource ─────────────────────────────────────────────────────────

    @Test
    final void testGetLastSource() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        GraphNode<String> s = new GraphNode<String>("s");
        GraphNode<String> y = new GraphNode<String>("y");
        bf.computeShortestPathsFrom(s);
        assertEquals(s, bf.getLastSource());
        bf.computeShortestPathsFrom(y);
        assertEquals(y, bf.getLastSource());
    }

    // ── Distanze minime grafo Cormen ──────────────────────────────────────────

    @Test
    final void testCormenDistanze() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        bf.computeShortestPathsFrom(new GraphNode<String>("s"));

        double delta = 1e-9;
        assertEquals(0.0,  g.getNode("s").getFloatingPointDistance(), delta);
        assertEquals(2.0,  g.getNode("t").getFloatingPointDistance(), delta);
        assertEquals(4.0,  g.getNode("x").getFloatingPointDistance(), delta);
        assertEquals(7.0,  g.getNode("y").getFloatingPointDistance(), delta);
        assertEquals(-2.0, g.getNode("z").getFloatingPointDistance(), delta);
    }

    // ── Cammino minimo verso z ────────────────────────────────────────────────

    @Test
    final void testCormenCamminoVersoZ() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        bf.computeShortestPathsFrom(new GraphNode<String>("s"));

        List<GraphEdge<String>> cammino =
                bf.getShortestPathTo(new GraphNode<String>("z"));

        // cammino atteso: s→y→x→t→z  (4 archi)
        assertNotNull(cammino);
        assertEquals(4, cammino.size());

        assertEquals("s", cammino.get(0).getNode1().getLabel());
        assertEquals("y", cammino.get(0).getNode2().getLabel());

        assertEquals("y", cammino.get(1).getNode1().getLabel());
        assertEquals("x", cammino.get(1).getNode2().getLabel());

        assertEquals("x", cammino.get(2).getNode1().getLabel());
        assertEquals("t", cammino.get(2).getNode2().getLabel());

        assertEquals("t", cammino.get(3).getNode1().getLabel());
        assertEquals("z", cammino.get(3).getNode2().getLabel());
    }

    // ── Sorgente = target → cammino vuoto ────────────────────────────────────

    @Test
    final void testCamminoVersoDiSeStesso() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        GraphNode<String> s = new GraphNode<String>("s");
        bf.computeShortestPathsFrom(s);
        List<GraphEdge<String>> cammino = bf.getShortestPathTo(s);
        assertNotNull(cammino);
        assertTrue(cammino.isEmpty());
    }

    // ── Nodo non raggiungibile → null ─────────────────────────────────────────

    @Test
    final void testNodoNonRaggiungibile() {
        // c non ha archi entranti → non raggiungibile da a
        Graph<String> g = new AdjacencyMatrixDirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        GraphNode<String> c = new GraphNode<String>("c");
        g.addNode(a); g.addNode(b); g.addNode(c);
        g.addEdge(new GraphEdge<String>(a, b, true, 1.0));

        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        bf.computeShortestPathsFrom(a);

        assertNull(bf.getShortestPathTo(c),
                "c non raggiungibile → deve restituire null");
    }

    // ── Ciclo negativo → IllegalStateException ────────────────────────────────

    @Test
    final void testCicloNegativo() {
        // Ciclo: a→b(-1) b→c(-1) c→a(-1)  peso totale = -3
        Graph<String> g = new AdjacencyMatrixDirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        GraphNode<String> c = new GraphNode<String>("c");
        GraphNode<String> d = new GraphNode<String>("d");
        g.addNode(a); g.addNode(b); g.addNode(c); g.addNode(d);
        g.addEdge(new GraphEdge<String>(a, b, true, -1.0));
        g.addEdge(new GraphEdge<String>(b, c, true, -1.0));
        g.addEdge(new GraphEdge<String>(c, a, true, -1.0));
        g.addEdge(new GraphEdge<String>(a, d, true,  5.0));

        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        assertThrows(IllegalStateException.class,
                () -> bf.computeShortestPathsFrom(a));
    }

    // ── Ciclo positivo → nessuna eccezione ───────────────────────────────────

    @Test
    final void testCicloPositivoNonLanciaEccezione() {
        // Ciclo: a→b(2) b→c(3) c→a(1)  peso totale = +6
        Graph<String> g = new AdjacencyMatrixDirectedGraph<String>();
        GraphNode<String> a = new GraphNode<String>("a");
        GraphNode<String> b = new GraphNode<String>("b");
        GraphNode<String> c = new GraphNode<String>("c");
        g.addNode(a); g.addNode(b); g.addNode(c);
        g.addEdge(new GraphEdge<String>(a, b, true, 2.0));
        g.addEdge(new GraphEdge<String>(b, c, true, 3.0));
        g.addEdge(new GraphEdge<String>(c, a, true, 1.0));

        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        assertDoesNotThrow(() -> bf.computeShortestPathsFrom(a));
    }

    // ── Concordanza con Dijkstra su pesi non negativi ─────────────────────────

    @Test
    final void testConcordanzaConDijkstra() {
        Graph<String> g = new AdjacencyMatrixDirectedGraph<String>();
        GraphNode<String> ns = new GraphNode<String>("s");
        GraphNode<String> nu = new GraphNode<String>("u");
        GraphNode<String> nx = new GraphNode<String>("x");
        GraphNode<String> ny = new GraphNode<String>("y");
        GraphNode<String> nv = new GraphNode<String>("v");
        g.addNode(ns); g.addNode(nu); g.addNode(nx);
        g.addNode(ny); g.addNode(nv);
        g.addEdge(new GraphEdge<String>(ns, nu, true, 10.1));
        g.addEdge(new GraphEdge<String>(ns, nx, true,  5.12));
        g.addEdge(new GraphEdge<String>(nu, nx, true,  2.05));
        g.addEdge(new GraphEdge<String>(nx, nu, true,  3.04));
        g.addEdge(new GraphEdge<String>(nx, ny, true,  2.0));
        g.addEdge(new GraphEdge<String>(ny, ns, true,  7.03));
        g.addEdge(new GraphEdge<String>(nu, nv, true,  1.0));
        g.addEdge(new GraphEdge<String>(nx, nv, true,  9.05));
        g.addEdge(new GraphEdge<String>(ny, nv, true,  6.0));
        g.addEdge(new GraphEdge<String>(nv, ny, true,  4.07));

        // Eseguo Bellman-Ford
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        bf.computeShortestPathsFrom(ns);
        double distBFv = g.getNode("v").getFloatingPointDistance();
        double distBFy = g.getNode("y").getFloatingPointDistance();

        // Eseguo Dijkstra sullo stesso grafo
        DijkstraShortestPathComputer<String> dijk =
                new DijkstraShortestPathComputer<String>(g);
        dijk.computeShortestPathsFrom(ns);
        double distDijkv = g.getNode("v").getFloatingPointDistance();
        double distDijky = g.getNode("y").getFloatingPointDistance();

        double delta = 1e-9;
        assertEquals(distBFv, distDijkv, delta,
                "BF e Dijkstra devono concordare sulla distanza s→v");
        assertEquals(distBFy, distDijky, delta,
                "BF e Dijkstra devono concordare sulla distanza s→y");
    }

    // ── getShortestPathTo con null / nodo assente ─────────────────────────────

    @Test
    final void testGetShortestPathToNull() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        bf.computeShortestPathsFrom(new GraphNode<String>("s"));
        assertThrows(NullPointerException.class,
                () -> bf.getShortestPathTo(null));
    }

    @Test
    final void testGetShortestPathToNodoAssente() {
        Graph<String> g = buildCormenGraph();
        BellmanFordShortestPathComputer<String> bf =
                new BellmanFordShortestPathComputer<String>(g);
        bf.computeShortestPathsFrom(new GraphNode<String>("s"));
        assertThrows(IllegalArgumentException.class,
                () -> bf.getShortestPathTo(
                        new GraphNode<String>("NONESISTE")));
    }
}
