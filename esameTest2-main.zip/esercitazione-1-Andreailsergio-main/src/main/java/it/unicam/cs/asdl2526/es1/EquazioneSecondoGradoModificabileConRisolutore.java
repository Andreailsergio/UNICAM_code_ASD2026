/**
 * 
 */
package it.unicam.cs.asdl2526.es1;

/**
 * Un oggetto di questa classe permette di rappresentare una equazione di
 * secondo grado e di trovarne le soluzioni reali. I valori dei parametri
 * dell'equazione possono cambiare nel tempo. All'inizio e ogni volta che viene
 * cambiato un parametro la soluzione dell'equazione non esiste e deve essere
 * calcolata con il metodo <code>solve()</code>. E' possibile sapere se al
 * momento la soluzione dell'equazione esiste con il metodo
 * <code>isSolved()</code>. Qualora la soluzione corrente non esista e si tenti
 * di ottenerla verrà lanciata una eccezione.
 * 
 * @author Template: Luca Tesei, Implementation: Collettiva da Esercitazione a
 *         Casa
 *
 */
public class EquazioneSecondoGradoModificabileConRisolutore {
    /*
     * Costante piccola per il confronto di due numeri double
     */
    private static final double EPSILON = 1.0E-15;

    private double a;

    private double b;

    private double c;

    private boolean solved;

    private SoluzioneEquazioneSecondoGrado lastSolution;

    /**
     * Costruisce una equazione di secondo grado modificabile. All'inizio
     * l'equazione non è risolta.
     * 
     * 
     * @param a
     *              coefficiente del termine x^2, deve essere diverso da zero.
     * @param b
     *              coefficiente del termine x
     * @param c
     *              termine noto
     * @throws IllegalArgumentException
     *                                      se il parametro <code>a</code> è
     *                                      zero
     * 
     */
    // esiste sempre anche il costruttore senza parametri che mette i valori di default
    // 0 per interi e floating point, false per booleani, "" per stringhe, null per oggetti
    public EquazioneSecondoGradoModificabileConRisolutore(double a, double b,
            double c) {
        // TODO implementare
        if (Math.abs(a) < EPSILON)
            throw new IllegalArgumentException("il coefficiente a del termine x quadratico deve essere maggiore di zero");
        // a è sia la variabile istanza passata come parametro, sia il puntatore all'oggetto stesso
        // quindi this disambigua distinguendo puntatore this.a che viene creato dal costruttore da parametro a passato
        this.a=a;
        this.b=b;
        this.c=c;
        // nella fase iniziale del costruttore l'equazione non è mai ancora stata risolta, e non esiste ancora un'ultima soluzione calcolata e salvata
        this.solved = false;
        this.lastSolution = null;
    }

    /**
     * @return il valore corrente del parametro a
     */
    public double getA() {
        return a;
    }

    /**
     * Cambia il parametro a di questa equazione. Dopo questa operazione
     * l'equazione andrà risolta di nuovo.
     * 
     * @param a
     *              il nuovo valore del parametro a
     * @throws IllegalArgumentException
     *                                      se il nuovo valore è zero
     */
    public void setA(double a) {
        // TODO implementare
        // voglio anche controllare se viene ripassato un a con valore già processato e dunque non rieseguo l'aggiornamento
        if (Math.abs(a) < EPSILON)
            throw new IllegalArgumentException("il coefficiente a del termine x quadratico deve essere maggiore di zero");
        // potrei anche controllare che se viene ripassato un a con valore già processato this.a e dunque (a - vecchio this.a) = 0
        // non rieseguo l'aggiornamento e solved rimane true, altrimenti rimetto solved a false
        if (Math.abs(a - this.a) > EPSILON)
            solved = false;
        this.a=a;
    }

    /**
     * @return il valore corrente del parametro b
     */
    public double getB() {
        return b;
    }

    /**
     * Cambia il parametro b di questa equazione. Dopo questa operazione
     * l'equazione andrà risolta di nuovo.
     * 
     * @param b
     *              il nuovo valore del parametro b
     */
    public void setB(double b) {
        // TODO implementare
        if (Math.abs(b - this.b) > EPSILON)
            solved = false;
        this.b=b;
    }

    /**
     * @return il valore corrente del parametro c
     */
    public double getC() {
        return c;
    }

    /**
     * Cambia il parametro c di questa equazione. Dopo questa operazione
     * l'equazione andrà risolta di nuovo.
     * 
     * @param c
     *              il nuovo valore del parametro c
     */
    public void setC(double c) {
        // TODO implementare
        if (Math.abs(c - this.c) > EPSILON)
            solved = false;
        this.c=c;
    }

    /**
     * Determina se l'equazione, nel suo stato corrente, è già stata risolta.
     * 
     * @return true se l'equazione è risolta, false altrimenti
     */
    public boolean isSolved() {
        return solved;
    }

    /**
     * Risolve l'equazione risultante dai parametri a, b e c correnti. Se
     * l'equazione era già stata risolta con i parametri correnti non viene
     * risolta di nuovo.
     */
    // il metodo solve non ritorna nulla (è void)
    public void solve() {
        // TODO implementare
        // se la soluzione già esisteva - risolta con i parametri correnti - non rifaccio nulla
        if (this.solved) {return;}
        else {
            // calcolo il DELTA d= b^2 - 4ac
            double d = b * b - (4*a*c);
            // Se DELTA < 0 -> c'è una sola soluzione con un solo numero reale
            if (Math.abs(d) < EPSILON) lastSolution = new SoluzioneEquazioneSecondoGrado(new EquazioneSecondoGrado(this.a, this.b, this.c),
                    (-(b/(2*a))));
            // Se DELTA = 0 -> non ci sono soluzioni
            // (il costruttore della soluzione prende solo come parametro l'equazione - sempre da calcolare col metodo non modificabile -
            // che però costruisce soluzione vuota)
            else if (d < EPSILON) lastSolution = new SoluzioneEquazioneSecondoGrado(new EquazioneSecondoGrado(this.a, this.b, this.c));
            // Se DELTA > 0 // if (d > EPSILON) -> ci sono due diverse soluzioni e vengono passati 2 valori reali
            else lastSolution = new SoluzioneEquazioneSecondoGrado(new EquazioneSecondoGrado(this.a, this.b, this.c),
                    ((-b + Math.sqrt(d)) / (2*a)), ((-b - Math.sqrt(d)) / (2*a)));
            this.solved = true;}
    }

    /**
     * Restituisce la soluzione dell'equazione risultante dai parametri
     * correnti. L'equazione con i parametri correnti deve essere stata
     * precedentemente risolta.
     * 
     * @return la soluzione
     * @throws IllegalStateException
     *                                   se l'equazione risulta non risolta,
     *                                   all'inizio o dopo il cambiamento di
     *                                   almeno uno dei parametri
     */
    public SoluzioneEquazioneSecondoGrado getSolution() {
        // TODO implementare
        if (this.solved) {
            return this.lastSolution;}
        else {throw new IllegalStateException(
                "Equazione risulta non risolta");}
        // return null;
    }

}
