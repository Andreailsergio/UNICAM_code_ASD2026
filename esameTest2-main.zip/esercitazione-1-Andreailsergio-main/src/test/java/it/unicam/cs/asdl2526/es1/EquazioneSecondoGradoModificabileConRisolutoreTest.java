/**
 * 
 */
package it.unicam.cs.asdl2526.es1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Template: Luca Tesei, Implementation: Collettiva da Esercitazione a
 *         Casa
 *
 */
class EquazioneSecondoGradoModificabileConRisolutoreTest {
    /*
     * Costante piccola per il confronto di due numeri double
     */
    static final double EPSILON = 1.0E-15;

    @Test
    final void testEquazioneSecondoGradoModificabileConRisolutore() {
        // controllo che il valore 0 su a lanci l'eccezione
        assertThrows(IllegalArgumentException.class,
                () -> new EquazioneSecondoGradoModificabileConRisolutore(0, 1,
                        1));
        // devo controllare che comunque nel caso normale il costruttore funziona
        EquazioneSecondoGradoModificabileConRisolutore eq = new EquazioneSecondoGradoModificabileConRisolutore(
                1, 1, 1);
        assertTrue(eq.getA()==1);
        assertTrue(eq.getB()==1);
        assertTrue(eq.getC()==1);
        // Controllo che all'inizio l'equazione non sia risolta
        assertFalse(eq.isSolved());
    }

    @Test
    final void testGetA() {
        double x = 10;
        EquazioneSecondoGradoModificabileConRisolutore e1 = new EquazioneSecondoGradoModificabileConRisolutore(
                x, 1, 1);
        // controllo che il valore restituito sia quello che ho messo
        // all'interno
        // dell'oggetto
        assertTrue(x == e1.getA());
        // in generale si dovrebbe usare assertTrue(Math.abs(x -
        // e1.getA())<EPSILON) ma in
        // questo caso il valore che testiamo non ha subito manipolazioni quindi
        // la sua rappresentazione sarà la stessa di quella inserita nel
        // costruttore senza errori di approssimazione

    }

    @Test
    final void testSetA() {
        // TODO implementare
        // istanzio una nuova equazione
        EquazioneSecondoGradoModificabileConRisolutore eq = new EquazioneSecondoGradoModificabileConRisolutore(1,2,3);
        // testo che se cambio il valore di a la variazione sia avvenuta
        eq.setA(5);
        assertTrue(eq.getA()==5);
        // testo che se setto a = 0 venga lanciato l'errore
        assertThrows(IllegalArgumentException.class,
                () -> eq.setA(0));
        // controllo che dopo la risoluzione dell'equazione il flag isSolved sia vero
        eq.solve();
        assertTrue(eq.isSolved());
        // controllo che dopo aver cambiato il valore di a = 7 con setA isSolved torni ad essere falso (quindi è falso che sia vero)
        eq.setA(7);
        assertFalse(eq.isSolved());
        //fail("Test non implementato");
    }

    @Test
    final void testGetB() {
        // TODO implementare
        double x = 10;
        EquazioneSecondoGradoModificabileConRisolutore e1 = new EquazioneSecondoGradoModificabileConRisolutore(
                1, x, 1);
        assertTrue(x == e1.getB());
        // fail("Test non implementato");
    }

    @Test
    final void testSetB() {
        // TODO implementare
        EquazioneSecondoGradoModificabileConRisolutore eq = new EquazioneSecondoGradoModificabileConRisolutore(1,2,3);
        eq.setB(5);
        assertTrue(eq.getB()==5);
        eq.solve();
        assertTrue(eq.isSolved());
        eq.setB(7);
        assertFalse(eq.isSolved());
        //fail("Test non implementato");
    }

    @Test
    final void testGetC() {
        // TODO implementare
        double x = 10;
        EquazioneSecondoGradoModificabileConRisolutore e1 = new EquazioneSecondoGradoModificabileConRisolutore(
                1, 1, x);
        assertTrue(x == e1.getC());
        // fail("Test non implementato");
    }

    @Test
    final void testSetC() {
        // TODO implementare
        EquazioneSecondoGradoModificabileConRisolutore eq = new EquazioneSecondoGradoModificabileConRisolutore(1,2,3);
        eq.setC(5);
        assertTrue(eq.getC()==5);
        eq.solve();
        assertTrue(eq.isSolved());
        eq.setC(7);
        assertFalse(eq.isSolved());
        //fail("Test non implementato");
    }

    @Test
    final void testIsSolved() {
        // TODO implementare
        EquazioneSecondoGradoModificabileConRisolutore e3 = new EquazioneSecondoGradoModificabileConRisolutore(
                1, 1, 3);
        // prima della soluzione isSolved è falso
        assertFalse(e3.isSolved());
        // dopo la soluzione isSolved è vero
        e3.solve();
        assertTrue(e3.isSolved());
        // al cambiamento di un valore parametrico isSolved torna falso
        e3.setA(5);
        assertFalse(e3.isSolved());
        // fail("Test non implementato");
    }

    @Test
    final void testSolve() {
        EquazioneSecondoGradoModificabileConRisolutore e4 = new EquazioneSecondoGradoModificabileConRisolutore(
                1, 1, 3);
        // controllo semplicemente che la chiamata a solve() non generi errori
        e4.solve();
        assertTrue(e4.isSolved());
        // i test con i valori delle soluzioni vanno fatti nel test del metodo
        // getSolution()
    }

    @Test
    final void testGetSolution() {
        // TODO implementare
        // equazione con 2 soluzioni
        EquazioneSecondoGradoModificabileConRisolutore e5 = new EquazioneSecondoGradoModificabileConRisolutore(
                1, -3, 2);
        e5.solve();
        SoluzioneEquazioneSecondoGrado sol1 = e5.getSolution();
        assertFalse(sol1.isEmptySolution());
        assertFalse(sol1.isOneSolution());
        // non sai l'ordine: s1 e s2 possono essere 1 o 2 (viceversa)
        assertTrue(Math.abs(sol1.getS1() - 1.0) < EPSILON
                || Math.abs(sol1.getS1() - 2.0) < EPSILON);
        assertTrue(Math.abs(sol1.getS2() - 1.0) < EPSILON
                || Math.abs(sol1.getS2() - 2.0) < EPSILON);
        // in ogni caso le due soluzioni devono essere diverse
        assertFalse(Math.abs(sol1.getS1() - sol1.getS2()) < EPSILON);
        // risultato dovrebbe essere x1=1 e x2=2

        // equazione con 1 soluzione
        EquazioneSecondoGradoModificabileConRisolutore e6 = new EquazioneSecondoGradoModificabileConRisolutore(
                1, -2, 1);
        e6.solve();
        SoluzioneEquazioneSecondoGrado sol2 = e6.getSolution();
        assertTrue(sol2.isOneSolution());
        // risultato dovrebbe essere x=1

        // equazione con delta negativo - nessun risultato possibile nell'insieme dei numeri reali
        EquazioneSecondoGradoModificabileConRisolutore e7 = new EquazioneSecondoGradoModificabileConRisolutore(
                1, 1, 1);
        e7.solve();
        SoluzioneEquazioneSecondoGrado sol3 = e7.getSolution();
        assertTrue(sol3.isEmptySolution());
        // risultato null

        // verifica generica che non si sollevino altre eccezioni
        assertDoesNotThrow(() -> e7.getSolution());
        // fail("Test non implementato");
    }

}
